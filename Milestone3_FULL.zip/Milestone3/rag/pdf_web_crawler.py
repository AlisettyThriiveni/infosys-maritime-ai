#!/usr/bin/env python3
"""
pdf_web_crawler.py   [M3 MODIFIED]
==================
Crawls seed websites → discovers ALL PDFs → downloads them →
rebuilds FAISS + BM25 indexes.

Milestone 3 changes (everything else is the original crawler):
  * FREIGHT_SEEDS: 220 sources, every one checked on 2026-11-10 (HTTP 200 + 50+ words of extracted text, duplicates removed).
    76 original seeds kept, 144 new ones added (weak topics first: demurrage, trade finance, insurance, documents, rates).
  * UNAVAILABLE_SEEDS (53): the 51 original seeds that failed the check (404 / 403 / no text), 1 duplicate redirect and 1 stub page, each with the reason. Not crawled.
  * Pre-flight check (PREFLIGHT_CHECK): every seed is fetched once before crawling; failures are skipped and reported.
  * Packages are pip-installed only when missing.
  * Cleaning: citation lists, edit links, navigation boxes and 'Retrieved ...' lines are removed before chunking.

Drive folders:
  FranchiseOps → MyDrive/FranchiseOps_AI/rag_pdfs/
  FreightQuote → MyDrive/FreightQuote_AI/rag_pdfs/
"""

import os
import re
import json
import time
import pickle
import hashlib
import requests
import urllib.parse
import subprocess
import sys

from pathlib import Path
from collections import deque
from datetime import datetime

# Install deps silently, only the ones that are missing  [M3]
for pkg, mod in [("requests", "requests"), ("beautifulsoup4", "bs4"), ("lxml", "lxml"), ("tqdm", "tqdm"),
                 ("PyMuPDF", "fitz"), ("sentence-transformers", "sentence_transformers"), ("faiss-cpu", "faiss"), ("rank-bm25", "rank_bm25")]:
    try:
        __import__(mod)
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", pkg], capture_output=True)

from bs4 import BeautifulSoup
from tqdm.auto import tqdm

# ─── Drive folder names ───────────────────────────────────────────────────────

FQ_DRIVE_FOLDER = "FreightQuote_AI"

# ─── Crawler settings ─────────────────────────────────────────────────────────
HEADERS = {
    "User-Agent": ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                   "Chrome/120.0.0.0 Safari/537.36"),
    "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
}
PDF_HEADERS = {
    "User-Agent": HEADERS["User-Agent"],
    "Accept": "application/pdf,*/*",
}

MAX_CRAWL_DEPTH   = 2
MAX_PDFS_PER_SEED = 80      # Milestone 3: raised from 50 to collect 150+ sources
MAX_PAGES_PER_SEED = 20     # HTML pages visited per seed (was a global cap of 200 shared by all seeds)
MAX_TOTAL_PDFS    = 600     # upper bound on downloads per run (Colab time / Drive quota)
MAX_PDF_MB        = 25      # skip very large files
TARGET_SOURCES    = 150     # Milestone 3 target: 150+ websites and PDFs
SAVE_WEB_PAGES    = True    # also keep each seed web page itself as a source (websites + PDFs)
BUILD_INDEX_HERE  = False   # the notebook builds ONE combined FAISS + BM25 index later (synthetic KB + crawled docs)
SHALLOW_DOMAINS   = ("wikipedia.org",)   # keep this page only, do not follow its links
SKIP_URL_WORDS    = ("login", "signin", "sign-in", "register", "account", "cart", "checkout", "mailto:")
PREFLIGHT_CHECK   = True    # [M3] fetch every seed once before crawling; seeds that fail are skipped and reported
PREFLIGHT_WORKERS = 12
DOWNLOAD_TIMEOUT  = 25
REQUEST_TIMEOUT   = 15
DELAY_BETWEEN     = 0.4
CHUNK_WORDS       = 400
CHUNK_OVERLAP     = 50

# ─────────────────────────────────────────────────────────────────────────────
# SEED URLS
# ─────────────────────────────────────────────────────────────────────────────



FREIGHT_SEEDS = [
    # ── Original seeds that passed the Milestone 3 accessibility check (HTTP 200 and 50+ words of text) ──
    ("Web Source", "https://www.iata.org/en/programs/cargo/live-animals"),
    ("Web Source", "https://www.classnk.or.jp/hp/en/index.html"),
    ("Web Source", "https://www.trade.gov/trade-data-and-analysis"),
    ("Web Source", "https://www.cbp.gov/trade/basic-import-export"),
    ("Web Source", "https://www.worldbank.org/en/topic/trade"),
    ("Web Source", "https://www.cbp.gov/trade/automated"),
    ("Web Source", "https://www.customs.gov.sg/businesses/importing-goods/overview"),
    ("Web Source", "https://www.joc.com"),
    ("Web Source", "https://www.gov.uk/import-goods-into-uk"),
    ("Web Source", "https://taxation-customs.ec.europa.eu/customs-4/union-customs-code_en"),
    ("Web Source", "https://www.bis.doc.gov/index.php/regulations/export-administration-regulations-ear"),
    ("Web Source", "https://unctad.org/topic/trade-analysis"),
    ("Web Source", "https://www.iata.org/en/programs/cargo/dgr"),
    ("Web Source", "https://www.customs.gov.sg/businesses/exporting-goods/overview"),
    ("Web Source", "https://www.cbp.gov/trade/priority-issues"),
    ("Web Source", "https://www.gov.uk/guidance/pay-less-import-duty-and-vat-when-re-importing-goods-to-the-uk-and-eu"),
    ("Web Source", "https://www.intercargo.org"),
    ("Web Source", "https://taxation-customs.ec.europa.eu/customs-4/prohibitions-and-restrictions_en"),
    ("Web Source", "https://www.gov.uk/export-goods"),
    ("Web Source", "https://www.worldbank.org/en/topic/transport/overview"),
    ("Web Source", "https://iccwbo.org/business-solutions/incoterms-rules/incoterms-2020"),
    ("Web Source", "https://www.icegate.gov.in"),
    ("Web Source", "https://www.wto.org/english/tratop_e/tariffs_e/tariffs_e.htm"),
    ("Web Source", "https://www.logisticsmgmt.com"),
    ("Web Source", "https://www.freightos.com/freight-resources/freight-rate"),
    ("Web Source", "https://www.wto.org/english/thewto_e/whatis_e/tif_e/agrm8_e.htm"),
    ("Web Source", "https://www.trade.gov/export-solutions"),
    ("Web Source", "https://www.imo.org/en/OurWork/Safety/Pages/default.aspx"),
    ("Web Source", "https://www.fmc.gov/about-the-fmc"),
    ("Web Source", "http://english.customs.gov.cn"),
    ("Web Source", "https://www.supplychaindigital.com"),
    ("Web Source", "https://www.bimco.org/contracts-and-clauses/contracts"),
    ("Maritime Law", "https://www.imo.org/en/KnowledgeCentre/IndexofIMOResolutions/"),
    ("Shipping Reports", "https://unctad.org/topic/transport-and-trade-logistics/review-of-maritime-transport"),
    ("Shipping Reports", "https://unctad.org/publications?field_topics_target_id=78"),
    ("INCOTERMS", "https://iccwbo.org/resources-for-business/incoterms-rules/"),
    ("India Trade", "https://www.dgft.gov.in/CP/"),
    ("Environmental", "https://www.imo.org/en/OurWork/Environment/Pages/Default.aspx"),
    ("Trade Finance", "https://iccwbo.org/resources-for-business/trade-finance/"),
    ("Research", "https://arxiv.org/search/?searchtype=all&query=maritime+freight+pricing+machine+learning"),
    ("Research", "https://arxiv.org/search/?searchtype=all&query=port+congestion+prediction"),
    ("Research", "https://arxiv.org/search/?searchtype=all&query=customs+risk+classification"),
    ("Research", "https://arxiv.org/search/?searchtype=all&query=vessel+route+optimization"),
    ("Research", "https://arxiv.org/search/?searchtype=all&query=supply+chain+disruption+prediction"),
    ("Research", "https://arxiv.org/search/?searchtype=all&query=freight+rate+forecasting"),
    ("Research", "https://arxiv.org/search/?searchtype=all&query=RAG+large+language+model+logistics"),
    ("Research", "https://arxiv.org/search/?searchtype=all&query=digital+twin+shipping"),
    ("Research", "https://arxiv.org/search/?searchtype=all&query=container+shipping+deep+learning"),
    ("EU Customs", "https://taxation-customs.ec.europa.eu/customs-4_en"),
    ("ESCAP", "https://www.unescap.org/our-work/transport"),
    ("Incoterms", "https://www.trade.gov/know-your-incoterms"),
    ("Incoterms", "https://en.wikipedia.org/wiki/Incoterms"),
    ("Customs & HS Codes", "https://www.trade.gov/harmonized-system-hs-codes"),
    ("Customs & HS Codes", "https://en.wikipedia.org/wiki/Harmonized_System"),
    ("Customs & HS Codes", "https://www.gov.uk/guidance/finding-commodity-codes-for-imports-or-exports"),
    ("Customs & HS Codes", "https://www.cbsa-asfc.gc.ca/trade-commerce/tariff-tarif/menu-eng.html"),
    ("Shipping Documents", "https://www.trade.gov/common-export-documents"),
    ("Shipping Documents", "https://en.wikipedia.org/wiki/Bill_of_lading"),
    ("Shipping Documents", "https://en.wikipedia.org/wiki/Commercial_invoice"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Intermodal_container"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Break_bulk_cargo"),
    ("Container & Cargo Types", "https://www.imo.org/en/OurWork/Safety/Pages/DangerousGoods-default.aspx"),
    ("Freight Rates & Surcharges", "https://en.wikipedia.org/wiki/Bunker_adjustment_factor"),
    ("Freight Rates & Surcharges", "https://en.wikipedia.org/wiki/Freight_rate"),
    ("Demurrage & Detention", "https://en.wikipedia.org/wiki/Demurrage"),
    ("Demurrage & Detention", "https://en.wikipedia.org/wiki/Laytime"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/List_of_busiest_container_ports"),
    ("Weather & Route Risk", "https://www.nhc.noaa.gov/"),
    ("Weather & Route Risk", "https://www.weather.gov/marine/"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Suez_Canal"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Panama_Canal"),
    ("Marine Insurance", "https://en.wikipedia.org/wiki/Marine_insurance"),
    ("Marine Insurance", "https://en.wikipedia.org/wiki/General_average"),
    ("Marine Insurance", "https://en.wikipedia.org/wiki/Protection_and_indemnity_insurance"),
    ("Trade Finance", "https://en.wikipedia.org/wiki/Letter_of_credit"),
    ("Trade Finance", "https://www.exim.gov/"),

    # ── Milestone 3: new verified sources (each checked: HTTP 200, 50+ words extracted, not a duplicate) ──
    # Incoterms (7)
    ("Incoterms", "https://en.wikipedia.org/wiki/FOB_(shipping)"),
    ("Incoterms", "https://en.wikipedia.org/wiki/Cost,_insurance_and_freight"),
    ("Incoterms", "https://en.wikipedia.org/wiki/Delivered_Duty_Paid"),
    ("Incoterms", "https://en.wikipedia.org/wiki/Delivered_at_Place"),
    ("Incoterms", "https://en.wikipedia.org/wiki/Free_alongside_ship"),
    ("Incoterms", "https://en.wikipedia.org/wiki/Cost_and_freight"),
    # Customs & HS Codes (20)
    ("Customs & HS Codes", "https://en.wikipedia.org/wiki/Customs"),
    ("Customs & HS Codes", "https://en.wikipedia.org/wiki/Tariff"),
    ("Customs & HS Codes", "https://en.wikipedia.org/wiki/Rules_of_origin"),
    ("Customs & HS Codes", "https://en.wikipedia.org/wiki/Certificate_of_origin"),
    ("Customs & HS Codes", "https://en.wikipedia.org/wiki/Authorized_economic_operator"),
    ("Customs & HS Codes", "https://en.wikipedia.org/wiki/Bonded_warehouse"),
    ("Customs & HS Codes", "https://en.wikipedia.org/wiki/Customs_broker"),
    ("Customs & HS Codes", "https://en.wikipedia.org/wiki/ATA_Carnet"),
    ("Customs & HS Codes", "https://en.wikipedia.org/wiki/Customs_valuation"),
    ("Customs & HS Codes", "https://en.wikipedia.org/wiki/Free-trade_zone"),
    ("Customs & HS Codes", "https://en.wikipedia.org/wiki/World_Customs_Organization"),
    ("Customs & HS Codes", "https://en.wikipedia.org/wiki/Harmonized_Tariff_Schedule_of_the_United_States"),
    ("Customs & HS Codes", "https://en.wikipedia.org/wiki/Central_Board_of_Indirect_Taxes_and_Customs"),
    ("Customs & HS Codes", "https://www.gov.uk/guidance/check-if-you-can-pay-a-reduced-rate-of-customs-duty"),
    ("Customs & HS Codes", "https://www.cbp.gov/trade/rulings"),
    ("Customs & HS Codes", "https://www.cbp.gov/trade/programs-administration/entry-summary"),
    ("Customs & HS Codes", "https://www.wto.org/english/tratop_e/roi_e/roi_e.htm"),
    ("Customs & HS Codes", "https://www.wto.org/english/tratop_e/cusval_e/cusval_e.htm"),
    ("Customs & HS Codes", "https://www.wto.org/english/docs_e/legal_e/tfa-nov14_e.htm"),
    ("Customs & HS Codes", "https://www.wcoomd.org/-/media/wco/public/global/pdf/topics/facilitation/instruments-and-tools/tools/safe-package/safe-framework-of-standards.pdf"),
    # Shipping Documents (6)
    ("Shipping Documents", "https://en.wikipedia.org/wiki/Air_waybill"),
    ("Shipping Documents", "https://en.wikipedia.org/wiki/Packing_list"),
    ("Shipping Documents", "https://en.wikipedia.org/wiki/Dock_receipt"),
    ("Shipping Documents", "https://en.wikipedia.org/wiki/Manifest_(transportation)"),
    ("Shipping Documents", "https://en.wikipedia.org/wiki/Shipping_bill"),
    ("Shipping Documents", "https://www.gov.uk/guidance/international-trade-paperwork-the-basics"),
    # Container & Cargo Types (14)
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Container_ship"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Refrigerated_container"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Tank_container"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Twenty-foot_equivalent_unit"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Bulk_carrier"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Roll-on/roll-off"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Less_than_container_load"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Containerization"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Dangerous_goods"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/International_Maritime_Dangerous_Goods_Code"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Bulk_cargo"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Project_cargo"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Reefer_ship"),
    ("Container & Cargo Types", "https://en.wikipedia.org/wiki/Tanker_(ship)"),
    # Freight Rates & Surcharges (10)
    ("Freight Rates & Surcharges", "https://en.wikipedia.org/wiki/Baltic_Dry_Index"),
    ("Freight Rates & Surcharges", "https://en.wikipedia.org/wiki/Bunker_fuel"),
    ("Freight Rates & Surcharges", "https://en.wikipedia.org/wiki/Bunkering"),
    ("Freight Rates & Surcharges", "https://en.wikipedia.org/wiki/Charter_party"),
    ("Freight Rates & Surcharges", "https://en.wikipedia.org/wiki/Voyage_charter"),
    ("Freight Rates & Surcharges", "https://en.wikipedia.org/wiki/Time_charter"),
    ("Freight Rates & Surcharges", "https://en.wikipedia.org/wiki/Currency_adjustment_factor"),
    ("Freight Rates & Surcharges", "https://en.wikipedia.org/wiki/Freight_forwarder"),
    ("Freight Rates & Surcharges", "https://en.wikipedia.org/wiki/Shipping_line"),
    ("Freight Rates & Surcharges", "https://fbx.freightos.com/"),
    # Demurrage & Detention (5)
    ("Demurrage & Detention", "https://www.fmc.gov/detention-and-demurrage/"),
    ("Demurrage & Detention", "https://www.federalregister.gov/documents/2020/05/18/2020-10039/interpretive-rule-on-demurrage-and-detention-under-the-shipping-act"),
    ("Demurrage & Detention", "https://www.federalregister.gov/documents/2024/02/26/2024-03147/demurrage-and-detention-billing-requirements"),
    ("Demurrage & Detention", "https://www.law.cornell.edu/cfr/text/46/part-541"),
    ("Demurrage & Detention", "https://www.ecfr.gov/current/title-46/chapter-IV/subchapter-B/part-541"),
    # Ports & Congestion (20)
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Port_of_Singapore"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Port_of_Rotterdam"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Port_of_Shanghai"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Jawaharlal_Nehru_Port"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Mundra_Port"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Port_of_Jebel_Ali"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Port_of_Antwerp-Bruges"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Port_of_Hamburg"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Port_of_Los_Angeles"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Port_of_Colombo"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Port_of_Busan"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Port_of_Chennai"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Cochin_Port"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Port_of_Felixstowe"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Port_of_Ningbo-Zhoushan"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Container_port_design_process"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Port_authority"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/Container_terminal"),
    ("Ports & Congestion", "https://en.wikipedia.org/wiki/2021%E2%80%932023_global_supply_chain_crisis"),
    ("Ports & Congestion", "https://www.worldbank.org/en/topic/transport/brief/connections-note-the-container-port-performance-index"),
    # Weather & Route Risk (18)
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Strait_of_Malacca"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Strait_of_Hormuz"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Bab-el-Mandeb"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Cape_of_Good_Hope"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Tropical_cyclone"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Beaufort_scale"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Saffir%E2%80%93Simpson_scale"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Sea_state"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Significant_wave_height"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Monsoon"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Weather_routing"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Piracy_off_the_coast_of_Somalia"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Red_Sea_crisis"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/2021_Suez_Canal_obstruction"),
    ("Weather & Route Risk", "https://en.wikipedia.org/wiki/Bosphorus"),
    ("Weather & Route Risk", "https://www.nhc.noaa.gov/aboutsshws.php"),
    ("Weather & Route Risk", "https://www.metoffice.gov.uk/weather/guides/coast-and-sea/beaufort-scale"),
    ("Weather & Route Risk", "https://ocean.weather.gov/"),
    # Marine Insurance (8)
    ("Marine Insurance", "https://en.wikipedia.org/wiki/Cargo_insurance"),
    ("Marine Insurance", "https://en.wikipedia.org/wiki/Hague%E2%80%93Visby_Rules"),
    ("Marine Insurance", "https://en.wikipedia.org/wiki/Hamburg_Rules"),
    ("Marine Insurance", "https://en.wikipedia.org/wiki/Rotterdam_Rules"),
    ("Marine Insurance", "https://en.wikipedia.org/wiki/Lloyd%27s_of_London"),
    ("Marine Insurance", "https://en.wikipedia.org/wiki/Marine_Insurance_Act_1906"),
    ("Marine Insurance", "https://en.wikipedia.org/wiki/Salvage"),
    ("Marine Insurance", "https://en.wikipedia.org/wiki/Carriage_of_Goods_by_Sea_Act"),
    # Trade Finance (14)
    ("Trade Finance", "https://en.wikipedia.org/wiki/Trade_finance"),
    ("Trade Finance", "https://en.wikipedia.org/wiki/Documentary_collection"),
    ("Trade Finance", "https://en.wikipedia.org/wiki/Standby_letter_of_credit"),
    ("Trade Finance", "https://en.wikipedia.org/wiki/Export_credit_agency"),
    ("Trade Finance", "https://en.wikipedia.org/wiki/Factoring_(finance)"),
    ("Trade Finance", "https://en.wikipedia.org/wiki/Forfaiting"),
    ("Trade Finance", "https://en.wikipedia.org/wiki/Supply_chain_finance"),
    ("Trade Finance", "https://en.wikipedia.org/wiki/Uniform_Customs_and_Practice_for_Documentary_Credits"),
    ("Trade Finance", "https://en.wikipedia.org/wiki/Bank_guarantee"),
    ("Trade Finance", "https://www.trade.gov/letter-credit"),
    ("Trade Finance", "https://www.trade.gov/documentary-collections"),
    ("Trade Finance", "https://www.trade.gov/cash-advance"),
    ("Trade Finance", "https://www.trade.gov/export-credit-insurance"),
    ("Trade Finance", "https://www.trade.gov/methods-payment"),
    # Maritime Regulation (9)
    ("Maritime Regulation", "https://en.wikipedia.org/wiki/International_Maritime_Organization"),
    ("Maritime Regulation", "https://en.wikipedia.org/wiki/SOLAS_Convention"),
    ("Maritime Regulation", "https://en.wikipedia.org/wiki/MARPOL_73/78"),
    ("Maritime Regulation", "https://en.wikipedia.org/wiki/International_Ship_and_Port_Facility_Security_Code"),
    ("Maritime Regulation", "https://en.wikipedia.org/wiki/IMO_2020"),
    ("Maritime Regulation", "https://en.wikipedia.org/wiki/Shipping_Act_of_1984"),
    ("Maritime Regulation", "https://en.wikipedia.org/wiki/Federal_Maritime_Commission"),
    ("Maritime Regulation", "https://en.wikipedia.org/wiki/Container_Security_Initiative"),
    ("Maritime Regulation", "https://en.wikipedia.org/wiki/Flag_of_convenience"),
    # Logistics (11)
    ("Logistics", "https://en.wikipedia.org/wiki/Logistics"),
    ("Logistics", "https://en.wikipedia.org/wiki/Intermodal_freight_transport"),
    ("Logistics", "https://en.wikipedia.org/wiki/Third-party_logistics"),
    ("Logistics", "https://en.wikipedia.org/wiki/Supply_chain_management"),
    ("Logistics", "https://en.wikipedia.org/wiki/Cross-docking"),
    ("Logistics", "https://en.wikipedia.org/wiki/Freight_transport"),
    ("Logistics", "https://en.wikipedia.org/wiki/Maritime_transport"),
    ("Logistics", "https://en.wikipedia.org/wiki/Liner_service"),
    ("Logistics", "https://en.wikipedia.org/wiki/Transshipment"),
    ("Logistics", "https://en.wikipedia.org/wiki/Logistics_Performance_Index"),
    ("Logistics", "https://en.wikipedia.org/wiki/Automatic_identification_system"),
    # Shipping Reports (3)
    ("Shipping Reports", "https://unctad.org/system/files/official-document/rmt2023_en.pdf"),
    ("Shipping Reports", "https://unctad.org/system/files/official-document/rmt2024_en.pdf"),
    ("Shipping Reports", "https://unctad.org/system/files/official-document/rmt2022_en.pdf"),
]

# Seeds from the earlier list that failed the accessibility check on 2026-11-10 (moved page, blocked, or no extractable text).
# They are NOT crawled; each was replaced by verified sources above. Kept here so the change is traceable.
UNAVAILABLE_SEEDS = [
    ("Incoterms", "https://en.wikipedia.org/wiki/Free_carrier", "stub page: under 50 words after Milestone 3 cleaning"),
    ("Web Source", "https://www.iata.org/en/programs/cargo/security", "http_404"),
    ("Web Source", "http://www.wcoomd.org/en/topics/nomenclature/overview/what-is-the-harmonized-system.aspx", "too_short"),
    ("Web Source", "https://www.fmc.gov/shipping-guidance", "http_404"),
    ("Web Source", "https://www.gard.no/web/updates", "too_short"),
    ("Web Source", "https://www.investopedia.com/terms/f/freight.asp", "http_404"),
    ("Web Source", "https://www.trade.gov/customs-broker", "http_404"),
    ("Web Source", "https://www.marad.dot.gov", "http_403"),
    ("Web Source", "https://www.gov.uk/guidance/customs-declaration-service", "http_404"),
    ("Web Source", "https://www.investopedia.com/terms/p/profit-margin.asp", "http_404"),
    ("Web Source", "https://www.gov.uk/guidance/intrastat", "http_404"),
    ("Web Source", "https://www.gov.uk/government/collections/uk-trade-tariff", "http_404"),
    ("Web Source", "http://www.wcoomd.org/en/topics/facilitation/overview/overview-of-trade-facilitation.aspx", "http_404"),
    ("Web Source", "https://www.abf.gov.au/importing-exporting-and-manufacturing/importing", "too_short"),
    ("Web Source", "https://taxation-customs.ec.europa.eu/customs-4/customs-procedures-import_en", "http_404"),
    ("Web Source", "https://www.wto.org/english/tratop_e/tradfa_e/tradfa_e.htm", "too_short"),
    ("Web Source", "https://unctad.org/topic/trade-logistics", "http_404"),
    ("Web Source", "https://www.cbp.gov/trade/trade-community", "http_404"),
    ("Web Source", "https://www.fmc.gov/regulations", "http_404"),
    ("Web Source", "https://taxation-customs.ec.europa.eu/customs-4/customs-procedures-export_en", "http_404"),
    ("Web Source", "http://www.wcoomd.org/en/topics/enforcement-and-compliance.aspx", "too_short"),
    ("Web Source", "https://www.abf.gov.au/importing-exporting-and-manufacturing/exporting", "too_short"),
    ("Web Source", "https://www.lr.org/en/maritime", "http_404"),
    ("Web Source", "https://www.customs.gov.sg/businesses/customs-schemes-licences-framework/overview", "http_404"),
    ("Web Source", "https://www.abf.gov.au/importing-exporting-and-manufacturing/tariff-classification", "too_short"),
    ("Customs", "https://www.wcoomd.org/en/topics/nomenclature/resources.aspx", "too_short"),
    ("Customs", "https://www.wcoomd.org/en/topics/valuation/resources.aspx", "too_short"),
    ("US Customs", "https://www.cbp.gov/trade/publications", "http_404"),
    ("India Trade", "https://www.cbic.gov.in/resources//htdocs-cbec/customs/", "http_500"),
    ("India Trade", "https://shipmin.gov.in/en/publications", "http_400"),
    ("India Trade", "https://www.jnport.gov.in/page/publications", "http_404"),
    ("Port Operations", "https://unctad.org/topic/transport-and-trade-logistics/port-management", "http_404"),
    ("Port Operations", "https://www.mpa.gov.sg/publications/statistics", "http_404"),
    ("Freight Pricing", "https://unctad.org/topic/transport-and-trade-logistics/liner-shipping", "http_404"),
    ("Freight Pricing", "https://lpi.worldbank.org/", "http_403"),
    ("Marine Insurance", "https://www.ukpandi.com/knowledge-publications/", "http_404"),
    ("Marine Insurance", "https://www.gard.no/web/publications", "too_short"),
    ("Marine Insurance", "https://www.iumi.com/publications/", "http_404"),
    ("Weather Risk", "https://library.wmo.int/records?ln=en&p=marine&action_search=Search&c=", "too_short"),
    ("Digital Logistics", "https://unctad.org/topic/transport-and-trade-logistics/port-technology", "http_404"),
    ("Digital Logistics", "https://dcsa.org/resources/", "http_404"),
    ("Environmental", "https://www.dnv.com/maritime/publications/index.html", "http_403"),
    ("Trade Finance", "https://www.adb.org/publications?subject=trade-finance", "http_403"),
    ("Shipping Bodies", "https://www.ics-shipping.org/resources/", "http_403"),
    ("Shipping Bodies", "https://www.bimco.org/education-and-training/publications", "http_404"),
    ("India Finance", "https://rbidocs.rbi.org.in/rdocs/Publications/", "http_403"),
    ("WTO", "https://www.wto.org/english/res_e/publications_e/", "http_403"),
    ("FONASBA", "https://www.fonasba.com/publications", "http_404"),
    ("Freight Rates & Surcharges", "https://www.bts.gov/topics/freight-transportation", "http_403"),
    ("Ports & Congestion", "https://www.worldbank.org/en/topic/transport/publication/the-container-port-performance-index", "http_404"),
    ("Ports & Congestion", "https://www.bts.gov/ports", "http_403"),
    ("Trade Finance", "https://www.trade.gov/trade-finance-guide", "too_short"),
    ("Web Source", "https://www.bis.doc.gov/index.php/licensing", "duplicate (redirects to a page already in the list)"),
]


def _norm_url(u):
    """Normalise a URL for duplicate checks (scheme, www., case, trailing slash)."""
    p = urllib.parse.urlparse(u.strip())
    host = p.netloc.lower()
    if host.startswith("www."):
        host = host[4:]
    return host + p.path.rstrip("/").lower() + ("?" + p.query if p.query else "")


def dedupe_seeds(seeds):
    seen, out = set(), []
    for cat, url in seeds:
        k = _norm_url(url)
        if k not in seen:
            seen.add(k)
            out.append((cat, url))
    return out


FREIGHT_SEEDS = dedupe_seeds(FREIGHT_SEEDS)


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def is_pdf_url(url):
    low = url.lower()
    return (low.endswith(".pdf")
            or "/pdf/" in low
            or "download=pdf" in low
            or ".pdf?" in low
            or "format=pdf" in low)


def same_domain(url, base):
    try:
        return urllib.parse.urlparse(url).netloc == urllib.parse.urlparse(base).netloc
    except Exception:
        return False


def title_from_url(url):
    name = url.rstrip("/").split("/")[-1]
    # strip extension safely without regex escape warning
    for ext in [".pdf", ".PDF", ".htm", ".html", ".aspx", ".php"]:
        if name.endswith(ext):
            name = name[: -len(ext)]
    return name.replace("-", " ").replace("_", " ").strip()[:100]


_GENERIC_LINK_TEXT = {"", "pdf", "download", "here", "click here", "view", "read more",
                      "link", "open", "file", "more", "full text", "download pdf"}


def pick_title(link_text, url):
    """Use the link text as title unless it is empty or generic ('Download', 'PDF', ...)."""
    t = (link_text or "").strip().strip("\"'“”‘’ ")
    if len(t) < 8 or t.lower() in _GENERIC_LINK_TEXT:
        t = title_from_url(url) or t
    return t[:120]


def is_public_url(url):
    """Public pages only: skip login / account / checkout style links."""
    low = url.lower()
    return not any(w in low for w in SKIP_URL_WORDS)


def discover_pdfs(url, category, visited=None, found=None,
                  max_depth=MAX_CRAWL_DEPTH, max_per_seed=MAX_PDFS_PER_SEED):
    if visited is None:
        visited = set()
    if found is None:
        found = []

    # ArXiv special handling
    if "arxiv.org/search" in url:
        return _crawl_arxiv(url, category, max_per_seed)

    if any(d in url for d in SHALLOW_DOMAINS):
        max_depth = 0

    queue = deque([(url, 0)])
    visited.add(url)
    pages = 0

    while queue and len(found) < max_per_seed and pages < MAX_PAGES_PER_SEED:
        cur_url, depth = queue.popleft()
        pages += 1
        try:
            r = requests.get(cur_url, headers=HEADERS,
                             timeout=REQUEST_TIMEOUT, allow_redirects=True)
            if r.status_code != 200:
                continue
            ctype = r.headers.get("content-type", "")

            if "pdf" in ctype.lower():
                if cur_url not in [f["url"] for f in found]:
                    found.append({"url": cur_url, "category": category,
                                  "title": title_from_url(cur_url), "kind": "pdf"})
                continue

            soup = BeautifulSoup(r.text, "lxml")

            # Milestone 3: the seed website itself is a knowledge source too
            if depth == 0 and SAVE_WEB_PAGES:
                page_title = soup.title.get_text(strip=True) if soup.title else ""
                found.append({"url": cur_url, "category": category, "kind": "web",
                              "title": pick_title(page_title, cur_url)})

            for tag in soup.find_all("a", href=True):
                href = tag["href"].strip()
                abs_href = urllib.parse.urljoin(cur_url, href)
                if (is_pdf_url(abs_href) and is_public_url(abs_href)
                        and abs_href not in [f["url"] for f in found]):
                    title = pick_title(tag.get_text(strip=True), abs_href)
                    found.append({"url": abs_href, "category": category,
                                  "title": title, "kind": "pdf"})
                    if len(found) >= max_per_seed:
                        break

            if depth < max_depth:
                for tag in soup.find_all("a", href=True):
                    href = tag["href"].strip()
                    abs_href = urllib.parse.urljoin(cur_url, href)
                    if (abs_href not in visited
                            and same_domain(abs_href, url)
                            and not is_pdf_url(abs_href)
                            and is_public_url(abs_href)
                            and abs_href.startswith("http")
                            and "#" not in abs_href):
                        visited.add(abs_href)
                        queue.append((abs_href, depth + 1))

        except Exception:
            pass
        time.sleep(DELAY_BETWEEN)

    return found


def _crawl_arxiv(search_url, category, limit=30):
    found = []
    try:
        r = requests.get(search_url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        soup = BeautifulSoup(r.text, "lxml")
        for li in soup.select("li.arxiv-result")[:limit]:
            title_tag = li.select_one("p.title")
            pdf_link  = li.select_one('a[href*="/pdf/"]')
            if pdf_link:
                pdf_url = pdf_link["href"]
                if "arxiv.org" not in pdf_url:
                    pdf_url = "https://arxiv.org" + pdf_url
                if not pdf_url.endswith(".pdf"):
                    pdf_url += ".pdf"
                title = title_tag.get_text(strip=True)[:120] if title_tag else title_from_url(pdf_url)
                found.append({"url": pdf_url, "category": category, "title": title, "kind": "pdf"})
    except Exception:
        pass
    return found


def download_pdf(entry, out_dir):
    url   = entry["url"]
    title = entry["title"]
    is_web = entry.get("kind") == "web"
    # safe filename — no regex needed; the URL hash keeps two sources with the same title apart
    safe  = "".join(c if c.isalnum() or c in " _-" else "_"
                    for c in f"{entry['category']}___{title}")[:90]
    uid   = hashlib.md5(url.encode()).hexdigest()[:8]
    fname = safe + "_" + uid + (".html" if is_web else ".pdf")
    fpath = out_dir / fname

    for cached in (fpath, fpath.with_suffix(".html")):
        if cached.exists() and cached.stat().st_size > 1024:
            return True, cached, "cached"

    try:
        r = requests.get(url, headers=HEADERS if is_web else PDF_HEADERS,
                         timeout=DOWNLOAD_TIMEOUT, allow_redirects=True, stream=True)
        ctype = r.headers.get("content-type", "")
        if r.status_code == 200:
            size = int(r.headers.get("content-length") or 0)
            if size > MAX_PDF_MB * 1024 * 1024:
                return False, fpath, "too_large"
            content = b"".join(r.iter_content(8192))
            if len(content) > MAX_PDF_MB * 1024 * 1024:
                return False, fpath, "too_large"
            if is_web:
                kind = "web"
            elif content[:5] == b"%PDF-" or "pdf" in ctype.lower():
                kind = "pdf"
            else:
                kind = "html"          # a "PDF" link that returned a web page
                fpath = fpath.with_suffix(".html")
            fpath.write_bytes(content)
            return True, fpath, kind
        return False, fpath, "http_" + str(r.status_code)
    except Exception as e:
        return False, fpath, "err_" + str(e)[:40]


# ─────────────────────────────────────────────────────────────────────────────
# TEXT EXTRACTION + CHUNKING
# ─────────────────────────────────────────────────────────────────────────────

def html_to_text(raw):
    """Main text of a web page, without scripts, menus, headers and footers."""
    soup = BeautifulSoup(raw, "lxml")
    for t in soup(["script", "style", "noscript", "nav", "header", "footer",
                   "aside", "form", "iframe", "svg"]):
        t.decompose()
    for t in soup.select(_NOISE_SELECTORS):      # [M3] wiki / CMS boilerplate
        t.decompose()
    for hd in soup.find_all(["h2", "h3"]):       # [M3] stop at the reference / external-link sections of wiki pages
        if hd.get_text(" ", strip=True).lower().replace("[edit]", "").strip() in _TAIL_SECTIONS:
            for sib in list(hd.find_all_next()):
                sib.decompose()
            hd.decompose()
            break
    main = soup.find("main") or soup.find("article") or soup.body or soup
    return clean_text(main.get_text(separator="\n", strip=True))


# [M3] Cleaning: citation lists, edit links, navigation boxes and "Find sources" banners are removed before chunking,
# so answers quote content instead of "Retrieved 1 September 2016 . ^".
_NOISE_SELECTORS = ",".join([".mw-editsection", "sup.reference", ".reference", ".reflist", ".references", ".mw-references-wrap",
                             ".navbox", ".vertical-navbox", ".ambox", ".hatnote", ".catlinks", ".noprint", ".sistersitebox", ".toc", "#toc",
                             ".printfooter", ".mw-jump-link", ".metadata", "[role=navigation]", ".breadcrumb"])
_TAIL_SECTIONS = {"references", "notes", "external links", "further reading", "sources", "citations", "bibliography", "notes and references"}
_CITE_LINE = re.compile(r"(^\s*(\^|↑|\[\s*edit\s*\]|v t e\s*$|Find sources:)|Retrieved (on )?\d|Archived from the original|"
                        r"^\s*ISBN[ -]?\d|\bdoi:\s*10\.|^\s*\[\d+\]\s*$|^\s*Jump to (navigation|search))", re.I)


def clean_text(text):
    """[M3] Drop citation / navigation lines and empty lines."""
    return "\n".join(l.strip() for l in text.split("\n") if l.strip() and not _CITE_LINE.search(l))


def extract_text(fpath):
    if fpath.suffix.lower() == ".html":
        try:
            return html_to_text(fpath.read_bytes())
        except Exception:
            return ""
    try:
        import fitz
        doc  = fitz.open(str(fpath))
        text = "\n".join(p.get_text() for p in doc)
        doc.close()
        return text
    except Exception:
        pass
    try:
        return html_to_text(fpath.read_bytes())
    except Exception:
        return ""


# No personal data in the knowledge base: e-mail addresses and phone numbers are masked.
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_PHONE_RE = re.compile(r"(?i)\b(?:tel|phone|mobile|mob|fax|whatsapp)\b\.?\s*(?:no\.?|number)?\s*[:.]?\s*\+?[\d][\d\s().-]{6,}\d")


def redact_pii(text):
    text = _EMAIL_RE.sub("[email removed]", text)
    return _PHONE_RE.sub("[phone removed]", text)


def text_fingerprint(text):
    """Same document under two URLs -> same fingerprint (used to remove duplicates)."""
    norm = " ".join(re.findall(r"[a-z0-9]+", text.lower()))
    return hashlib.md5(norm[:20000].encode()).hexdigest()


def chunk_text(text, title, source_url,
               chunk_words=CHUNK_WORDS, overlap=CHUNK_OVERLAP):
    words  = text.split()
    step   = chunk_words - overlap
    chunks = []
    for i in range(0, max(1, len(words) - overlap), step):
        piece = " ".join(words[i: i + chunk_words])
        if len(piece) > 80:
            cid = hashlib.md5((source_url + str(i)).encode()).hexdigest()[:12]
            chunks.append({
                "chunk_id": cid,
                "text":     piece,
                "title":    title,
                "source":   source_url,
                "offset":   i,
            })
    return chunks


# ─────────────────────────────────────────────────────────────────────────────
# RAG INDEX BUILD  (matches existing RAG notebook format exactly)
# ─────────────────────────────────────────────────────────────────────────────

def build_rag_index(chunks, out_base, project_key):
    import numpy as np
    import faiss
    from sentence_transformers import SentenceTransformer
    from rank_bm25 import BM25Okapi

    faiss_dir = out_base / "faiss_indexes"
    bm25_dir  = out_base / "bm25_indexes"
    faiss_dir.mkdir(parents=True, exist_ok=True)
    bm25_dir.mkdir(parents=True, exist_ok=True)

    ST_CACHE = "/content/.cache/sentence_transformers"
    print("  Loading sentence-transformer (all-MiniLM-L6-v2)...")
    model = SentenceTransformer("all-MiniLM-L6-v2", cache_folder=ST_CACHE)

    texts = [c["text"] for c in chunks]
    print(f"  Encoding {len(texts)} chunks...")
    embs  = model.encode(texts, show_progress_bar=True,
                         batch_size=64, convert_to_numpy=True).astype("float32")

    faiss.normalize_L2(embs)
    index = faiss.IndexFlatIP(embs.shape[1])
    index.add(embs)

    idx_path  = str(faiss_dir / (project_key + "_faiss.index"))
    meta_path = str(faiss_dir / (project_key + "_chunks_meta.json"))
    bm25_path = str(bm25_dir  / (project_key + "_bm25.pkl"))

    faiss.write_index(index, idx_path)
    with open(meta_path, "w") as f:
        json.dump(chunks, f)

    tokenized = [c["text"].lower().split() for c in chunks]
    bm25      = BM25Okapi(tokenized)
    with open(bm25_path, "wb") as f:
        pickle.dump({"bm25": bm25, "chunks": chunks}, f)

    print("  FAISS index:  " + idx_path)
    print("  Chunk meta:   " + meta_path)
    print("  BM25 index:   " + bm25_path)
    return index.ntotal


# ─────────────────────────────────────────────────────────────────────────────
# MAIN RUNNER
# ─────────────────────────────────────────────────────────────────────────────

def preflight_seeds(seeds, out_base):
    """[M3] Validate source accessibility before ingestion: HTTP 200 and 50+ words of text (or a PDF).
    Writes seed_check.csv and returns the seeds that passed."""
    import csv, concurrent.futures as cf

    def check(item):
        cat, url = item
        try:
            r = requests.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT + 10, allow_redirects=True)
            if r.status_code != 200:
                return cat, url, False, "http_" + str(r.status_code), 0
            if r.content[:5] == b"%PDF-" or "pdf" in r.headers.get("content-type", "").lower():
                return cat, url, True, "pdf", len(r.content)
            words = len(html_to_text(r.content).split())
            if "arxiv.org/search" in url:      # search pages: the PDFs are what counts
                return cat, url, True, "ok", words
            return cat, url, words >= 50, "ok" if words >= 50 else "too_short", words
        except Exception as e:
            return cat, url, False, "err_" + type(e).__name__, 0

    with cf.ThreadPoolExecutor(max_workers=PREFLIGHT_WORKERS) as ex:
        res = list(tqdm(ex.map(check, seeds), total=len(seeds), desc="  Pre-flight"))
    with open(out_base / "seed_check.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["category", "url", "ok", "status", "words_or_bytes"]); w.writerows(res)
    ok = [(c, u) for c, u, good, _, _ in res if good]
    print("  Pre-flight: " + str(len(ok)) + "/" + str(len(seeds)) + " seeds reachable"
          + ("" if len(ok) == len(seeds) else " | skipped: " + ", ".join(u for c, u, good, _, _ in res if not good)[:600]))
    return ok, res


def run_project(project_name, project_key, seeds, out_base_str):
    out_base = Path(out_base_str)
    out_base.mkdir(parents=True, exist_ok=True)
    seed_check = []
    if PREFLIGHT_CHECK:
        seeds, seed_check = preflight_seeds(seeds, out_base)
    pdf_dir  = out_base / "rag_pdfs"
    pdf_dir.mkdir(parents=True, exist_ok=True)

    print("\n" + "=" * 65)
    print("  PROJECT: " + project_name)
    print("  Seed sites: " + str(len(seeds)))
    print("  Output: " + str(out_base))
    print("=" * 65)

    # Step 1 — crawl
    print("\n  [1/4] Crawling " + str(len(seeds)) + " seed sites for PDFs...")
    all_found  = []
    visited_gl = set()
    for cat, seed_url in tqdm(seeds, desc="  Crawling"):
        found = discover_pdfs(seed_url, cat, visited=visited_gl)
        all_found.extend(found)
        print("    " + cat[:20].ljust(22) + "| " + seed_url[:50] +
              " -> " + str(len(found)) + " PDFs")

    # Deduplicate (normalised URL: http/https, www., trailing slash)
    seen, unique = set(), []
    for e in all_found:
        k = _norm_url(e["url"])
        if k not in seen:
            seen.add(k)
            unique.append(e)
    webs = [e for e in unique if e.get("kind") == "web"]
    pdfs = [e for e in unique if e.get("kind") != "web"][:MAX_TOTAL_PDFS]
    unique = webs + pdfs
    print("\n  Unique sources discovered: " + str(len(unique)) +
          " (websites: " + str(len(webs)) + ", PDFs: " + str(len(pdfs)) + ")")

    # Step 2 — download
    print("\n  [2/4] Downloading " + str(len(unique)) + " websites and PDFs...")
    manifest = {
        "project": project_name,
        "generated_at": datetime.now().isoformat(),
        "total_discovered": len(unique),
        "seeds_checked": len(seed_check), "seeds_reachable": len(seeds),
        "seeds_failed": [{"url": u, "status": st} for c, u, good, st, _ in seed_check if not good],
        "downloaded": 0, "cached": 0, "failed": 0,
        "files": [],
    }
    for entry in tqdm(unique, desc="  Downloading"):
        ok, fpath, status = download_pdf(entry, pdf_dir)
        entry["local_path"] = str(fpath)
        entry["status"]     = status
        if ok:
            if status == "cached":
                manifest["cached"] += 1
            else:
                manifest["downloaded"] += 1
        else:
            manifest["failed"] += 1
        manifest["files"].append(entry)
        time.sleep(DELAY_BETWEEN)

    with open(out_base / "manifest.json", "w") as f:
        json.dump(manifest, f, indent=2)

    print("  Downloaded: " + str(manifest["downloaded"]) +
          " | Cached: " + str(manifest["cached"]) +
          " | Failed: " + str(manifest["failed"]))

    # Step 3 — extract, clean, remove duplicates, chunk
    print("\n  [3/4] Extracting text, removing duplicates and chunking...")
    all_chunks, docs, fingerprints = [], [], set()
    dup_count = short_count = 0
    ok_files   = [e for e in manifest["files"]
                  if e.get("status") in ("pdf", "html", "web", "cached")]
    for entry in tqdm(ok_files, desc="  Chunking"):
        fpath = Path(entry.get("local_path", ""))
        if not fpath.exists() or fpath.stat().st_size < 512:
            continue
        text = redact_pii(extract_text(fpath))
        if len(text.split()) < 50:
            short_count += 1
            continue
        fp = text_fingerprint(text)
        if fp in fingerprints:
            dup_count += 1
            continue
        fingerprints.add(fp)
        doc_chunks = chunk_text(text, entry["title"], entry["url"])
        all_chunks.extend(doc_chunks)
        kind = "web" if entry.get("kind") == "web" else "pdf"
        docs.append({"title": entry["title"], "content": text, "source": entry["url"],
                     "category": entry["category"], "kind": kind})
        entry["words"], entry["chunks"], entry["used"] = len(text.split()), len(doc_chunks), True
    n_web = sum(d["kind"] == "web" for d in docs)
    n_pdf = len(docs) - n_web
    print("  Sources kept: " + str(len(docs)) + " (websites: " + str(n_web) +
          ", PDFs: " + str(n_pdf) + ") | duplicates removed: " + str(dup_count) +
          " | too short: " + str(short_count))
    print("  Total chunks: " + str(len(all_chunks)))

    # Hand the crawled documents to the notebook: synthetic_kb/pdf_extracted.jsonl is
    # merged with freight_kb.jsonl into all_chunks.jsonl, the FAISS/BM25 index and kb_export.json.
    kb_dir = out_base / "synthetic_kb"
    kb_dir.mkdir(parents=True, exist_ok=True)
    with open(kb_dir / "pdf_extracted.jsonl", "w", encoding="utf-8") as f:
        for d in docs:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")
    print("  Documents for the RAG notebook: " + str(kb_dir / "pdf_extracted.jsonl"))

    import csv
    with open(out_base / "sources_collected.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["kind", "category", "title", "url", "words", "chunks"])
        for e in manifest["files"]:
            if e.get("used"):
                w.writerow(["web" if e.get("kind") == "web" else "pdf", e["category"],
                            e["title"], e["url"], e["words"], e["chunks"]])
    manifest.update({"sources_used": len(docs), "websites_used": n_web, "pdfs_used": n_pdf,
                     "duplicates_removed": dup_count, "chunks": len(all_chunks)})
    with open(out_base / "manifest.json", "w") as f:
        json.dump(manifest, f, indent=2)

    # Step 4 — index
    n = 0
    if not all_chunks:
        print("\n  [4/4] No chunks to index")
    elif BUILD_INDEX_HERE:
        print("\n  [4/4] Building FAISS + BM25 indexes...")
        n = build_rag_index(all_chunks, out_base, project_key)
    else:
        print("\n  [4/4] FAISS + BM25 are built by the next notebook cells "
              "(synthetic KB + these " + str(len(docs)) + " sources in one index).")
    status = "OK" if len(docs) >= TARGET_SOURCES else "BELOW TARGET - add seeds and run again"
    print("\n  " + project_name + " COMPLETE: " + str(len(docs)) + " sources / " +
          str(len(all_chunks)) + " chunks  [target " + str(TARGET_SOURCES) + "+: " + status + "]")
    return manifest


# ─────────────────────────────────────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    DRIVE = Path("/content/drive/MyDrive")

    if DRIVE.exists():

        FQ_BASE = str(DRIVE / FQ_DRIVE_FOLDER)
        print("Google Drive mounted.")

        print("FreightQuote -> " + FQ_BASE)
    else:

        FQ_BASE = "/content/FreightQuote_AI"
        print("Drive not mounted — saving locally.")


    print("FreightQuote seed sites: " + str(len(FREIGHT_SEEDS)))


    fq_m = run_project("FreightQuote AI", "freight",   FREIGHT_SEEDS,   FQ_BASE)

    print("\n" + "=" * 65)
    print("  FINAL SUMMARY")
    print("=" * 65)
    for nm, m in [("FreightQuote", fq_m)]:
        print("  " + nm.ljust(14) +
              " | Found: " + str(m["total_discovered"]) +
              " | DL: " + str(m["downloaded"]) +
              " | Cached: " + str(m["cached"]) +
              " | Failed: " + str(m["failed"]))
        print("  " + "".ljust(14) +
              " | Sources used: " + str(m.get("sources_used", 0)) +
              " (websites " + str(m.get("websites_used", 0)) +
              ", PDFs " + str(m.get("pdfs_used", 0)) + ")" +
              " | Chunks: " + str(m.get("chunks", 0)))
    print("=" * 65)
