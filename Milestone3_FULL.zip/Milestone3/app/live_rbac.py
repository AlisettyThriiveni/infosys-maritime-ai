"""Capability RBAC for the live layer. Menu-level RBAC stays in each app's rbac.py; this gates actions inside the Command Center."""
CAPS = {  # view, resolve, approve, run, feeder, admin
 "Admin": {"view", "resolve", "approve", "run", "feeder", "admin", "quote"},
 "Franchise Owner": {"view", "resolve", "approve", "run", "feeder"},
 "Operations Manager": {"view", "resolve", "approve", "run", "feeder", "quote"},
 "Store Manager": {"view", "resolve"},
 "Freight Broker": {"view", "resolve", "quote"},
 "Auditor": {"view"},
 "Staff": {"view"},
 "Customer": {"quote"},
}
SCOPED = {"Store Manager", "Staff"}                 # these roles only see actions for their assigned outlet
def norm(role):
    r = (role or "").strip().lower()
    for k in CAPS:
        if k.lower() == r: return k
    return "Admin" if "admin" in r else "Customer"
def can(role, cap): return cap in CAPS.get(norm(role), set())
def scope_for(email):
    from live_engine import conn
    try:
        c = conn(); c.execute("CREATE TABLE IF NOT EXISTS user_scope(email TEXT PRIMARY KEY, entity TEXT)")
        r = c.execute("SELECT entity FROM user_scope WHERE email=?", ((email or "").lower(),)).fetchone(); return r[0] if r else None
    except Exception: return None
def set_scope(email, entity):
    from live_engine import conn
    c = conn(); c.execute("CREATE TABLE IF NOT EXISTS user_scope(email TEXT PRIMARY KEY, entity TEXT)"); c.execute("INSERT OR REPLACE INTO user_scope VALUES(?,?)", (email.lower(), entity)); c.commit()
