"""Authentication for the web app: PBKDF2 password hashing, progressive lockout (5 min, 15 min, permanent), security-question reset, HttpOnly JWT cookie sessions. Independent of any UI framework."""
import re, os, hmac, hashlib, secrets, sqlite3, datetime, threading
import jwt
from config import DB_PATH, JWT_SECRET_KEY, ADMIN_EMAIL_ID, ADMIN_PASSWORD, KIND, DEMO_MODE
QUESTIONS = ["What was the name of your first pet?", "What is your mother's maiden name?", "What was the name of your first school?", "What city were you born in?", "What is your favorite book/movie?"]
LOCK_LADDER = {3: 300, 4: 900}; PERMA = 5
ROLES = {"Franchise": ["Admin", "Franchise Owner", "Store Manager", "Staff", "Customer"], "Freight": ["Admin", "Operations Manager", "Freight Broker", "Auditor", "Customer"]}[KIND]
DEMO = {"Franchise": [("owner", "owner@infosys.com", "Franchise Owner"), ("manager", "manager@infosys.com", "Store Manager"), ("staff", "staff@infosys.com", "Staff"), ("customer", "customer@infosys.com", "Customer")],
        "Freight": [("ops", "ops@infosys.com", "Operations Manager"), ("broker", "broker@infosys.com", "Freight Broker"), ("auditor", "auditor@infosys.com", "Auditor"), ("customer", "customer@infosys.com", "Customer")]}[KIND]
_L = threading.RLock()
def _c():
    c = sqlite3.connect(DB_PATH, timeout=30); c.execute("PRAGMA journal_mode=WAL;"); c.row_factory = sqlite3.Row; return c
def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(8); return f"pbkdf2${salt}${hashlib.pbkdf2_hmac('sha256', pw.encode(), salt.encode(), 120_000).hex()}"
def check_pw(pw, h):
    try: _, salt, _ = h.split("$"); return hmac.compare_digest(hash_pw(pw, salt), h)
    except Exception: return False
def init():
    with _L, _c() as c:
        c.execute("CREATE TABLE IF NOT EXISTS app_users(email TEXT PRIMARY KEY, username TEXT UNIQUE, pw TEXT, role TEXT, sq TEXT, sa TEXT, failed INT DEFAULT 0, lock_until TEXT, status TEXT DEFAULT 'active', created TEXT, last_login TEXT)")
        def add(u, e, r, pw):
            if not c.execute("SELECT 1 FROM app_users WHERE email=?", (e,)).fetchone(): c.execute("INSERT INTO app_users(email,username,pw,role,sq,sa,created) VALUES(?,?,?,?,?,?,?)", (e, u, hash_pw(pw), r, QUESTIONS[0], hashlib.sha256(b"infosys").hexdigest(), now()))
        add("admin", ADMIN_EMAIL_ID, "Admin", ADMIN_PASSWORD)
        for u, e, r in (DEMO if DEMO_MODE else []): add(u, e, r, "Demo@1234")
def now(): return datetime.datetime.now().isoformat(timespec="seconds")
def strength(pw):
    if not pw or len(pw) < 8 or not re.search(r"[A-Za-z]", pw) or not re.search(r"\d", pw): return False, "Password too weak: at least 8 characters with a letter and a digit."
    return True, "ok"
def register(username, email, pw, role, sq, sa):
    if not (username and email and pw and sa.strip()): return False, "Fill in every field."
    ok, m = strength(pw)
    if not ok: return False, m
    if role not in ("Customer", "Staff"): role = "Customer"          # self-service sign-up never grants an elevated role; Admin promotes users
    try:
        with _L, _c() as c: c.execute("INSERT INTO app_users(email,username,pw,role,sq,sa,created) VALUES(?,?,?,?,?,?,?)", (email.lower().strip(), username.strip(), hash_pw(pw), role, sq, hashlib.sha256(sa.strip().lower().encode()).hexdigest(), now()))
        return True, "Account created. Sign in."
    except sqlite3.IntegrityError: return False, "An account with this email or username already exists."
def login(login_id, pw):
    """-> (ok, message, user_dict|None)"""
    lid = (login_id or "").strip().lower()
    with _L, _c() as c:
        r = c.execute("SELECT * FROM app_users WHERE lower(email)=? OR lower(username)=?", (lid, lid)).fetchone()
        if not r: return False, "No such user.", None
        if r["status"] == "locked": return False, "Account locked after 5 failed attempts. An Admin must unlock it.", None
        if r["lock_until"] and now() < r["lock_until"]: return False, f"Temporarily locked until {r['lock_until'][11:16]} UTC.", None
        if check_pw(pw, r["pw"]):
            c.execute("UPDATE app_users SET failed=0, lock_until=NULL, last_login=? WHERE email=?", (now(), r["email"])); return True, "ok", {"email": r["email"], "username": r["username"], "role": r["role"]}
        n = (r["failed"] or 0) + 1; lock = None; st = r["status"]
        if n >= PERMA: st = "locked"
        elif n in LOCK_LADDER: lock = (datetime.datetime.now() + datetime.timedelta(seconds=LOCK_LADDER[n])).isoformat(timespec="seconds")
        c.execute("UPDATE app_users SET failed=?, lock_until=?, status=? WHERE email=?", (n, lock, st, r["email"]))
        return False, f"Wrong password. {max(0, PERMA - n)} attempt(s) left before lockout.", None
def question_for(email):
    with _c() as c: r = c.execute("SELECT sq FROM app_users WHERE lower(email)=?", (email.lower().strip(),)).fetchone(); return r["sq"] if r else None
def reset(email, answer, new_pw):
    ok, m = strength(new_pw)
    if not ok: return False, m
    with _L, _c() as c:
        r = c.execute("SELECT sa FROM app_users WHERE lower(email)=?", (email.lower().strip(),)).fetchone()
        if not r or r["sa"] != hashlib.sha256(answer.strip().lower().encode()).hexdigest(): return False, "Security answer does not match."
        c.execute("UPDATE app_users SET pw=?, failed=0, lock_until=NULL, status='active' WHERE lower(email)=?", (hash_pw(new_pw), email.lower().strip())); return True, "Password reset. Sign in."
def users():
    with _c() as c: return [dict(r) for r in c.execute("SELECT email, username, role, status, failed, last_login, created FROM app_users ORDER BY created")]
def set_role(email, role):
    with _L, _c() as c: c.execute("UPDATE app_users SET role=? WHERE email=?", (role, email))
def unlock(email):
    with _L, _c() as c: c.execute("UPDATE app_users SET status='active', failed=0, lock_until=NULL WHERE email=?", (email,))
import time as _time
def revoke(email):
    with _L, _c() as c:
        c.execute("CREATE TABLE IF NOT EXISTS revoked_before(email TEXT PRIMARY KEY, ts REAL)"); c.execute("INSERT OR REPLACE INTO revoked_before VALUES(?,?)", (email, _time.time()))
def token(u): return jwt.encode({**u, "iatf": _time.time(), "iat": datetime.datetime.utcnow(), "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=10)}, JWT_SECRET_KEY, algorithm="HS256")
def decode(t):
    try:
        p = jwt.decode(t, JWT_SECRET_KEY, algorithms=["HS256"])
        with _c() as c:
            c.execute("CREATE TABLE IF NOT EXISTS revoked_before(email TEXT PRIMARY KEY, ts REAL)")
            r = c.execute("SELECT role, status FROM app_users WHERE email=?", (p["email"],)).fetchone(); rv = c.execute("SELECT ts FROM revoked_before WHERE email=?", (p["email"],)).fetchone()
        if rv and float(p.get("iatf") or 0) <= float(rv[0]): return None
        return {"email": p["email"], "username": p["username"], "role": r["role"]} if r and r["status"] != "locked" else None      # role is re-read so an Admin's change applies at once
    except Exception: return None

# ---------------------------------------------------------------- e-mail OTP, profile, preferences, invitations
import mailer
def _otp_init():
    with _L, _c() as c:
        c.execute("CREATE TABLE IF NOT EXISTS otp(email TEXT, purpose TEXT, code TEXT, expires TEXT, tries INT DEFAULT 0, PRIMARY KEY(email, purpose))")
        c.execute("CREATE TABLE IF NOT EXISTS user_prefs(email TEXT PRIMARY KEY, lang TEXT DEFAULT 'English', email_alerts INT DEFAULT 0, daily_digest INT DEFAULT 0, last_digest TEXT)")
_otp_init()
def send_otp(email, purpose):
    """Mails a 6-digit code (valid 10 min). Returns (ok, message). Without SMTP settings it says so and the caller falls back to the security question."""
    email = (email or "").lower().strip()
    if "@" not in email: return False, "Enter a valid e-mail address."
    if not mailer.configured(): return False, "E-mail is not configured on this server, so codes cannot be sent. Use the security question instead."
    if purpose == "reset":
        with _c() as c:
            if not c.execute("SELECT 1 FROM app_users WHERE lower(email)=?", (email,)).fetchone(): return True, "If the account exists, a code was sent."
    code = f"{secrets.randbelow(10**6):06d}"; exp = (datetime.datetime.now() + datetime.timedelta(minutes=10)).isoformat(timespec="seconds")
    with _L, _c() as c: c.execute("INSERT OR REPLACE INTO otp(email,purpose,code,expires,tries) VALUES(?,?,?,?,0)", (email, purpose, hashlib.sha256(code.encode()).hexdigest(), exp))
    ok, m = mailer.send(email, f"Your verification code: {code}", f"Your {KIND} platform verification code is {code}. It expires in 10 minutes. If you did not ask for it, ignore this message.")
    return ok, ("Code sent to " + email + ". It expires in 10 minutes.") if ok else m
def check_otp(email, purpose, code):
    email = (email or "").lower().strip()
    with _L, _c() as c:
        r = c.execute("SELECT * FROM otp WHERE email=? AND purpose=?", (email, purpose)).fetchone()
        if not r or now() > r["expires"] or (r["tries"] or 0) >= 5: return False
        c.execute("UPDATE otp SET tries=tries+1 WHERE email=? AND purpose=?", (email, purpose))
        if hmac.compare_digest(hashlib.sha256(str(code).strip().encode()).hexdigest(), r["code"]): c.execute("DELETE FROM otp WHERE email=? AND purpose=?", (email, purpose)); return True
    return False
def reset_with_otp(email, code, new_pw):
    ok, m = strength(new_pw)
    if not ok: return False, m
    if not check_otp(email, "reset", code): return False, "The code is wrong or has expired."
    with _L, _c() as c: c.execute("UPDATE app_users SET pw=?, failed=0, lock_until=NULL, status='active' WHERE lower(email)=?", (hash_pw(new_pw), email.lower().strip()))
    return True, "Password reset. Sign in."
def register_verified(username, email, pw, role, sq, sa, code):
    if mailer.configured() and not check_otp(email, "register", code): return False, "Enter the 6-digit code that was e-mailed to you."
    return register(username, email, pw, role, sq, sa or "-")
def profile(email):
    with _c() as c:
        r = c.execute("SELECT email, username, role, created, last_login FROM app_users WHERE lower(email)=?", (email.lower(),)).fetchone(); p = c.execute("SELECT * FROM user_prefs WHERE email=?", (email.lower(),)).fetchone()
    d = dict(r) if r else {}; d["prefs"] = dict(p) if p else {"lang": "English", "email_alerts": 0, "daily_digest": 0}; return d
def set_prefs(email, **kw):
    with _L, _c() as c:
        c.execute("INSERT OR IGNORE INTO user_prefs(email) VALUES(?)", (email.lower(),))
        for k in ("lang", "email_alerts", "daily_digest", "last_digest"):
            if k in kw: c.execute(f"UPDATE user_prefs SET {k}=? WHERE email=?", (kw[k], email.lower()))
def update_name(email, username):
    username = (username or "").strip()
    if len(username) < 3: return False, "User name needs at least 3 characters."
    try:
        with _L, _c() as c: c.execute("UPDATE app_users SET username=? WHERE lower(email)=?", (username, email.lower()))
        return True, "Saved."
    except sqlite3.IntegrityError: return False, "That user name is taken."
def change_password(email, old, new):
    ok, m = strength(new)
    if not ok: return False, m
    with _L, _c() as c:
        r = c.execute("SELECT pw FROM app_users WHERE lower(email)=?", (email.lower(),)).fetchone()
        if not r or not check_pw(old, r["pw"]): return False, "Current password is wrong."
        c.execute("UPDATE app_users SET pw=? WHERE lower(email)=?", (hash_pw(new), email.lower())); return True, "Password changed."
def invite(email, username, role):
    """Admin creates an account and e-mails a one-time password (shown to the admin when e-mail is not configured)."""
    if role not in ROLES: return False, "Unknown role."
    email = email.lower().strip(); tmp = "Tmp-" + secrets.token_urlsafe(6)
    try:
        with _L, _c() as c: c.execute("INSERT INTO app_users(email,username,pw,role,sq,sa,created) VALUES(?,?,?,?,?,?,?)", (email, username.strip(), hash_pw(tmp), role, QUESTIONS[0], hashlib.sha256(secrets.token_hex(8).encode()).hexdigest(), now()))
    except sqlite3.IntegrityError: return False, "An account with this email or user name already exists."
    ok, m = mailer.send(email, "You have been invited", f"An account was created for you as {role}.\nSign in with {email} and the temporary password {tmp}, then change it under My Profile.")
    return True, (f"Invitation e-mailed to {email}." if ok else f"Account created. E-mail is not configured, so give them this temporary password yourself: {tmp}")
def deactivate(email, on=True):
    with _L, _c() as c: c.execute("UPDATE app_users SET status=? WHERE lower(email)=?", ("locked" if on else "active", email.lower()))


# ---------------------------------------------------------------------------------------------------
# [M3] Bridge to the Milestone 2 account store. Sign-in uses auth.py (table `users`, bcrypt), so the reference
# helpers that list or change accounts (Admin → Users tab, profile, e-mail digest) read and write that same table.
# ---------------------------------------------------------------------------------------------------
def _m2():
    import auth as _A; return _A
def users():
    with _m2().db() as c:
        return [{"email": r["email"], "username": r["username"], "role": r["role"], "status": r["account_status"] or "active", "failed": r["failed_attempts"] or 0,
                 "last_login": r["last_login"], "created": r["created_at"]} for r in c.execute("SELECT * FROM users ORDER BY created_at")]
def set_role(email, role):
    with _m2().db() as c: c.execute("UPDATE users SET role=? WHERE lower(email)=lower(?)", (role, email))
def unlock(email):
    with _m2().db() as c:
        c.execute("UPDATE users SET account_status='active', failed_attempts=0, lock_until=NULL WHERE lower(email)=lower(?)", (email,)); c.execute("DELETE FROM auth_lockouts WHERE lower(email)=lower(?)", (email,))
def deactivate(email, on=True):
    with _m2().db() as c: c.execute("UPDATE users SET account_status=? WHERE lower(email)=lower(?)", ("locked" if on else "active", email))
def profile(email):
    with _m2().db() as c:
        r = c.execute("SELECT email, username, role, created_at created, last_login FROM users WHERE lower(email)=lower(?)", (email,)).fetchone()
    with _c() as c2: p = c2.execute("SELECT * FROM user_prefs WHERE email=?", (email.lower(),)).fetchone()
    d = dict(r) if r else {}; d["prefs"] = dict(p) if p else {"lang": "English", "email_alerts": 0, "daily_digest": 0}; return d
def update_name(email, username):
    username = (username or "").strip()
    if len(username) < 3: return False, "User name needs at least 3 characters."
    try:
        with _m2().db() as c: c.execute("UPDATE users SET username=? WHERE lower(email)=lower(?)", (username, email))
        return True, "Saved."
    except sqlite3.IntegrityError: return False, "That user name is taken."
def change_password(email, old, new):
    A = _m2(); err = A._password_error(new, new)
    if err: return False, err
    with A.db() as c:
        r = c.execute("SELECT password_hash FROM users WHERE lower(email)=lower(?)", (email,)).fetchone()
        if not r or not A._check(old, r["password_hash"]): return False, "Current password is wrong."
        c.execute("UPDATE users SET password_hash=? WHERE lower(email)=lower(?)", (A._hash(new), email)); return True, "Password changed."
def invite(email, username, role):
    if role not in ROLES: return False, "Unknown role."
    if role == "Admin": return False, "Create the user with a standard role; the Admin role is reserved."
    A = _m2(); email = (email or "").lower().strip(); err = A._email_error(email)
    if err: return False, err
    tmp = "Tmp-" + secrets.token_urlsafe(6) + "9a!"; cid = ("CUST-" + secrets.token_hex(6).upper()) if role == "Customer" else None
    try:
        with A.db() as c:
            c.execute("INSERT INTO users(username,email,password_hash,role,account_status,customer_id) VALUES(?,?,?,?,'active',?)", ((username or email.split("@")[0]).strip(), email, A._hash(tmp), role, cid))
            if cid: c.execute("INSERT OR IGNORE INTO customers(customer_id,name,industry,priority_tier,credit_risk) VALUES(?,?, 'General', 'Standard', 0.25)", (cid, username or cid))
    except sqlite3.IntegrityError: return False, "An account with this email or user name already exists."
    ok, m = mailer.send(email, "You have been invited", f"An account was created for you as {role}.\nSign in with {email} and the temporary password {tmp}, then change it under My Profile.")
    return True, (f"Invitation e-mailed to {email}." if ok else f"Account created. E-mail is not configured, so give them this temporary password yourself: {tmp}")
