"""Unified FastAPI authentication for FreightQuote AI.
All account data is stored in the existing FreightQuote SQLite database.
No separate Streamlit process or public URL is used.
"""
import os, re, time, secrets, smtplib, sqlite3, uuid
from contextlib import contextmanager
from email.message import EmailMessage
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt
from fastapi import APIRouter, Request, Response, HTTPException
from config import DB_PATH, JWT_SECRET_KEY, EMAIL_ID, EMAIL_PASSWORD, ADMIN_EMAIL_ID

router = APIRouter(prefix="/api/auth", tags=["authentication"])
COOKIE_NAME = "freightquote_session"
SESSION_HOURS = 8
MAX_FAILED_ATTEMPTS = 3
LOCKOUT_DURATION_SECONDS = 300
MAX_TEMPORARY_LOCKOUTS = 5
OTP_EXPIRY_MINUTES = 5
OTP_MAX_ATTEMPTS = 3
OTP_RESEND_SECONDS = 60
ADMIN_EMAIL = str(ADMIN_EMAIL_ID or "admin@infosys.com").strip().lower()
SECURITY_QUESTIONS = (
    "What is your pet name?",
    "What is your mother's maiden name?",
    "What is your favourite city?",
)

@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def _hash(value):
    return bcrypt.hashpw(str(value).encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

def _check(value, stored):
    if not stored:
        return False
    try:
        if str(stored).startswith(("$2a$", "$2b$", "$2y$")):
            return bcrypt.checkpw(str(value).encode("utf-8"), str(stored).encode("utf-8"))
    except Exception:
        return False
    # Compatibility for the original FreightQuote demo seed accounts.
    return secrets.compare_digest(str(value), str(stored))

def _password_error(password, confirm):
    if not password:
        return "Password is required."
    if re.search(r"\s", password):
        return "Password cannot contain spaces."
    if len(password) < 8:
        return "Password must be at least 8 characters."
    if not re.search(r"[A-Z]", password):
        return "Password must contain an uppercase letter."
    if not re.search(r"[a-z]", password):
        return "Password must contain a lowercase letter."
    if not re.search(r"\d", password):
        return "Password must contain a number."
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        return "Password must contain a special symbol."
    if password != confirm:
        return "Passwords do not match."
    return ""

EMAIL_REGEX = re.compile(
    r"^(?P<local>[A-Za-z0-9_%+-]+(?:\.[A-Za-z0-9_%+-]+)*)@"
    r"(?P<domain>(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\.)+[A-Za-z]{2,})$"
)

def _email_error(email):
    """Standard Email Format Constraints (Syntax):
    - A valid email consists of a local part (prefix), an @ symbol, and a domain name.
    - Local Part: Letters (A-Z, a-z), numbers (0-9), special chars (. _ - % +);
      no leading, trailing, or consecutive dots. Max 64 chars.
    - Domain Part: Domain name and top-level domain (TLD like .com, .org, .net)
      separated by a dot. Labels cannot start/end with hyphen. TLD must be >= 2 letters.
    """
    if not email or not isinstance(email, str):
        return "Email address is required."
    email = email.strip()
    if len(email) > 254:
        return "Email address must be 254 characters or fewer."
    if "@" not in email:
        return "Email address must contain an '@' symbol separating the prefix and domain."
    parts = email.split("@")
    if len(parts) != 2:
        return "Email address must contain exactly one '@' symbol."
    local, domain = parts[0], parts[1]
    if not local:
        return "Email prefix (local part) cannot be empty."
    if len(local) > 64:
        return "Email prefix (local part) cannot exceed 64 characters."
    if local.startswith("."):
        return "Email prefix cannot start with a dot."
    if local.endswith("."):
        return "Email prefix cannot end with a dot."
    if ".." in local:
        return "Email prefix cannot contain consecutive dots."
    if not re.fullmatch(r"[A-Za-z0-9_%+-]+(?:\.[A-Za-z0-9_%+-]+)*", local):
        return "Email prefix contains invalid characters. Only letters, numbers, and special characters (. _ - % +) are allowed."
    if not domain:
        return "Domain name cannot be empty."
    if len(domain) > 253:
        return "Domain name is too long."
    if ".." in domain:
        return "Domain name cannot contain consecutive dots."
    if "." not in domain:
        return "Domain must contain a domain name and a top-level domain (e.g. .com, .org, .net) separated by a dot."
    domain_labels = domain.split(".")
    tld = domain_labels[-1]
    if not re.fullmatch(r"[A-Za-z]{2,}", tld):
        return "Top-level domain (TLD) must be at least 2 alphabetical characters (e.g. .com, .org, .net)."
    for label in domain_labels[:-1]:
        if not label:
            return "Domain labels cannot be empty."
        if label.startswith("-") or label.endswith("-"):
            return "Domain label cannot start or end with a hyphen."
        if not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?", label):
            return "Domain label contains invalid characters."
    if not EMAIL_REGEX.fullmatch(email):
        return "Enter a valid email address matching standard syntax constraints (e.g. user@example.com)."
    return None

def _email_ok(email):
    return _email_error(email) is None

def init_auth():
    """Create authentication tables and add missing columns without replacing FreightQuote data."""
    with db() as conn:
        cols = {r["name"] for r in conn.execute("PRAGMA table_info(users)")}
        migrations = [
            ("username", "ALTER TABLE users ADD COLUMN username TEXT"),
            ("security_question", "ALTER TABLE users ADD COLUMN security_question TEXT"),
            ("security_answer_hash", "ALTER TABLE users ADD COLUMN security_answer_hash TEXT"),
            ("failed_attempts", "ALTER TABLE users ADD COLUMN failed_attempts INTEGER DEFAULT 0"),
            ("lock_until", "ALTER TABLE users ADD COLUMN lock_until REAL DEFAULT NULL"),
            ("account_status", "ALTER TABLE users ADD COLUMN account_status TEXT DEFAULT 'active'"),
            ("customer_id", "ALTER TABLE users ADD COLUMN customer_id TEXT"),
            ("last_login", "ALTER TABLE users ADD COLUMN last_login DATETIME DEFAULT NULL"),
        ]
        for name, ddl in migrations:
            if name not in cols:
                try:
                    conn.execute(ddl)
                except sqlite3.OperationalError:
                    pass

        conn.execute("""
            CREATE TABLE IF NOT EXISTS auth_lockouts (
                email TEXT PRIMARY KEY,
                attempts INTEGER NOT NULL DEFAULT 0,
                last_attempt REAL NOT NULL DEFAULT 0,
                lockout_count INTEGER NOT NULL DEFAULT 0,
                is_permanent INTEGER NOT NULL DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS auth_otps (
                email TEXT PRIMARY KEY,
                otp_hash TEXT NOT NULL,
                expires_at REAL NOT NULL,
                created_at REAL NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0
            )
        """)
        otp_cols = {r["name"] for r in conn.execute("PRAGMA table_info(auth_otps)")}
        if "attempts" not in otp_cols:
            conn.execute("ALTER TABLE auth_otps ADD COLUMN attempts INTEGER NOT NULL DEFAULT 0")
        user_cols = {r["name"] for r in conn.execute("PRAGMA table_info(users)")}
        if "avatar" not in user_cols:
            try: conn.execute("ALTER TABLE users ADD COLUMN avatar TEXT")
            except Exception: pass
        try:
            conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_users_username ON users(username) WHERE username IS NOT NULL")
        except sqlite3.IntegrityError:
            pass
        try:
            conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_users_email ON users(lower(email))")
        except sqlite3.IntegrityError:
            pass

        # Ensure the configured seed operator is always assigned the Admin role.
        conn.execute("UPDATE users SET role='Admin' WHERE lower(email)=?", (ADMIN_EMAIL,))
        # Give existing Customer accounts a stable customer record if they do not have one.
        customer_rows = conn.execute("SELECT id,username,customer_id FROM users WHERE lower(role)='customer'").fetchall()
        for customer in customer_rows:
            if not customer["customer_id"]:
                cid = "CUST-" + str(customer["id"])
                conn.execute("UPDATE users SET customer_id=? WHERE id=?", (cid, customer["id"]))
                conn.execute("INSERT OR IGNORE INTO customers(customer_id,name,industry,priority_tier,credit_risk) VALUES(?,?, 'General', 'Standard', 0.25)", (cid, customer["username"] or cid))

        # Upgrade legacy demo passwords to bcrypt hashes; do not overwrite user passwords.
        for email, username in (
            ("admin@infosys.com", "Administrator"),
            ("broker@infosys.com", "Freight Broker"),
            ("customer@infosys.com", "Customer"),
        ):
            row = conn.execute(
                "SELECT id, username, password_hash FROM users WHERE lower(email)=?",
                (email,),
            ).fetchone()
            if row:
                stored = str(row["password_hash"] or "")
                if stored and not stored.startswith(("$2a$", "$2b$", "$2y$")):
                    conn.execute("UPDATE users SET password_hash=? WHERE id=?", (_hash(stored), row["id"]))
                if not row["username"]:
                    conn.execute("UPDATE users SET username=? WHERE id=?", (username, row["id"]))
        _ensure_demo_users(conn)      # [M3] one demo login per role for the evaluation

_LEGACY_ADMINS = {e.strip().lower() for e in os.environ.get("LEGACY_ADMIN_EMAILS", "").split(",") if e.strip()}

def import_legacy_accounts(source_path="/content/drive/MyDrive/portal_db/infosys_portal.db"):
    """Import Milestone 1 accounts and lockout history when its old Drive DB is available.
    Existing FreightQuote accounts are never overwritten; bcrypt hashes are retained.
    """
    if not os.path.isfile(source_path):
        return {"imported_users": 0, "imported_lockouts": 0, "skipped": "Legacy Milestone 1 database not found."}
    source = sqlite3.connect(source_path, timeout=20)
    source.row_factory = sqlite3.Row
    imported_users = imported_lockouts = 0
    try:
        tables = {r["name"] for r in source.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "users" not in tables:
            return {"imported_users": 0, "imported_lockouts": 0, "skipped": "Legacy users table not found."}
        legacy_users = source.execute(
            "SELECT username,email,password_hash,security_question,security_answer_hash FROM users"
        ).fetchall()
        with db() as target:
            for old in legacy_users:
                email = str(old["email"] or "").strip().lower()
                password_hash = str(old["password_hash"] or "")
                if not _email_ok(email) or not password_hash:
                    continue
                if target.execute("SELECT 1 FROM users WHERE lower(email)=?", (email,)).fetchone():
                    continue
                username = str(old["username"] or email.split("@")[0]).strip()[:80]
                if target.execute("SELECT 1 FROM users WHERE lower(username)=?", (username.lower(),)).fetchone():
                    username = (username[:60] + "_" + email.split("@")[0][:18])[:80]
                role = "Admin" if email in _LEGACY_ADMINS else "Freight Broker"      # [M3] was a hard-coded personal e-mail; now LEGACY_ADMIN_EMAILS (comma-separated, default none)
                try:
                    target.execute(
                        """INSERT INTO users(username,email,password_hash,security_question,
                           security_answer_hash,role,account_status)
                           VALUES(?,?,?,?,?,?, 'active')""",
                        (username, email, password_hash, old["security_question"], old["security_answer_hash"], role),
                    )
                    imported_users += 1
                except sqlite3.IntegrityError:
                    continue
            if "lockouts" in tables:
                old_locks = source.execute(
                    "SELECT email,attempts,last_attempt,lockout_count,is_permanent FROM lockouts"
                ).fetchall()
                for lock in old_locks:
                    email = str(lock["email"] or "").strip().lower()
                    if not email:
                        continue
                    cur = target.execute(
                        """INSERT OR IGNORE INTO auth_lockouts
                           (email,attempts,last_attempt,lockout_count,is_permanent) VALUES(?,?,?,?,?)""",
                        (email, int(lock["attempts"] or 0), float(lock["last_attempt"] or 0),
                         int(lock["lockout_count"] or 0), int(lock["is_permanent"] or 0)),
                    )
                    imported_lockouts += max(cur.rowcount, 0)
    finally:
        source.close()
    return {"imported_users": imported_users, "imported_lockouts": imported_lockouts, "skipped": None}

def current_user(request: Request):
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        return None
    try:
        payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=["HS256"])
        email = str(payload.get("email", "")).strip().lower()
    except Exception:
        return None
    with db() as conn:
        row = conn.execute(
            "SELECT id, username, email, role, account_status, lock_until, customer_id, created_at, last_login, avatar FROM users WHERE lower(email)=?",
            (email,),
        ).fetchone()
    if not row or str(row["account_status"] or "active").strip().lower() != "active":
        return None
    if row["lock_until"] and float(row["lock_until"]) > time.time():
        return None
    role = row["role"] or ("Admin" if email == ADMIN_EMAIL else "Freight Broker")
    return {
        "id": row["id"],
        "email": row["email"],
        "username": row["username"] or row["email"].split("@")[0],
        "role": role,
        "customer_id": row["customer_id"],
        "created_at": row["created_at"],
        "last_login": row["last_login"],
        "avatar": row["avatar"] if "avatar" in row.keys() else None,
    }

def require_user(request: Request):
    user = current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Please sign in to continue.")
    return user

def _issue_session(response: Response, email):
    token = jwt.encode(
        {"email": email, "exp": datetime.now(timezone.utc) + timedelta(hours=SESSION_HOURS)},
        JWT_SECRET_KEY,
        algorithm="HS256",
    )
    response.set_cookie(
        COOKIE_NAME, token, max_age=SESSION_HOURS * 3600, httponly=True,
        secure=os.environ.get("COOKIE_SECURE", "0") == "1",
        samesite="lax", path="/",
    )

def _lockout_state(conn, email):
    u = conn.execute("SELECT role FROM users WHERE lower(email)=?", (email.lower(),)).fetchone()
    if email.lower() == ADMIN_EMAIL or (u and str(u["role"] or "").strip().lower() in {"admin", "administrator"}):
        return None
    row = conn.execute("SELECT * FROM auth_lockouts WHERE lower(email)=?", (email.lower(),)).fetchone()
    if not row:
        return None
    if int(row["is_permanent"] or 0):
        return "permanent"
    attempts = int(row["attempts"] or 0)
    if attempts >= MAX_FAILED_ATTEMPTS:
        remaining = LOCKOUT_DURATION_SECONDS - (time.time() - float(row["last_attempt"] or 0))
        if remaining > 0:
            return ("temporary", int(remaining) + 1, int(row["lockout_count"] or 0))
        conn.execute("UPDATE auth_lockouts SET attempts=0 WHERE lower(email)=?", (email.lower(),))
    return None

def _ensure_recovery_allowed(conn, user):
    """Prevent password recovery from bypassing a disabled or login-locked account."""
    if not user:
        raise HTTPException(404, "Account or recovery details not found.")
    email = str(user["email"]).strip().lower()
    if str(user["account_status"] or "active").strip().lower() != "active":
        raise HTTPException(423, "This account is locked or disabled. Contact an administrator.")
    state = _lockout_state(conn, email)
    if state == "permanent":
        raise HTTPException(423, "This account is permanently locked. Contact an administrator.")
    if state and state[0] == "temporary":
        raise HTTPException(423, f"This account is temporarily locked. Try again in {state[1]} seconds.")
    return email

def _lock_account(conn, email, duration=LOCKOUT_DURATION_SECONDS):
    u = conn.execute("SELECT role FROM users WHERE lower(email)=?", (email.lower(),)).fetchone()
    if email.lower() == ADMIN_EMAIL or (u and str(u["role"] or "").strip().lower() in {"admin", "administrator"}):
        return 0, False
    now = time.time()
    row = conn.execute("SELECT * FROM auth_lockouts WHERE lower(email)=?", (email.lower(),)).fetchone()
    count = (int(row["lockout_count"] or 0) + 1) if row else 1
    permanent = int(count >= MAX_TEMPORARY_LOCKOUTS)
    if not row:
        conn.execute(
            "INSERT INTO auth_lockouts(email,attempts,last_attempt,lockout_count,is_permanent) VALUES(?,?,?,?,?)",
            (email.lower(), MAX_FAILED_ATTEMPTS, now, count, permanent),
        )
    else:
        conn.execute(
            "UPDATE auth_lockouts SET attempts=?,last_attempt=?,lockout_count=?,is_permanent=? WHERE lower(email)=?",
            (MAX_FAILED_ATTEMPTS, now, count, permanent, email.lower()),
        )
    if permanent:
        conn.execute(
            "UPDATE users SET account_status='locked', failed_attempts=?, lock_until=NULL WHERE lower(email)=?",
            (MAX_FAILED_ATTEMPTS, email.lower()),
        )
    else:
        conn.execute(
            "UPDATE users SET failed_attempts=?,lock_until=? WHERE lower(email)=?",
            (MAX_FAILED_ATTEMPTS, now + duration, email.lower()),
        )
    return count, bool(permanent)

def _record_failed_attempt(conn, email):
    u = conn.execute("SELECT role FROM users WHERE lower(email)=?", (email.lower(),)).fetchone()
    if email.lower() == ADMIN_EMAIL or (u and str(u["role"] or "").strip().lower() in {"admin", "administrator"}):
        return 0, 0, False
    now = time.time()
    row = conn.execute("SELECT * FROM auth_lockouts WHERE lower(email)=?", (email.lower(),)).fetchone()
    if not row:
        conn.execute(
            "INSERT INTO auth_lockouts(email,attempts,last_attempt,lockout_count,is_permanent) VALUES(?,1,?,0,0)",
            (email.lower(), now),
        )
        return 1, 0, False
    attempts = int(row["attempts"] or 0) + 1
    count = int(row["lockout_count"] or 0)
    permanent = int(row["is_permanent"] or 0)
    if attempts >= MAX_FAILED_ATTEMPTS:
        count += 1
        permanent = int(count >= MAX_TEMPORARY_LOCKOUTS)
        if permanent:
            conn.execute(
                "UPDATE users SET account_status='locked', failed_attempts=?, lock_until=NULL WHERE lower(email)=?",
                (attempts, email.lower()),
            )
        else:
            conn.execute(
                "UPDATE users SET failed_attempts=?,lock_until=? WHERE lower(email)=?",
                (attempts, now + LOCKOUT_DURATION_SECONDS, email.lower()),
            )
    conn.execute(
        "UPDATE auth_lockouts SET attempts=?,last_attempt=?,lockout_count=?,is_permanent=? WHERE lower(email)=?",
        (attempts, now, count, permanent, email.lower()),
    )
    return attempts, count, bool(permanent)

def _clear_temporary_attempts(conn, email):
    # Matches Milestone 1: a successful login clears the current attempt window,
    # but the accumulated lockout count remains until an administrator unlocks it.
    conn.execute("UPDATE auth_lockouts SET attempts=0 WHERE lower(email)=? AND is_permanent=0", (email.lower(),))
    conn.execute("UPDATE users SET failed_attempts=0, lock_until=NULL WHERE lower(email)=?", (email.lower(),))

def _is_admin(user):
    return str(user.get("role", "")).strip().lower() in {"admin", "administrator"} or user.get("email", "").lower() == ADMIN_EMAIL

@router.post("/login")
async def login(request: Request, response: Response):
    data = await request.json()
    identity = str(data.get("identity") or data.get("email") or data.get("username") or "").strip()
    password = str(data.get("password", ""))
    if not identity or not password:
        raise HTTPException(400, "Enter your username/email and password.")
    if re.search(r"\s", password):
        raise HTTPException(400, "Password cannot contain spaces.")
    error = None
    email = None
    with db() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE lower(email)=? OR lower(username)=?",
            (identity.lower(), identity.lower()),
        ).fetchone()
        if not row:
            error = (404, "Email/username not found.")
        else:
            email = str(row["email"]).lower()
            if (row["account_status"] or "active") != "active":
                error = (423, "This account is locked. Contact an administrator.")
            else:
                state = _lockout_state(conn, email)
                if state == "permanent":
                    error = (423, "Account permanently locked after repeated security lockouts. Contact an administrator.")
                elif state and state[0] == "temporary":
                    error = (423, f"Account temporarily locked. Try again in {state[1]} seconds. Lockout {state[2]}/{MAX_TEMPORARY_LOCKOUTS}.")
                elif not _check(password, row["password_hash"]):
                    if _is_admin(dict(row)):
                        error = (401, "Email/username or password is incorrect.")
                    else:
                        attempts, count, permanent = _record_failed_attempt(conn, email)
                        if permanent:
                            error = (423, "Account permanently locked after 5 temporary lockouts. Contact an administrator.")
                        elif attempts >= MAX_FAILED_ATTEMPTS:
                            error = (423, f"Account locked for 5 minutes after {MAX_FAILED_ATTEMPTS} failed attempts. Lockout {count}/{MAX_TEMPORARY_LOCKOUTS}.")
                        else:
                            error = (401, f"Invalid credentials. {MAX_FAILED_ATTEMPTS-attempts} attempt(s) remain.")
                else:
                    stored = str(row["password_hash"] or "")
                    if stored and not stored.startswith(("$2a$", "$2b$", "$2y$")):
                        conn.execute("UPDATE users SET password_hash=? WHERE id=?", (_hash(password), row["id"]))
                    _clear_temporary_attempts(conn, email)
                    conn.execute("UPDATE users SET last_login=datetime('now','localtime') WHERE id=?", (row["id"],))
    if error:
        raise HTTPException(error[0], error[1])
    _issue_session(response, email)
    return {"ok": True, "msg": "Signed in successfully."}

@router.post("/register")
@router.post("/signup")
async def register(request: Request):
    data = await request.json()
    username = str(data.get("username", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))
    confirm = str(data.get("confirm_password") or data.get("confirmPassword") or "")
    question = str(data.get("security_question", "")).strip()
    answer = str(data.get("security_answer", "")).strip()
    raw_role = str(data.get("role", "Customer")).strip()
    if not username or not email or not answer:
        raise HTTPException(400, "Complete all fields.")
    if len(username) > 80:
        raise HTTPException(400, "Username must be 80 characters or fewer.")
    err = _email_error(email)
    if err:
        raise HTTPException(400, err)
    error = _password_error(password, confirm)
    if error:
        raise HTTPException(400, error)
    if question not in SECURITY_QUESTIONS:
        raise HTTPException(400, "Choose a valid security question.")

    role_map = {
        "operations mgr": "Operations Manager",
        "operations manager": "Operations Manager",
        "freight broker": "Freight Broker",
        "auditor": "Auditor",
        "customer": "Customer",
    }
    role = role_map.get(raw_role.lower())
    if role and role != "Customer":                                  # [M3 AUDIT] self sign-up never grants a staff role; an Admin assigns it in the Admin Dashboard
        raise HTTPException(403, "Self sign-up creates Customer accounts only. Ask an administrator for a staff role.")
    if not role:
        raise HTTPException(400, "Choose one of the supported roles: Operations Mgr, Freight Broker, Auditor, Customer.")

    with db() as conn:
        try:
            customer_id = ("CUST-" + uuid.uuid4().hex[:12].upper()) if role == "Customer" else None
            conn.execute(
                """INSERT INTO users(username,email,password_hash,security_question,
                   security_answer_hash,role,account_status,customer_id)
                   VALUES(?,?,?,?,?,?, 'active',?)""",
                (username, email, _hash(password), question, _hash(answer), role, customer_id),
            )
            if role == "Customer" and customer_id:
                conn.execute("INSERT OR IGNORE INTO customers(customer_id,name,industry,priority_tier,credit_risk) VALUES(?,?, 'General', 'Standard', 0.25)", (customer_id, username))
        except sqlite3.IntegrityError:
            raise HTTPException(409, "That email address or username is already registered.")
    return {"ok": True, "msg": "Account created. Sign in with your new credentials."}
@router.get("/profile")
def profile(request: Request):
    user = require_user(request)
    with db() as conn:
        row = conn.execute("SELECT id,username,email,role,created_at,last_login,customer_id,avatar FROM users WHERE id=?", (user["id"],)).fetchone()
    return {"ok": True, "profile": dict(row)}

@router.post("/profile/avatar")
async def update_avatar(request: Request):
    user = require_user(request)
    data = await request.json()
    avatar = str(data.get("avatar") or "")
    if avatar and (not avatar.startswith(("data:image/png;base64,", "data:image/jpeg;base64,", "data:image/webp;base64,")) or len(avatar) > 400_000):   # [M3 AUDIT]
        raise HTTPException(400, "Profile picture must be a PNG, JPEG or WebP image under 300 KB.")
    with db() as conn:
        conn.execute("UPDATE users SET avatar=? WHERE id=?", (avatar, user["id"]))
    return {"ok": True, "msg": "Profile picture updated.", "avatar": avatar}

@router.post("/profile")
async def update_profile(request: Request):
    user = require_user(request)
    data = await request.json()
    current = str(data.get("current_password", ""))
    username = str(data.get("username", user.get("username", ""))).strip()
    new_password = str(data.get("new_password", ""))
    confirm = str(data.get("confirm_password", ""))
    if not current:
        raise HTTPException(400, "Enter your current password to save profile changes.")
    if not username or len(username) > 80:
        raise HTTPException(400, "Username must contain 1–80 characters.")
    with db() as conn:
        row = conn.execute("SELECT id,password_hash FROM users WHERE id=?", (user["id"],)).fetchone()
        if not row or not _check(current, row["password_hash"]):
            raise HTTPException(401, "Current password is incorrect.")
        duplicate = conn.execute("SELECT 1 FROM users WHERE lower(username)=lower(?) AND id<>?", (username, user["id"])).fetchone()
        if duplicate:
            raise HTTPException(409, "That username is already in use.")
        if new_password:
            error = _password_error(new_password, confirm)
            if error: raise HTTPException(400, error)
            if _check(new_password, row["password_hash"]):
                raise HTTPException(400, "New password cannot match the current password.")
            conn.execute("UPDATE users SET username=?,password_hash=? WHERE id=?", (username, _hash(new_password), user["id"]))
        else:
            conn.execute("UPDATE users SET username=? WHERE id=?", (username, user["id"]))
    return {"ok": True, "msg": "Profile updated successfully."}

@router.post("/logout")
def logout(response: Response):
    response.delete_cookie(COOKIE_NAME, path="/")
    return {"ok": True, "msg": "Signed out."}

@router.post("/security-question")
async def security_question(request: Request):
    data = await request.json()
    identity = str(data.get("identity", "")).strip().lower()
    if not identity:
        raise HTTPException(400, "Enter your registered email or username.")
    with db() as conn:
        row = conn.execute(
            "SELECT email,security_question,account_status FROM users WHERE lower(email)=? OR lower(username)=?",
            (identity, identity),
        ).fetchone()
        _ensure_recovery_allowed(conn, row)
        if not row["security_question"]:
            raise HTTPException(404, "Account or security question not found.")
    return {"ok": True, "email": row["email"], "question": row["security_question"]}

def _send_otp(email, otp):
    # Read environment values at send time so the notebook's optional secret-setup
    # cell can run after auth.py has been imported for the legacy-account migration.
    sender = (os.environ.get("EMAIL_ID") or EMAIL_ID or "").strip()
    sender_password = (os.environ.get("EMAIL_PASSWORD") or EMAIL_PASSWORD or "").replace(" ", "")
    if not sender or not sender_password:
        raise HTTPException(503, "Email OTP is not configured. Add EMAIL_ID and EMAIL_PASSWORD in Colab Secrets, then rerun the email setup cell.")
    message = EmailMessage()
    message["Subject"] = "FreightQuote password reset verification code"
    message["From"] = sender
    message["To"] = email
    message.set_content(
        f"Your FreightQuote verification code is {otp}. "
        f"It expires in {OTP_EXPIRY_MINUTES} minutes. If you did not request this, ignore this email."
    )
    try:
        with smtplib.SMTP("smtp.gmail.com", 587, timeout=20) as smtp:
            smtp.starttls()
            smtp.login(sender, sender_password)
            smtp.send_message(message)
    except Exception:
        raise HTTPException(502, "Could not send the email OTP. Check EMAIL_ID and your Gmail App Password.")

@router.post("/otp/request")
async def otp_request(request: Request):
    data = await request.json()
    email = str(data.get("email", "")).strip().lower()
    err = _email_error(email)
    if err:
        raise HTTPException(400, err)
    with db() as conn:
        user = conn.execute(
            "SELECT email,account_status FROM users WHERE lower(email)=?", (email,)
        ).fetchone()
        if not user:
            raise HTTPException(404, "Email address is not registered.")
        _ensure_recovery_allowed(conn, user)
        previous = conn.execute("SELECT created_at FROM auth_otps WHERE lower(email)=?", (email,)).fetchone()
        if previous and time.time() - float(previous["created_at"]) < OTP_RESEND_SECONDS:
            wait = int(OTP_RESEND_SECONDS - (time.time() - float(previous["created_at"]))) + 1
            raise HTTPException(429, f"Please wait {wait} seconds before requesting another OTP.")
    otp = f"{secrets.randbelow(900000) + 100000}"
    _send_otp(email, otp)
    with db() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO auth_otps(email,otp_hash,expires_at,created_at,attempts) VALUES(?,?,?,?,0)",
            (email, _hash(otp), time.time() + OTP_EXPIRY_MINUTES * 60, time.time()),
        )
    return {"ok": True, "msg": "A verification code was sent to your email."}

@router.post("/reset-security")
async def reset_security(request: Request):
    data = await request.json()
    email = str(data.get("email", "")).strip().lower()
    answer = str(data.get("answer", "")).strip()
    password = str(data.get("password", ""))
    confirm = str(data.get("confirm_password") or data.get("confirmPassword") or "")
    error = _password_error(password, confirm)
    if error:
        raise HTTPException(400, error)
    failure = None
    with db() as conn:
        row = conn.execute(
            "SELECT id,email,account_status,security_answer_hash,password_hash FROM users WHERE lower(email)=?",
            (email,),
        ).fetchone()
        if not row:
            failure = (404, "Account or recovery details not found.")
        else:
            try:
                _ensure_recovery_allowed(conn, row)
            except HTTPException as exc:
                failure = (exc.status_code, str(exc.detail))
        if failure:
            pass
        elif not _check(answer, row["security_answer_hash"]):
            if _is_admin(dict(row)):
                failure = (401, "Incorrect security answer.")
            else:
                attempts, count, permanent = _record_failed_attempt(conn, email)
                if permanent:
                    failure = (423, "This account is permanently locked after multiple lockout periods. Contact an administrator.")
                elif attempts >= MAX_FAILED_ATTEMPTS:
                    failure = (423, f"Account locked for 5 minutes after {MAX_FAILED_ATTEMPTS} failed attempts. Lockout {count}/{MAX_TEMPORARY_LOCKOUTS}.")
                else:
                    remaining = MAX_FAILED_ATTEMPTS - attempts
                    failure = (401, f"Incorrect security answer. {remaining} attempt(s) remain.")
        elif _check(password, row["password_hash"]):
            failure = (400, "New password cannot match the old password.")
        else:
            conn.execute("UPDATE users SET password_hash=? WHERE id=?", (_hash(password), row["id"]))
            conn.execute("UPDATE users SET failed_attempts=0,lock_until=NULL WHERE id=?", (row["id"],))
            conn.execute("UPDATE auth_lockouts SET attempts=0 WHERE lower(email)=? AND is_permanent=0", (email,))
    if failure:
        raise HTTPException(failure[0], failure[1])
    return {"ok": True, "msg": "Password updated. You can now sign in."}

@router.post("/otp/reset")
async def otp_reset(request: Request):
    data = await request.json()
    email = str(data.get("email", "")).strip().lower()
    otp = str(data.get("otp", "")).strip()
    password = str(data.get("password", ""))
    confirm = str(data.get("confirm_password") or data.get("confirmPassword") or "")
    error = _password_error(password, confirm)
    if error:
        raise HTTPException(400, error)

    failure = None
    with db() as conn:
        row = conn.execute("SELECT * FROM auth_otps WHERE lower(email)=?", (email,)).fetchone()
        user = conn.execute(
            "SELECT id,email,account_status,password_hash FROM users WHERE lower(email)=?", (email,)
        ).fetchone()
        if user:
            try:
                _ensure_recovery_allowed(conn, user)
            except HTTPException as exc:
                failure = (exc.status_code, str(exc.detail))
        if failure:
            pass
        elif not row or not user:
            failure = (400, "Request a new verification code.")
        elif float(row["expires_at"]) < time.time():
            conn.execute("DELETE FROM auth_otps WHERE lower(email)=?", (email,))
            failure = (400, "Verification code expired. Request a new one.")
        elif not _check(otp, row["otp_hash"]):
            otp_attempts = int(row["attempts"] or 0) + 1
            conn.execute("UPDATE auth_otps SET attempts=? WHERE lower(email)=?", (otp_attempts, email))
            if otp_attempts > OTP_MAX_ATTEMPTS:
                count, permanent = _lock_account(conn, email, duration=LOCKOUT_DURATION_SECONDS)
                conn.execute("DELETE FROM auth_otps WHERE lower(email)=?", (email,))
                if permanent:
                    failure = (423, "This account is permanently locked after multiple lockout periods. Contact an administrator.")
                else:
                    failure = (423, f"Account locked for 5 minutes after entering incorrect OTP more than {OTP_MAX_ATTEMPTS} times. Lockout {count}/{MAX_TEMPORARY_LOCKOUTS}.")
            else:
                remaining = OTP_MAX_ATTEMPTS + 1 - otp_attempts
                failure = (401, f"Invalid verification code. {remaining} attempt(s) remaining before account lockout.")
        elif _check(password, user["password_hash"]):
            failure = (400, "New password cannot match the old password.")
        else:
            conn.execute(
                "UPDATE users SET password_hash=?,failed_attempts=0,lock_until=NULL WHERE id=?",
                (_hash(password), user["id"]),
            )
            conn.execute(
                "UPDATE auth_lockouts SET attempts=0 WHERE lower(email)=? AND is_permanent=0",
                (email,),
            )
            conn.execute("DELETE FROM auth_otps WHERE lower(email)=?", (email,))
    if failure:
        raise HTTPException(failure[0], failure[1])
    return {"ok": True, "msg": "Password updated. You can now sign in."}

# Compact aliases used by the unified auth contract:
# POST /signup, POST /login, POST /forgot, POST /reset.
@router.post("/forgot")
async def forgot(request: Request):
    data = await request.json()
    mode = str(data.get("mode", "otp")).strip().lower()
    if mode in {"security", "question", "security-question"}:
        return await security_question(request)
    if mode in {"otp", "email", "email-otp"}:
        return await otp_request(request)
    raise HTTPException(400, "Choose either 'security' or 'otp' password recovery.")

@router.post("/reset")
async def reset(request: Request):
    data = await request.json()
    mode = str(data.get("mode") or ("otp" if data.get("otp") else "security")).strip().lower()
    if mode in {"security", "question", "security-question"}:
        return await reset_security(request)
    if mode in {"otp", "email", "email-otp"}:
        return await otp_reset(request)
    raise HTTPException(400, "Choose either 'security' or 'otp' password reset.")

def _need_users(request: Request):
    user = require_user(request)
    import rbac
    c = {"role": user.get("role"), "email": user.get("email"), "user": user}
    rbac.need(c, "users")
    if rbac.normalize_role(user.get("role")) != "Admin":
        raise HTTPException(403, "Administrator access required.")
    return user, c

@router.get("/admin/activity")
def admin_activity(request: Request, limit: int = 500):
    user, c = _need_users(request); import rbac; rbac.need(c, "users")
    limit = max(1, min(int(limit), 2000))
    with db() as conn:
        rows = conn.execute("SELECT ts,actor,event,target,detail FROM audit_log ORDER BY audit_id DESC LIMIT ?", (limit,)).fetchall()
    return {"ok": True, "events": [dict(r) for r in rows]}

@router.get("/admin/users")
def admin_users(request: Request):
    user, c = _need_users(request); import rbac; rbac.need(c, "users")
    with db() as conn:
        rows = conn.execute("SELECT id,username,email,role,customer_id,created_at,last_login,account_status FROM users ORDER BY lower(username)").fetchall()
    return {"ok": True, "users": [dict(r) for r in rows]}

@router.post("/admin/users/role")
async def admin_set_role(request: Request):
    user, c = _need_users(request); import rbac; rbac.need(c, "users")
    data = await request.json(); uid = int(data.get("user_id", 0)); role = str(data.get("role", "")).strip()
    if role not in {"Admin", "Operations Manager", "Freight Broker", "Auditor", "Customer"}:
        raise HTTPException(400, "Choose one of the five supported roles.")
    with db() as conn:
        target = conn.execute("SELECT id,customer_id,username FROM users WHERE id=?", (uid,)).fetchone()
        if not target: raise HTTPException(404, "User not found.")
        if uid == user["id"] and role != "Admin": raise HTTPException(400, "You cannot remove your own Admin role.")
        cid = target["customer_id"]
        if role == "Customer" and not cid:
            cid = "CUST-" + uuid.uuid4().hex[:12].upper()
            conn.execute("INSERT INTO customers(customer_id,name,industry,priority_tier,credit_risk) VALUES(?,?, 'General', 'Standard', 0.25)", (cid, target["username"] or cid))
        conn.execute("UPDATE users SET role=?,customer_id=? WHERE id=?", (role, cid if role == "Customer" else None, uid))
    return {"ok": True, "msg": "User role updated."}

@router.get("/admin/locked")
def admin_locked(request: Request):
    user = require_user(request)
    if not _is_admin(user):
        raise HTTPException(403, "Administrator access required.")
    with db() as conn:
        rows = conn.execute(
            """SELECT u.username,u.email,l.attempts,l.last_attempt,l.lockout_count,l.is_permanent
               FROM auth_lockouts l JOIN users u ON lower(u.email)=lower(l.email)
               WHERE l.attempts >= ? OR l.is_permanent=1 ORDER BY l.is_permanent DESC,l.lockout_count DESC""",
            (MAX_FAILED_ATTEMPTS,),
        ).fetchall()
    return {"ok": True, "accounts": [dict(r) for r in rows]}

@router.post("/admin/unlock")
async def admin_unlock(request: Request):
    user = require_user(request)
    if not _is_admin(user):
        raise HTTPException(403, "Administrator access required.")
    data = await request.json()
    email = str(data.get("email", "")).strip().lower()
    err = _email_error(email)
    if err:
        raise HTTPException(400, err)
    with db() as conn:
        conn.execute("DELETE FROM auth_lockouts WHERE lower(email)=?", (email,))
        conn.execute("UPDATE users SET failed_attempts=0,lock_until=NULL WHERE lower(email)=?", (email,))
    return {"ok": True, "msg": f"Lockout cleared for {email}."}


def is_admin_user(user):
    return _is_admin(user)


# ---------------------------------------------------------------------------------------------------
# [M3] Demo accounts: one per role, listed on the sign-in page (Milestone 3: "create one demo user per role").
# Passwords follow the Milestone 2 policy (upper, lower, digit, special). They are demo credentials, not secrets:
# set the environment variable DEMO_MODE=0 to create none, and ADMIN_PASSWORD (Colab Secret) to choose the admin password.
# ---------------------------------------------------------------------------------------------------
from config import DEMO_MODE as _DEMO_MODE
_LEGACY_SEED_PASSWORDS = ("admin123",)          # the old seed_data plaintext password; replaced by the documented demo password
DEMO_ACCOUNTS = (   # email, username, role, password, customer_id
    (ADMIN_EMAIL, "Administrator", "Admin", os.environ.get("ADMIN_PASSWORD") or "AdminPass123!", None),
    ("ops@infosys.com", "Operations Manager", "Operations Manager", "OpsPass123!", None),
    ("broker@infosys.com", "Freight Broker", "Freight Broker", "BrokerPass123!", None),
    ("auditor@infosys.com", "Auditor", "Auditor", "AuditPass123!", None),
    ("customer@apex.com", "Apex Customer", "Customer", "CustPass123!", "CUST-001"),
)


def _ensure_demo_users(conn):
    if not _DEMO_MODE:
        return
    for email, username, role, pw, cid in DEMO_ACCOUNTS:
        row = conn.execute("SELECT id, username, password_hash, role, customer_id FROM users WHERE lower(email)=?", (email.lower(),)).fetchone()
        if row is None:
            if conn.execute("SELECT 1 FROM users WHERE lower(username)=?", (username.lower(),)).fetchone():
                username = username + " (demo)"
            if cid and not conn.execute("SELECT 1 FROM customers WHERE customer_id=?", (cid,)).fetchone():
                conn.execute("INSERT OR IGNORE INTO customers(customer_id,name,industry,priority_tier,credit_risk) VALUES(?,?, 'General', 'Standard', 0.25)", (cid, username))
            conn.execute("INSERT INTO users(username,email,password_hash,role,account_status,customer_id) VALUES(?,?,?,?, 'active', ?)",
                         (username, email.lower(), _hash(pw), role, cid))
            continue
        stored = str(row["password_hash"] or "")
        if any(_check(old, stored) for old in _LEGACY_SEED_PASSWORDS):      # still the old seed password: move to the documented one
            conn.execute("UPDATE users SET password_hash=? WHERE id=?", (_hash(pw), row["id"]))
        if cid and not row["customer_id"]:
            conn.execute("UPDATE users SET customer_id=? WHERE id=?", (cid, row["id"]))


def demo_logins():
    """For the sign-in screen (GET /api/public): which demo logins exist."""
    if not _DEMO_MODE:
        return []
    return [{"email": e, "role": r, "pw": p} for e, _, r, p, _ in DEMO_ACCOUNTS]
