"""Freight simulators (USD). Real sea routes (seanav), live shipments, quotes, carriers and ports; assumptions are shown on every page and are editable in the form."""
import numpy as np, pandas as pd
import blocks as B
from blocks import Q, TEAL, BLUE, AMBER, RED, VIOLET
GREY = "#8b8d98"; STORM_AREAS = {"Red Sea": (18.0, 40.0), "Arabian Sea": (15.0, 65.0), "Strait of Malacca": (3.5, 100.5), "South China Sea": (14.0, 114.0), "Bay of Biscay": (45.0, -8.0), "Cape of Good Hope": (-35.0, 20.0), "North Atlantic": (48.0, -35.0)}
def g(a, k, d):
    try: return float(a.get(k, d))
    except Exception: return float(d)
def usd(x):
    x = float(x); s = "-" if x < 0 else ""; x = abs(x); return s + ("$%.2fM" % (x / 1e6) if x >= 1e6 else "$%.1fk" % (x / 1e3) if x >= 1e4 else "${:,.0f}".format(x))
def _D():
    import domain_freight as D; return D
def hav(la1, lo1, la2, lo2):
    p = np.pi / 180; a = np.sin((la2 - la1) * p / 2) ** 2 + np.cos(la1 * p) * np.cos(la2 * p) * np.sin((lo2 - lo1) * p / 2) ** 2; return 2 * 3440.065 * np.arcsin(np.sqrt(a))
def _wrap(lon): return (np.asarray(lon, float) + 180) % 360 - 180
ASSUME = {"route": "Real sea routes on a land-masked graph. Speed 14 kn. Freight cost $0.012 per tonne-nautical-mile; cargo waiting costs $120 per shipment-day. Each +1 congestion adds 0.8 days at each end port. Closed chokepoints are removed from the graph; storms are avoided by a 700 nm radius.",
          "quote": "Win probability = 45% × exp(−elasticity × price change). Elasticity is a setting. Costs rise with the carrier-rate and fuel moves you set (fuel applies to the fuel surcharge). Expected profit = win probability × (price − cost).",
          "carrier": "Alternatives are ranked by rating, on-time % and cost index. Each alternative can absorb up to 30% more load. Delay cost $120 per shipment-day, and 1 point of on-time ≈ 0.08 days.",
          "weather": "Delay days = 0.25 × (wind − 12 m/s), capped at 7. A vessel is affected inside the storm radius. Demurrage and re-planning cost is a setting per shipment-day.",
          "customs": "Held shipments are those arriving soonest at the affected ports; each is delayed by the extra dwell days at the storage cost you set. Duty changes scale customs fees (average duty 7.5%)."}
def _cb(k): return B.callout(ASSUME[k], "info", "Assumptions")
def _lanes(limit=40):
    s = Q("SELECT s.shipment_id, s.origin_port o, s.dest_port d, s.carrier, s.weight_kg/1000.0 t, s.status FROM shipments s WHERE s.status IN ('In Transit','Port Congestion Delay','Anchorage Pending','Customs Hold') ORDER BY s.shipment_id")
    p = Q("SELECT port_name, lat, lon, congestion_index ci, avg_dwell_days dw FROM ports"); pm = {r.port_name: r for r in p.itertuples()}
    s = s[s.o.isin(pm) & s.d.isin(pm) & (s.o != s.d)]; lanes = s.groupby(["o", "d"], as_index=False).agg(n=("shipment_id", "count"), t=("t", "sum")).sort_values("n", ascending=False).head(limit); return lanes, pm
# ------------------------------------------------------------------------------------------------ routes
_BASE = {}; LAST = {}
def run_route(a):
    import seanav; D = _D(); S = seanav.sea(); closed = [c for c in (a.get("closures") or []) if c in seanav.BLOCK_GROUPS]; area = a.get("area") or "None"; wind = g(a, "wind", 25); cong = g(a, "add", 0); dc = g(a, "delay_cost", 120); rate = g(a, "rate", 12) / 1000
    st = ((STORM_AREAS[area][0], STORM_AREAS[area][1], 700.0),) if area in STORM_AREAS and area != "None" else ()
    lanes, pm = _lanes(int(g(a, "lanes", 25))); rows = []
    for r in lanes.itertuples():
        o, d = pm[r.o], pm[r.d]; oo, dd = (o.lat, o.lon), (d.lat, d.lon)
        try:
            b = _BASE.get((r.o, r.d)) or _BASE.setdefault((r.o, r.d), S.options(oo, dd, (), (), D._access(oo), D._access(dd))); sc = S.options(oo, dd, tuple(closed), st, D._access(oo), D._access(dd)) or (S.options(oo, dd, tuple(closed), (), D._access(oo), D._access(dd)) if st else [])
        except Exception: continue
        if not b: continue
        bn = b[0]["nm"]; days0 = bn / (14 * 24) + (o.dw + d.dw) * .5
        if not sc: rows.append({"lane": f"{r.o} → {r.d}", "shipments": int(r.n), "tonnes": r.t, "nm_now": round(bn), "nm_scn": None, "days_now": round(days0, 1), "days_scn": None, "extra_cost": np.nan, "route_scn": "NO ROUTE", "route_now": b[0]["name"]}); continue
        sn = sc[0]["nm"]; days1 = sn / (14 * 24) + (o.dw + d.dw) * .5 + 0.8 * cong * 2; ex = (sn - bn) * rate * r.t + (days1 - days0) * dc * r.n
        rows.append({"dist_cost": (sn - bn) * rate * r.t, "delay_cost": (days1 - days0) * dc * r.n, "lane": f"{r.o} → {r.d}", "shipments": int(r.n), "tonnes": r.t, "nm_now": round(bn), "nm_scn": round(sn), "days_now": round(days0, 1), "days_scn": round(days1, 1), "extra_cost": ex, "route_scn": sc[0]["name"], "route_now": b[0]["name"]})
    if not rows: return {"blocks": [B.callout("No active lanes found.", "warn")], "m": {}}
    d = pd.DataFrame(rows); LAST["route"] = d[d.nm_scn.notna()]; ok = d[d.nm_scn.notna()]; nor = d[d.nm_scn.isna()]; top = ok.sort_values("extra_cost", ascending=False).head(15)
    bl = [_cb("route"), B.kpis(("Lanes re-routed", int((ok.route_scn != ok.route_now).sum()), f"of {len(d)} active lanes"), ("Lanes with no route", len(nor), "blocked completely" if len(nor) else "none", "Critical" if len(nor) else None), ("Extra cost / voyage set", usd(ok.extra_cost.sum()), f"{int(ok.shipments.sum())} shipments"), ("Average extra days", f"{(ok.days_scn - ok.days_now).mean():+.1f}", None, "Critical" if (ok.days_scn - ok.days_now).mean() > 3 else None)),
          B.card("Extra days on the worst lanes", B.chart(B.bar(top.lane, {"days now": list(top.days_now), "days under scenario": list(top.days_scn)}, horizontal=True, colors=[GREY, RED]), h=360, key="rt_c")),
          B.table(d.sort_values("extra_cost", ascending=False).head(25), ["lane", B.num_col("shipments", "shipments", "int"), B.num_col("nm_now", "nm now", "int"), B.num_col("nm_scn", "nm scenario", "int"), B.num_col("days_now", "days now", "num"), B.num_col("days_scn", "days scenario", "num"), B.num_col("extra_cost", "extra cost", "money"), "route_scn"], title="Lane by lane", h=420, key="rt_t")]
    return {"blocks": bl, "m": {"extra": float(ok.extra_cost.sum()), "no_route": len(nor), "rerouted": int((ok.route_scn != ok.route_now).sum()), "extra_days": float((ok.days_scn - ok.days_now).mean()), "lanes": len(d)}}
# ------------------------------------------------------------------------------------------------ quotes and margin
def run_quote(a):
    fuel, car, disc, fx, el = g(a, "pct", 0) / 100, g(a, "carrier", 0) / 100, g(a, "discount", 0) / 100, g(a, "fx", 0) / 100, g(a, "elasticity", 2.0)
    q = Q("SELECT quote_id, carrier, base_cost, insurance, customs_fee, fuel_surcharge, final_price, margin_pct FROM freight_quotes WHERE final_price>0 ORDER BY created_at DESC LIMIT 400")
    if not len(q): return {"blocks": [B.callout("No quotes yet.", "warn")], "m": {}}
    p0 = q.final_price; c0 = p0 * (1 - q.margin_pct / 100); c1 = c0 + q.base_cost * ((1 + car) * (1 + fx) - 1) + q.customs_fee * fx + q.fuel_surcharge * fuel; m0 = (p0 - c0) / p0
    hold = p0; pass_ = c1 / (1 - m0.clip(.02, .6)) * (1 - disc)
    ev = lambda price, cost: (.45 * np.exp(-el * (price / p0 - 1)).clip(0, 2) * (price - cost)).sum()
    grid = np.arange(-.10, .21, .02); curve = [ev(p0 * (1 + x), c1) for x in grid]; bi = int(np.argmax(curve)); bx = float(grid[bi])
    q = q.assign(margin_now=m0, margin_hold=(hold - c1) / hold, margin_pass=(pass_ - c1) / pass_, cost_up=c1 - c0)
    kp = lambda v: float(v.mean())
    bl = [_cb("quote"), B.kpis(("Margin if prices are held", f"{kp(q.margin_hold):.1%}", f"now {kp(q.margin_now):.1%}", "Critical" if kp(q.margin_hold) < kp(q.margin_now) - .03 else None), ("Margin if costs are passed through", f"{kp(q.margin_pass):.1%}", f"price {((pass_ / p0).mean() - 1):+.1%}"), ("Quotes under 5% margin (held)", int((q.margin_hold < .05).sum()), f"now {int((q.margin_now < .05).sum())}", "Critical" if (q.margin_hold < .05).sum() > (q.margin_now < .05).sum() else None), ("Best price move", f"{bx:+.0%}", f"expected profit {usd(max(curve))} vs {usd(ev(p0, c1))} if held")),
          B.row(B.card("Expected profit vs price change", B.chart(B.line([f"{x:+.0%}" for x in grid], {"expected profit": [round(v) for v in curve]}, area=False, colors=[TEAL], markers=True), h=260, key="qt_c"), sub="Win probability falls as price rises (elasticity setting)"),
                B.card("Extra cost per quote", B.chart(B.hist(list(q.cost_up), bins=18, color=AMBER), h=260, key="qt_h"))),
          B.table(q.sort_values("margin_hold").head(15)[["quote_id", "carrier", "final_price", "cost_up", "margin_now", "margin_hold", "margin_pass"]], ["quote_id", "carrier", B.num_col("final_price", "price", "money"), B.num_col("cost_up", "extra cost", "money"), B.num_col("margin_now", "margin now", "pct"), B.num_col("margin_hold", "margin if held", "pct"), B.num_col("margin_pass", "margin if passed on", "pct")], title="Quotes to reprice first", h=400, open={"kind": "quote", "col": "quote_id"}, key="qt_t")]
    return {"blocks": bl, "m": {"margin_hold": kp(q.margin_hold), "margin_now": kp(q.margin_now), "margin_loss": float(((q.margin_now - q.margin_hold) * p0).sum()), "best_move": bx, "best_gain": float(max(curve) - ev(p0, c1)), "under5": int((q.margin_hold < .05).sum())}}
# ------------------------------------------------------------------------------------------------ carriers
def run_carrier(a):
    name = a.get("carrier"); loss = g(a, "loss", 100) / 100; dc = g(a, "delay_cost", 120); c = Q("SELECT name, rating, on_time_pct ot, avg_cost_index ci, risk_level FROM carriers")
    if not name or name not in set(c.name): name = Q("SELECT carrier, COUNT(*) n FROM shipments WHERE carrier IS NOT NULL GROUP BY carrier ORDER BY n DESC LIMIT 1").carrier[0]
    act = Q("SELECT shipment_id, carrier, weight_kg/1000.0 t, status FROM shipments WHERE status IN ('In Transit','Quoted','Anchorage Pending','Port Congestion Delay')"); load = act.groupby("carrier").size(); mine = act[act.carrier == name].sample(frac=loss, random_state=3) if len(act[act.carrier == name]) else act.iloc[0:0]
    c = c.assign(score=c.rating / 5 * 40 + c.ot * .4 - c.ci * 12 - (c.risk_level.str.lower().map({"low": 0, "medium": 6, "high": 14}).fillna(6))); cur = c[c.name == name].iloc[0]
    alts = c[(c.name != name) & c.name.isin(load.index)].sort_values("score", ascending=False).head(6).copy(); alts["cap"] = (load.reindex(alts.name).values * .30).round().clip(min=1)
    rows = []; room = dict(zip(alts.name, alts.cap))
    for r in mine.itertuples():
        pick = next((n for n in alts.name if room[n] > 0), None)
        if pick: room[pick] -= 1; al = alts[alts.name == pick].iloc[0]; rows.append({"shipment": r.shipment_id, "tonnes": r.t, "from": name, "to": pick, "cost_index": al.ci - cur.ci, "on_time": al.ot - cur.ot, "delay_cost": max(0, cur.ot - al.ot) * .08 * dc})
        else: rows.append({"shipment": r.shipment_id, "tonnes": r.t, "from": name, "to": "NO CAPACITY", "cost_index": np.nan, "on_time": np.nan, "delay_cost": np.nan})
    d = pd.DataFrame(rows)
    if not len(d): return {"blocks": [B.callout(f"{name} has no active shipments.", "info")], "m": {"unplaced": 0}}
    LAST["carrier"] = d; ok = d[d.to != "NO CAPACITY"]; ex = float((ok.cost_index * ok.tonnes * 400).sum()) + float(ok.delay_cost.sum())
    bl = [_cb("carrier"), B.kpis(("Shipments displaced", len(d), f"{name}, {loss:.0%} capacity lost"), ("Re-placed", len(ok), f"{len(d) - len(ok)} with no capacity", "Critical" if len(d) > len(ok) else None), ("Average cost index change", f"{ok.cost_index.mean():+.2f}" if len(ok) else "–"), ("Extra cost", usd(ex), "cost index × tonnes × $400 + delay cost")),
          B.card("Where the load goes", B.chart(B.bar(list(ok.groupby("to").size().index), {"shipments": list(ok.groupby("to").size().values)}, colors=[BLUE]), h=240, key="cr_c")),
          B.table(d.head(40), ["shipment", B.num_col("tonnes", "tonnes", "num"), "from", "to", B.num_col("cost_index", "cost index Δ", "num"), B.num_col("on_time", "on-time Δ (pts)", "num"), B.num_col("delay_cost", "delay cost", "money")], title="Re-assignments", h=380, key="cr_t")]
    return {"blocks": bl, "m": {"displaced": len(d), "unplaced": len(d) - len(ok), "extra": ex}}
# ------------------------------------------------------------------------------------------------ weather
def run_weather(a):
    area = a.get("area") or "Red Sea"; wind = g(a, "wind", 25); rad = g(a, "radius", 900); dem = g(a, "demurrage", 900); la, lo = STORM_AREAS.get(area, STORM_AREAS["Red Sea"])
    try: v = Q("SELECT v.shipment_id, v.lat, v.lon, v.progress, s.origin_port o, s.dest_port d, s.weight_kg/1000.0 t FROM vessels v JOIN shipments s USING(shipment_id)")
    except Exception: v = Q("SELECT shipment_id, 0.0 lat, 0.0 lon, 0.0 progress, origin_port o, dest_port d, weight_kg/1000.0 t FROM shipments")
    p = Q("SELECT port_name, lat, lon, avg_dwell_days dw, congestion_index ci FROM ports")      # [M3] fix: was only loaded in the except branch (NameError on every normal run)
    v["dist"] = hav(v.lat.values, _wrap(v.lon.values), la, lo); hit = v[v.dist <= rad].copy(); p["dist"] = hav(p.lat.values, p.lon.values, la, lo); ph = p[p.dist <= rad]
    delay = lambda w: min(7.0, max(0.0, .25 * (w - 12))); dd = delay(wind); hit["delay_days"] = dd * (1 - hit.dist / rad * .5); hit["cost"] = hit.delay_days * dem
    sw = [(w, round(delay(w), 1), round(delay(w) * dem * max(len(hit), 0))) for w in (12, 18, 24, 30, 36)]
    bl = [_cb("weather"), B.kpis(("Vessels inside the storm", len(hit), f"of {len(v)} tracked", "Critical" if len(hit) > 5 else None), ("Delay per vessel", f"{dd:.1f} days", f"wind {wind:g} m/s"), ("Delay + demurrage cost", usd(hit.cost.sum())), ("Ports in the storm", len(ph), ", ".join(ph.port_name.head(3)) or "none")),
          B.card("Cost vs wind speed", B.chart(B.bar([f"{w} m/s" for w, _, _ in sw], {"cost": [c for _, _, c in sw]}, colors=[AMBER]), h=240, key="wx_s"), sub="For the vessels currently inside the radius"),
          B.table(hit.sort_values("cost", ascending=False).head(25)[["shipment_id", "o", "d", "t", "dist", "delay_days", "cost"]].rename(columns={"o": "origin", "d": "destination"}), [{"k": "shipment_id", "label": "shipment", "type": "id"}, "origin", "destination", B.num_col("t", "tonnes", "num"), B.num_col("dist", "nm from centre", "int"), B.num_col("delay_days", "delay days", "num"), B.num_col("cost", "cost", "money")], title="Vessels affected", h=380, open={"kind": "shipment", "col": "shipment_id"}, key="wx_t")]
    return {"blocks": bl, "m": {"hit": len(hit), "cost": float(hit.cost.sum()), "delay": dd}}
# ------------------------------------------------------------------------------------------------ customs
def run_customs(a):
    hp, dw, sc, duty = g(a, "hold", 20) / 100, g(a, "dwell", 4), g(a, "storage", 180), g(a, "duty", 0)
    s = Q("SELECT shipment_id, dest_port d, eta, weight_kg/1000.0 t, status FROM shipments WHERE status IN ('In Transit','Port Congestion Delay','Anchorage Pending','Customs Hold')").sort_values("eta")
    n = int(round(len(s) * hp)); held = s.head(n); cost = len(held) * dw * sc; by = held.groupby("d").size().sort_values(ascending=False).head(10)
    q = Q("SELECT SUM(customs_fee) cf, SUM(final_price) fp, COUNT(*) n FROM freight_quotes"); cf, fp = float(q.cf[0] or 0), float(q.fp[0] or 1); dcost = cf * duty / 7.5
    bl = [_cb("customs"), B.kpis(("Shipments held", len(held), f"{hp:.0%} of {len(s)} inbound", "Critical" if len(held) > 20 else None), ("Storage + delay cost", usd(cost), f"{dw:g} days × ${sc:g}"), ("Duty impact on open quotes", usd(dcost), f"{dcost / fp:.1%} of quote value", "Critical" if dcost / fp > .02 else None), ("Port most affected", by.index[0] if len(by) else "–", f"{int(by.iloc[0])} held" if len(by) else "")),
          B.card("Held shipments by destination", B.chart(B.bar(list(by.index), {"held": [int(x) for x in by.values]}, horizontal=True, colors=[VIOLET]), h=300, key="cu_c")),
          B.table(held.head(25), [{"k": "shipment_id", "label": "shipment", "type": "id"}, "d", "eta", B.num_col("t", "tonnes", "num"), "status"], title="First to be held", h=360, open={"kind": "shipment", "col": "shipment_id"}, key="cu_t")]
    return {"blocks": bl, "m": {"held": len(held), "cost": float(cost), "duty": float(dcost)}}
RUN = {"route": run_route, "carriers": run_carrier, "weather": run_weather, "quotes": run_quote, "margin": run_quote, "customs": run_customs}

# =====================================================================================================================
# [M3] Milestone 3 simulator improvements (one panel per agent, shown above the original simulator output).
# Every panel: lists its assumptions, reports a range (P10 / P50 / P90) instead of one number, takes a seed so a run
# repeats exactly, reads its starting values from the database, and never changes live data (SELECT queries only).
# =====================================================================================================================
CANAL_TOLL_PER_T = {"Suez Canal": 7.0, "Panama Canal": 9.0}      # USD per tonne of cargo (assumption)
FUEL_SHARE = 0.45                                              # bunker fuel share of the voyage freight rate (assumption)
WIN_BASE = 0.45                                                # win probability at today's price (same as the reference quote simulator)
INTENSITY = {"Tropical storm": 22.0, "Category 1": 36.0, "Category 2": 45.0, "Category 3": 53.0, "Category 4": 62.0, "Category 5": 72.0}   # sustained wind m/s (Saffir-Simpson, approx.)
READ_ONLY = "Read-only: the simulator only runs SELECT queries on the database; live data is never changed."


def _seed(a):
    try: return int(float(a.get("seed", 42)))
    except Exception: return 42
def _runs(a): return int(min(5000, max(200, g(a, "runs", 1000))))
def _pct3(x): return [float(v) for v in np.percentile(np.asarray(x, float), [10, 50, 90])]
def _fmt(v, unit):
    if v is None or v != v: return "–"
    return usd(v) if unit == "usd" else f"{v:,.1f} days" if unit == "days" else f"{v:.0%}" if unit == "pct" else f"{v:,.0f}" if unit == "n" else f"{v:,.1f}"
def _band_rows(items):
    """items: [(measure, samples, unit)] -> rows with P10 / P50 / P90 as display strings."""
    out = []
    for m, x, unit in items:
        p = _pct3(x); out.append({"measure": m, "P10": _fmt(p[0], unit), "P50 (median)": _fmt(p[1], unit), "P90": _fmt(p[2], unit)})
    return out
def _assumptions(lines, a):
    txt = "\n".join("- " + l for l in lines) + f"\n- Seed **{_seed(a)}**, **{_runs(a):,}** Monte Carlo runs: the same seed and settings give exactly the same result.\n- {READ_ONLY}"
    return B.card("Assumptions", B.md(txt))
def _start(rows, key):
    return B.table(pd.DataFrame(rows, columns=["starting value", "value", "read from"]), ["starting value", "value", "read from"], title="Starting values (read from the database)", h=min(300, 70 + 34 * len(rows)), key=key)
def _bands(items, title, key):
    rows = _band_rows(items); return B.table(pd.DataFrame(rows), ["measure", "P10", "P50 (median)", "P90"], title=title, h=min(320, 70 + 34 * len(rows)), key=key, sub="P10 = 1 run in 10 is lower, P90 = 1 run in 10 is higher")


# ------------------------------------------------------------------------------------------------ route: closures, fuel, 3 routes
def lane_names(limit=15):
    try: lanes, _ = _lanes(limit); return [f"{r.o} → {r.d}" for r in lanes.itertuples()]
    except Exception: return []
def m3_route(a):
    import seanav; D = _D(); S = seanav.sea(); rng = np.random.default_rng(_seed(a)); n = _runs(a)
    closed = [c for c in (a.get("closures") or []) if c in seanav.BLOCK_GROUPS]; area = a.get("area") or "None"
    st = ((STORM_AREAS[area][0], STORM_AREAS[area][1], 700.0),) if area in STORM_AREAS else ()
    fuel, spd, rate, dc, cong = g(a, "fuel", 0) / 100, g(a, "speed", 14), g(a, "rate", 12) / 1000, g(a, "delay_cost", 120), g(a, "add", 0)
    lanes, pm = _lanes(40)
    if not len(lanes): return [B.callout("No active lanes in the database.", "warn")]
    want = (a.get("lane") or "").strip(); row = next((r for r in lanes.itertuples() if f"{r.o} → {r.d}" == want), next(lanes.itertuples()))
    o, d = pm[row.o], pm[row.d]; oo, dd = (o.lat, o.lon), (d.lat, d.lon); T = max(float(row.t), 1.0); ns = int(row.n)
    cands = []
    for extra in ((), ("suez",), ("malacca",), ("panama",), ("suez", "malacca"), ("hormuz",), ("suez", "panama")):
        blk = tuple(dict.fromkeys(list(closed) + list(extra)))
        try:
            opts = S.options(oo, dd, blk, st, D._access(oo), D._access(dd)) or (S.options(oo, dd, blk, (), D._access(oo), D._access(dd)) if st else [])
        except Exception: opts = []
        for op in opts:
            if all(abs(op["nm"] - c_["nm"]) > 50 for c_ in cands): cands.append(op)
        if len(cands) >= 3: break
    cands = sorted(cands, key=lambda x: x["nm"])[:3]
    if not cands: return [B.callout(f"No sea route exists for {row.o} → {row.d} with {', '.join(closed) or 'these'} closures.", "warn", "Route comparison")]
    # common random numbers: every route sees the same speed, fuel, dwell and congestion draws, so differences are due to the route
    sp = np.clip(rng.normal(spd, 1.0, n), 9, 22); fu = rng.normal(fuel, 0.10, n); dw = rng.gamma(4.0, max(o.dw + d.dw, 0.2) / 4.0, n); cg = np.maximum(0, rng.normal(1.6 * cong, 0.4, n)) if cong else np.zeros(n)
    days, cost, rows = [], [], []
    for k, c_ in enumerate(cands):
        toll = sum(CANAL_TOLL_PER_T.get(v, 0.0) for v in c_.get("via", [])) * T
        dk = c_["nm"] / (sp * 24) + dw + cg; ck = rate * c_["nm"] * T * (1 + FUEL_SHARE * fu) + toll + dk * dc * ns; days.append(dk); cost.append(ck)
    days, cost = np.array(days), np.array(cost); best = np.bincount(cost.argmin(0), minlength=len(cands)) / n; fast = np.bincount(days.argmin(0), minlength=len(cands)) / n
    L = "ABC"
    for k, c_ in enumerate(cands):
        pd_, pc_ = _pct3(days[k]), _pct3(cost[k])
        rows.append({"route": f"{L[k]}: {c_['name']}", "nm": round(c_["nm"]), "days P10": round(pd_[0], 1), "days P50": round(pd_[1], 1), "days P90": round(pd_[2], 1),
                     "cost P10": pc_[0], "cost P50": pc_[1], "cost P90": pc_[2], "P(cheapest)": float(best[k]), "P(fastest)": float(fast[k])})
    df = pd.DataFrame(rows); kc = int(df["cost P50"].idxmin()); kd = int(df["days P50"].idxmin())
    starts = [("Lane", f"{row.o} → {row.d}", "shipments (active, busiest lanes)"), ("Shipments / tonnes on the lane", f"{ns} / {T:,.0f} t", "shipments.weight_kg"),
              (f"{row.o}: congestion / dwell", f"{o.ci:.1f} / {o.dw:.1f} days", "ports"), (f"{row.d}: congestion / dwell", f"{d.ci:.1f} / {d.dw:.1f} days", "ports")]
    lines = ["Up to three real sea routes from the land-masked graph: the shortest open route, then the best routes that avoid Suez, Malacca, Panama or Hormuz.",
             f"Closed chokepoints: {', '.join(closed) or 'none'}; storm: {area}. Closed chokepoints are removed from the graph.",
             f"Speed ~ Normal({spd:g} kn, 1 kn). Sea days = nm / (speed × 24). Port dwell at both ends ~ Gamma around the database dwell days.",
             f"Freight = ${rate * 1000:g} per 1,000 tonne-nm × tonnes; fuel is {FUEL_SHARE:.0%} of it, so a fuel move of {fuel:+.0%} (±10 pts) changes freight by {FUEL_SHARE * fuel:+.1%}.",
             f"Canal tolls: Suez ${CANAL_TOLL_PER_T['Suez Canal']:g}/t, Panama ${CANAL_TOLL_PER_T['Panama Canal']:g}/t. Waiting costs ${dc:g} per shipment-day.",
             "All three routes use the same random draws (common random numbers), so the comparison is fair."]
    return [B.md("### Route comparison: three routes, days and cost (Milestone 3)"), _assumptions(lines, a), _start(starts, "m3rt_s"),
            B.kpis(("Cheapest (median)", L[kc], f"{usd(df['cost P50'][kc])}, cheapest in {df['P(cheapest)'][kc]:.0%} of runs"), ("Fastest (median)", L[kd], f"{df['days P50'][kd]:.1f} days, fastest in {df['P(fastest)'][kd]:.0%} of runs"),
                   ("Fuel price move", f"{fuel:+.0%}", f"freight {FUEL_SHARE * fuel:+.1%}"), ("Closures", ", ".join(closed) or "none", area if area != "None" else "no storm")),
            B.row(B.card("Days door to door: P10 / P50 / P90", B.chart(B.bar([r["route"][:28] for r in rows], {"P10": list(df["days P10"]), "P50": list(df["days P50"]), "P90": list(df["days P90"])}, colors=[GREY, BLUE, RED]), h=260, key="m3rt_d")),
                  B.card("Total cost: P10 / P50 / P90", B.chart(B.bar([r["route"][:28] for r in rows], {"P10": [round(x) for x in df["cost P10"]], "P50": [round(x) for x in df["cost P50"]], "P90": [round(x) for x in df["cost P90"]]}, colors=[GREY, TEAL, AMBER]), h=260, key="m3rt_c"))),
            B.table(df, ["route", B.num_col("nm", "nm", "int"), B.num_col("days P10", "days P10", "num"), B.num_col("days P50", "days P50", "num"), B.num_col("days P90", "days P90", "num"),
                         B.num_col("cost P10", "cost P10", "money"), B.num_col("cost P50", "cost P50", "money"), B.num_col("cost P90", "cost P90", "money"), B.num_col("P(cheapest)", "P(cheapest)", "pct"), B.num_col("P(fastest)", "P(fastest)", "pct")],
                    title="Three routes compared", h=200, key="m3rt_t")]


# ------------------------------------------------------------------------------------------------ quote: margin, fuel, FX -> price band, win chance
def quote_ids(limit=30):
    try: return Q("SELECT quote_id FROM freight_quotes WHERE final_price>0 ORDER BY created_at DESC, quote_id DESC LIMIT ?", (limit,)).quote_id.tolist()
    except Exception: return []
def avg_margin():
    try: return round(float(Q("SELECT AVG(margin_pct) m FROM freight_quotes WHERE final_price>0").m[0] or 15), 1)
    except Exception: return 15.0
def m3_quote(a):
    rng = np.random.default_rng(_seed(a)); n = _runs(a)
    fuel, car, fx, disc, el = g(a, "pct", 0) / 100, g(a, "carrier", 0) / 100, g(a, "fx", 0) / 100, g(a, "discount", 0) / 100, g(a, "elasticity", 2.0)
    q = Q("SELECT quote_id, customer_id, carrier, base_cost, customs_fee, fuel_surcharge, final_price, margin_pct, status FROM freight_quotes WHERE final_price>0 ORDER BY created_at DESC, quote_id DESC LIMIT 400")
    if not len(q): return [B.callout("No quotes in the database yet.", "warn")]
    tm = g(a, "target_margin", float(q.margin_pct.mean())) / 100
    p0 = q.final_price.values; c0 = p0 * (1 - q.margin_pct.values / 100); bc, cf, fs = q.base_cost.values, q.customs_fee.values, q.fuel_surcharge.values
    fu = rng.normal(fuel, 0.08, n)[:, None]; cr = rng.normal(car, 0.03, n)[:, None]; fxs = rng.normal(fx, 0.03, n)[:, None]
    cost = c0 + bc * ((1 + cr) * (1 + fxs) - 1) + cf * fxs + fs * fu                       # runs × quotes
    price = cost / (1 - tm) * (1 - disc); win = np.clip(WIN_BASE * np.exp(-el * (price / p0 - 1)), 0, 0.95); prof = win * (price - cost)
    sel = a.get("quote") if a.get("quote") in set(q.quote_id) else q.quote_id.iloc[0]; j = int(np.where(q.quote_id.values == sel)[0][0])
    pp, pw = _pct3(price[:, j]), _pct3(win[:, j])
    sweep = np.arange(0.05, 0.351, 0.025); sw_win, sw_prof = [], []
    for m in sweep:
        pr = cost / (1 - m) * (1 - disc); w = np.clip(WIN_BASE * np.exp(-el * (pr / p0 - 1)), 0, 0.95); sw_win.append(float(np.median(w.mean(1)))); sw_prof.append(float(np.median((w * (pr - cost)).sum(1))))
    bm = float(sweep[int(np.argmax(sw_prof))])
    per = pd.DataFrame({"quote_id": q.quote_id, "carrier": q.carrier, "price now": p0, "price P10": np.percentile(price, 10, 0), "price P50": np.percentile(price, 50, 0), "price P90": np.percentile(price, 90, 0),
                        "win P10": np.percentile(win, 10, 0), "win P50": np.percentile(win, 50, 0), "win P90": np.percentile(win, 90, 0)}).sort_values("price now", ascending=False).head(15)
    starts = [("Quotes in the portfolio", f"{len(q)}", "freight_quotes"), ("Average margin today", f"{q.margin_pct.mean():.1f}%", "freight_quotes.margin_pct"),
              ("Average price", usd(p0.mean()), "freight_quotes.final_price"), ("Fuel surcharge share of price", f"{fs.sum() / p0.sum():.1%}", "freight_quotes.fuel_surcharge"),
              (f"Selected quote {sel}", f"{usd(p0[j])} at {q.margin_pct.values[j]:.1f}% margin ({q.status.values[j]})", "freight_quotes")]
    lines = [f"Cost of each quote today = price × (1 − its margin). Carrier rates move {car:+.0%} (±3 pts), currency {fx:+.0%} (±3 pts, applies to base cost and customs fee), fuel {fuel:+.0%} (±8 pts, applies to the fuel surcharge).",
             f"New price = cost ÷ (1 − target margin {tm:.1%}) × (1 − discount {disc:.0%}).",
             f"Chance of winning = {WIN_BASE:.0%} × exp(−{el:g} × price change), capped at 95%: a higher price wins less often (price sensitivity is a setting).",
             "Expected profit = chance of winning × (price − cost). Fuel, carrier and currency shocks are shared by all quotes in a run (one market)."]
    return [B.md("### Price band and chance of winning (Milestone 3)"), _assumptions(lines, a), _start(starts, "m3qt_s"),
            B.kpis((f"Price band {sel}", f"{usd(pp[0])} – {usd(pp[2])}", f"median {usd(pp[1])}, today {usd(p0[j])}"), (f"Chance of winning {sel}", f"{pw[1]:.0%}", f"P10 {pw[0]:.0%} · P90 {pw[2]:.0%}"),
                   ("Target margin", f"{tm:.1%}", f"today {q.margin_pct.mean():.1f}%"), ("Margin with the best expected profit", f"{bm:.1%}", f"{usd(max(sw_prof))} expected (median)")),
            _bands([("Price of " + sel, price[:, j], "usd"), ("Chance of winning " + sel, win[:, j], "pct"), ("Portfolio expected profit", prof.sum(1), "usd"), ("Average chance of winning (all quotes)", win.mean(1), "pct")], "Ranges", "m3qt_b"),
            B.row(B.card("Chance of winning vs target margin", B.chart(B.line([f"{m:.1%}" for m in sweep], {"avg win chance": [round(x, 3) for x in sw_win]}, area=False, colors=[BLUE], markers=True), h=250, key="m3qt_w")),
                  B.card("Expected profit vs target margin", B.chart(B.line([f"{m:.1%}" for m in sweep], {"expected profit": [round(x) for x in sw_prof]}, area=False, colors=[TEAL], markers=True), h=250, key="m3qt_p"))),
            B.table(per, ["quote_id", "carrier", B.num_col("price now", "price now", "money"), B.num_col("price P10", "price P10", "money"), B.num_col("price P50", "price P50", "money"), B.num_col("price P90", "price P90", "money"),
                          B.num_col("win P10", "win P10", "pct"), B.num_col("win P50", "win P50", "pct"), B.num_col("win P90", "win P90", "pct")], title="Price band and chance of winning per quote (15 largest)", h=380, open={"kind": "quote", "col": "quote_id"}, key="m3qt_t")]


# ------------------------------------------------------------------------------------------------ carrier: reliability, capacity shortage, ranking
def m3_carrier(a):
    rng = np.random.default_rng(_seed(a)); n = _runs(a)
    drop, short, loss, dc = g(a, "reliability_drop", 15), g(a, "shortage", 20) / 100, g(a, "loss", 100) / 100, g(a, "delay_cost", 120)
    c = Q("SELECT name, rating, on_time_pct ot, avg_cost_index ci, risk_level FROM carriers")
    act = Q("SELECT carrier, COUNT(*) n, AVG(weight_kg)/1000.0 t FROM shipments WHERE status IN ('In Transit','Quoted','Anchorage Pending','Port Congestion Delay') AND carrier IS NOT NULL GROUP BY carrier")
    c = c[c.name.isin(act.carrier)].merge(act, left_on="name", right_on="carrier", how="left")
    if not len(c): return [B.callout("No carriers with active shipments.", "warn")]
    name = a.get("carrier") if a.get("carrier") in set(c.name) else c.sort_values("n", ascending=False).name.iloc[0]
    k = len(c); dis = (c.name == name).values; t_avg = float((c.t * c.n).sum() / c.n.sum()); demand = loss * float(c.n[dis].sum())
    ot = np.clip(rng.normal((c.ot.values - np.where(dis, drop, drop * 0.15))[None, :], 3.0, (n, k)), 40, 99.5)     # 15% of the shock spills over to the market
    spare = (0.30 * c.n.values)[None, :] * (1 - short) * rng.lognormal(0, 0.25, (n, k)); spare[:, dis] = 0.0
    need = demand / max(k - 1, 1); fill = np.clip(spare / max(need, 1e-9), 0, 1) if demand > 0 else np.ones((n, k))
    base = 400.0 * t_avg * c.ci.values[None, :]; late = (1 - ot / 100) * 3.0 * dc; spot = (1 - fill) * 0.35 * base
    cost = base + late + spot; cost[:, dis] = base[:, dis] + late[:, dis] + 0.35 * base[:, dis] * loss         # the disrupted carrier itself: lost capacity is re-booked on the spot market
    pbest = np.bincount(cost.argmin(1), minlength=k) / n
    df = pd.DataFrame({"carrier": c.name, "on-time now": c.ot.values / 100, "on-time P50": np.median(ot, 0) / 100, "spare capacity P50": np.median(spare, 0), "cost P10": np.percentile(cost, 10, 0),
                       "cost P50": np.median(cost, 0), "cost P90": np.percentile(cost, 90, 0), "P(best)": pbest}).sort_values("cost P50").reset_index(drop=True)
    df.insert(0, "rank", range(1, len(df) + 1)); r_dis = int(df.index[df.carrier == name][0]) + 1
    starts = [("Carriers with active shipments", f"{k}", "carriers + shipments"), (f"{name}: on-time / cost index", f"{float(c.ot[dis].iloc[0]):.1f}% / {float(c.ci[dis].iloc[0]):.2f}", "carriers"),
              (f"{name}: active shipments", f"{int(c.n[dis].sum())}", "shipments"), ("Average shipment size", f"{t_avg:,.1f} t", "shipments.weight_kg")]
    lines = [f"Disruption at **{name}**: on-time falls by {drop:g} points and {loss:.0%} of its capacity is lost; 15% of the on-time shock spills over to every other carrier.",
             f"Market capacity shortage {short:.0%}: spare space at each carrier = 30% of its current load × (1 − shortage), with ±25% uncertainty.",
             f"On-time per run ~ Normal(database on-time − shock, 3 points). A late shipment loses 3 days at ${dc:g} per day.",
             "Cost per shipment = $400 × tonnes × cost index + expected late cost + 35% spot premium on the share that finds no space. Carriers are ranked by median cost (lower is better); P(best) = share of runs where the carrier is cheapest."]
    return [B.md("### Carrier ranking under a disruption (Milestone 3)"), _assumptions(lines, a), _start(starts, "m3cr_s"),
            B.kpis(("Best carrier under the disruption", df.carrier.iloc[0], f"best in {df['P(best)'].iloc[0]:.0%} of runs"), (f"{name} falls to", f"rank {r_dis} of {k}", f"on-time {float(df[df.carrier == name]['on-time P50'].iloc[0]):.0%} (median)"),
                   ("Shipments to re-place", f"{demand:,.0f}", f"{loss:.0%} of {name}'s load"), ("Capacity shortage", f"{short:.0%}", "market-wide")),
            _bands([(f"Cost per shipment, best carrier ({df.carrier.iloc[0]})", cost[:, int(np.where(c.name.values == df.carrier.iloc[0])[0][0])], "usd"), (f"Cost per shipment, {name}", cost[:, dis][:, 0], "usd"),
                    (f"On-time, {name}", ot[:, dis][:, 0] / 100, "pct")], "Ranges", "m3cr_b"),
            B.card("Median cost per shipment by carrier", B.chart(B.bar(list(df.carrier), {"cost P50": [round(x) for x in df["cost P50"]]}, horizontal=True, colors=[BLUE]), h=min(420, 60 + 26 * len(df)), key="m3cr_c")),
            B.table(df, [B.num_col("rank", "rank", "int"), "carrier", B.num_col("on-time now", "on-time now", "pct"), B.num_col("on-time P50", "on-time P50", "pct"), B.num_col("spare capacity P50", "spare space (shipments)", "num"),
                         B.num_col("cost P10", "cost P10", "money"), B.num_col("cost P50", "cost P50", "money"), B.num_col("cost P90", "cost P90", "money"), B.num_col("P(best)", "P(best)", "pct")], title="Carriers ranked under the disruption", h=420, key="m3cr_t")]


# ------------------------------------------------------------------------------------------------ weather: storm intensity + duration -> delay days, demurrage
def m3_weather(a):
    rng = np.random.default_rng(_seed(a)); n = _runs(a)
    area = a.get("area") or "Red Sea"; la, lo = STORM_AREAS.get(area, STORM_AREAS["Red Sea"]); inten = a.get("intensity") or "Use wind slider"
    wind = INTENSITY.get(inten, g(a, "wind", 25)); dur, rad, dem = g(a, "duration", 3), g(a, "radius", 900), g(a, "demurrage", 900)
    v = Q("SELECT v.shipment_id, v.lat, v.lon, s.dest_port d FROM vessels v JOIN shipments s USING(shipment_id)")
    p = Q("SELECT port_name, lat, lon FROM ports")
    if not len(v): return [B.callout("No tracked vessels.", "warn")]
    W = rng.normal(wind, 4.0, n); D_ = rng.gamma(6.0, max(dur, 0.1) / 6.0, n); Rd = np.clip(rng.normal(rad, 0.15 * rad, n), 100, None)
    cla, clo = la + rng.normal(0, 1.5, n), lo + rng.normal(0, 1.5, n)                       # storm track uncertainty ±1.5° (~90 nm)
    dist = hav(v.lat.values[None, :], _wrap(v.lon.values)[None, :], cla[:, None], clo[:, None])     # runs × vessels
    inside = dist <= Rd[:, None]; sev = np.clip((W - 12) / 28.0, 0, 2.0)[:, None]
    delay = inside * D_[:, None] * sev * (1 - 0.5 * np.minimum(dist / Rd[:, None], 1))
    pdist = hav(p.lat.values[None, :], p.lon.values[None, :], cla[:, None], clo[:, None]); closed = (pdist <= Rd[:, None]) & (W[:, None] > 25)
    pidx = {nm: i for i, nm in enumerate(p.port_name)}; di = np.array([pidx.get(x, -1) for x in v.d])
    dest_closed = np.where(di[None, :] >= 0, closed[:, np.clip(di, 0, None)], False)
    delay = delay + dest_closed * D_[:, None] * 0.5                                           # destination port closed for part of the storm
    tot = delay.sum(1); aff = (delay > 0).sum(1); demc = tot * dem
    pv = pd.DataFrame({"shipment_id": v.shipment_id, "destination": v.d, "P(affected)": (delay > 0).mean(0), "delay P50": np.median(delay, 0), "delay P90": np.percentile(delay, 90, 0)})
    pv = pv[pv["P(affected)"] > 0].sort_values(["P(affected)", "delay P90"], ascending=False).head(25)
    try: wx = Q("SELECT port_name, wind_ms, ts FROM wx_live"); wx["km"] = hav(la, lo, p.set_index("port_name").reindex(wx.port_name).lat.values, p.set_index("port_name").reindex(wx.port_name).lon.values); near = wx.sort_values("km").iloc[0]; live = f"{near.wind_ms:.1f} m/s at {near.port_name} ({str(near.ts)[:16]})"
    except Exception: live = "no live reading cached yet"
    starts = [("Tracked vessels", f"{len(v)}", "vessels"), ("Ports in the database", f"{len(p)}", "ports"), ("Live wind nearest the storm area", live, "wx_live (Open-Meteo cache)"),
              ("Vessels inside the radius today", f"{int((hav(v.lat.values, _wrap(v.lon.values), la, lo) <= rad).sum())}", "vessels")]
    lines = [f"Storm in **{area}**: intensity {inten if inten in INTENSITY else 'from the wind slider'} → wind {wind:g} m/s (±4 m/s), duration {dur:g} days (Gamma, ±40%), radius {rad:g} nm (±15%), track uncertain by ±1.5°.",
             "Severity = (wind − 12) ÷ 28, so 12 m/s does nothing and 40 m/s is a full stop; it can exceed 1 for a hurricane.",
             "A vessel inside the radius loses duration × severity × (1 − half its relative distance from the centre) days (it slows or waits).",
             "A destination port inside the radius closes while wind is above 25 m/s: half the storm duration is added for vessels heading there.",
             f"Demurrage and re-planning cost = delay days × ${dem:g} per shipment-day.",
             "Vessel positions are live (the worker moves them every few seconds), so a re-run a minute later starts from new positions; from the same positions the same seed repeats exactly."]
    return [B.md("### Storm intensity and duration: delay days and demurrage (Milestone 3)"), _assumptions(lines, a), _start(starts, "m3wx_s"),
            B.kpis(("Delay days (fleet, median)", f"{np.median(tot):,.1f}", f"P10 {np.percentile(tot, 10):,.1f} · P90 {np.percentile(tot, 90):,.1f}"), ("Demurrage cost (median)", usd(np.median(demc)), f"P90 {usd(np.percentile(demc, 90))}", "Critical" if np.median(demc) > 50000 else None),
                   ("Vessels affected (median)", f"{np.median(aff):.0f}", f"P90 {np.percentile(aff, 90):.0f}"), ("Storm", f"{wind:g} m/s · {dur:g} days", area)),
            _bands([("Delay days, whole fleet", tot, "days"), ("Delay per affected vessel", np.where(aff > 0, tot / np.maximum(aff, 1), 0), "days"), ("Demurrage + re-planning cost", demc, "usd"), ("Vessels affected", aff, "n")], "Ranges", "m3wx_b"),
            B.card("Demurrage cost across runs", B.chart(B.hist(list(np.round(demc)), bins=24, color=AMBER), h=240, key="m3wx_h")),
            B.table(pv, [{"k": "shipment_id", "label": "shipment", "type": "id"}, "destination", B.num_col("P(affected)", "P(affected)", "pct"), B.num_col("delay P50", "delay P50 (days)", "num"), B.num_col("delay P90", "delay P90 (days)", "num")],
                    title="Vessels most at risk", h=360, open={"kind": "shipment", "col": "shipment_id"}, key="m3wx_t")]


# ------------------------------------------------------------------------------------------------ customs: inspection rate, missing documents -> holding cost per day
def hold_share():
    try:
        s = Q("SELECT SUM(status='Customs Hold') h, COUNT(*) n FROM shipments WHERE status IN ('In Transit','Port Congestion Delay','Anchorage Pending','Customs Hold')"); return round(100.0 * float(s.h[0] or 0) / max(float(s.n[0] or 1), 1), 1)
    except Exception: return 10.0
def m3_customs(a):
    rng = np.random.default_rng(_seed(a)); n = _runs(a)
    insp, insp_d, miss, doc_d = g(a, "inspect", 10) / 100, g(a, "inspect_days", 2), g(a, "missing", hold_share()) / 100, g(a, "doc_delay", 3)
    hp, dw, sc, val, ir = g(a, "hold", 20) / 100, g(a, "dwell", 4), g(a, "storage", 180), g(a, "cargo_value", 2500), g(a, "interest", 9) / 100
    s = Q("SELECT shipment_id, dest_port d, weight_kg/1000.0 t, status, hs_code FROM shipments WHERE status IN ('In Transit','Port Congestion Delay','Anchorage Pending','Customs Hold')")
    if not len(s): return [B.callout("No inbound shipments.", "warn")]
    m = len(s); t = s.t.fillna(s.t.mean()).values; hc = sc + t * val * ir / 365.0                     # holding cost per shipment-day = storage + capital tied up
    ins = rng.random((n, m)) < insp; mis = rng.random((n, m)) < miss; pol = rng.random((n, m)) < hp
    days = ins * rng.gamma(3.0, max(insp_d, .1) / 3.0, (n, m)) + mis * rng.gamma(2.0, max(doc_d, .1) / 2.0, (n, m)) + pol * rng.gamma(4.0, max(dw, .1) / 4.0, (n, m))
    held = days > 0; perday = (held * hc[None, :]).sum(1); total = (days * hc[None, :]).sum(1); nheld = held.sum(1)
    by = pd.DataFrame({"port": s.d, "held": held.mean(0), "days": days.mean(0), "cost": (days * hc[None, :]).mean(0), "perday": (held * hc[None, :]).mean(0)}).groupby("port").agg(held=("held", "sum"), days=("days", "mean"), perday=("perday", "sum"), cost=("cost", "sum")).sort_values("cost", ascending=False).head(12).reset_index()
    duty = Q("SELECT AVG(duty_pct) d, COUNT(*) n FROM customs_rules")
    starts = [("Inbound shipments", f"{m}", "shipments (in transit / at anchorage / on hold)"), ("On customs hold today", f"{int((s.status == 'Customs Hold').sum())} ({hold_share():.1f}%)", "shipments.status"),
              ("Average cargo per shipment", f"{t.mean():,.1f} t", "shipments.weight_kg"), ("Customs rules / average duty", f"{int(duty.n[0])} chapters / {float(duty.d[0] or 0):.1f}%", "customs_rules")]
    lines = [f"Each inbound shipment is physically inspected with probability {insp:.0%} (adds ~{insp_d:g} days, Gamma), has missing documents with probability {miss:.0%} (adds ~{doc_d:g} days to fix, Gamma; the default is today's customs-hold share), "
             f"and is held by policy with probability {hp:.0%} (adds ~{dw:g} days).",
             f"Holding cost per shipment-day = storage ${sc:g} + capital cost (tonnes × ${val:g}/t × {ir:.0%} a year ÷ 365).",
             "Holding cost per day = what the held shipments cost together for each day they wait. Total = holding cost × days held, summed over shipments."]
    return [B.md("### Inspections and missing documents: holding cost per day (Milestone 3)"), _assumptions(lines, a), _start(starts, "m3cu_s"),
            B.kpis(("Holding cost per day (median)", usd(np.median(perday)), f"P10 {usd(np.percentile(perday, 10))} · P90 {usd(np.percentile(perday, 90))}"), ("Total holding cost (median)", usd(np.median(total)), f"P90 {usd(np.percentile(total, 90))}", "Critical" if np.median(total) > 100000 else None),
                   ("Shipments held (median)", f"{np.median(nheld):.0f}", f"of {m} inbound"), ("Average days held", f"{float(days[held].mean()) if held.any() else 0:.1f}", "per held shipment")),
            _bands([("Holding cost per day", perday, "usd"), ("Total holding cost", total, "usd"), ("Shipments held", nheld, "n"), ("Days held per held shipment", np.where(nheld > 0, days.sum(1) / np.maximum(nheld, 1), 0), "days")], "Ranges", "m3cu_b"),
            B.row(B.card("Holding cost per day across runs", B.chart(B.hist(list(np.round(perday)), bins=24, color=VIOLET), h=240, key="m3cu_h")),
                  B.card("Expected holding cost by destination", B.chart(B.bar(list(by.port), {"cost": [round(x) for x in by.cost]}, horizontal=True, colors=[VIOLET]), h=240, key="m3cu_c"))),
            B.table(by, ["port", B.num_col("held", "expected held shipments", "num"), B.num_col("days", "avg days held", "num"), B.num_col("perday", "holding cost / day", "money"), B.num_col("cost", "expected total", "money")], title="By destination port", h=360, key="m3cu_t")]


def _with_m3(base, m3):
    def run(a):
        r = base(a)
        try: extra = m3(a)
        except Exception as e:
            import traceback, sys; traceback.print_exc(file=sys.stderr); extra = [B.callout(f"Milestone 3 panel skipped: {e}", "warn")]
        return {**r, "blocks": extra + [B.md("### Scenario impact on the live lanes (original simulator)")] + r["blocks"]}
    return run


RUN = {"route": _with_m3(run_route, m3_route), "carriers": _with_m3(run_carrier, m3_carrier), "weather": _with_m3(run_weather, m3_weather),
       "quotes": _with_m3(run_quote, m3_quote), "margin": _with_m3(run_quote, m3_quote), "customs": _with_m3(run_customs, m3_customs)}
ASSUME = {**ASSUME,
          "route (Milestone 3)": "Three real sea routes compared under closures, a storm and a fuel price move; speed, dwell and fuel are random (common random numbers); canal tolls Suez $7/t, Panama $9/t; fuel is 45% of freight. Output: P10/P50/P90 days and cost, and how often each route is cheapest / fastest.",
          "quote (Milestone 3)": "Target margin, fuel, carrier rate and currency move the cost; price = cost ÷ (1 − margin) × (1 − discount); win chance = 45% × exp(−sensitivity × price change). Output: price band (P10–P90) and chance of winning per quote, plus the margin that maximises expected profit.",
          "carrier (Milestone 3)": "A disruption cuts one carrier's on-time and capacity; the market has a capacity shortage. Cost per shipment = $400 × t × cost index + late cost + spot premium for unplaced load. Output: carriers ranked by median cost with P10/P90 and P(best).",
          "weather (Milestone 3)": "Storm intensity (Saffir-Simpson) and duration with track, size and wind uncertainty; vessels inside slow or wait, destination ports close above 25 m/s. Output: delay days and demurrage cost P10/P50/P90.",
          "customs (Milestone 3)": "Inspection rate, missing documents and policy holds add Gamma-distributed days; holding cost per day = storage + capital cost. Output: holding cost per day and total P10/P50/P90, by port."}
