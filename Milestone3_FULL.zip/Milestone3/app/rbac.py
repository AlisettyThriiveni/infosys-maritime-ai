"""Central server-side role-based access control for FreightQuote."""
from fastapi import HTTPException

PAGE_IDS = {"copilot", "route", "quotes", "carriers", "weather", "margin", "customs", "profile", "admin"}
ROLE_MENU = {
    "Admin": PAGE_IDS,
    "Operations Manager": {"copilot", "route", "carriers", "weather", "customs", "profile"},
    "Freight Broker": {"copilot", "quotes", "carriers", "margin", "profile"},
    "Auditor": {"copilot", "route", "quotes", "carriers", "weather", "margin", "customs", "profile"},
    "Customer": {"copilot", "quotes", "profile"},
}
ROLE_CAPS = {
    "Admin": {"quote_create", "quote_view", "run_agents", "reroute", "inject_storm", "customs_edit", "manage_users", "view_activity", "read_all"},
    "Operations Manager": {"run_agents", "reroute", "customs_edit", "read_operations"},
    "Freight Broker": {"quote_create", "quote_view", "read_commercial"},
    "Auditor": {"quote_view", "read_all"},
    "Customer": {"quote_create", "quote_view", "read_own_shipments"},
}
ROLE_ALIASES = {"administrator": "Admin", "operations mgr": "Operations Manager", "operations manager": "Operations Manager", "freight broker": "Freight Broker", "auditor": "Auditor", "customer": "Customer", "admin": "Admin"}
MENU_LABELS = {"copilot": ("AI Copilot", "bot"), "route": ("Agent 1 · Route AI", "route"), "quotes": ("Agent 2 · Spot Quotes", "dollar"), "carriers": ("Agent 3 · Carriers", "truck"), "weather": ("Agent 4 · Weather Risk", "cloud"), "margin": ("Agent 5 · Margin", "trend"), "customs": ("Agent 6 · Customs", "file"), "profile": ("My Profile", "user"), "admin": ("Admin", "shield")}

def normalize_role(role):
    raw = str(role or "Customer").strip()
    return ROLE_ALIASES.get(raw.lower(), raw if raw in ROLE_MENU else "Customer")

def menu_for(user):
    role = normalize_role(user.get("role") if isinstance(user, dict) else user)
    allowed = ROLE_MENU.get(role, ROLE_MENU["Customer"])
    return [(pid, *MENU_LABELS[pid]) for pid in MENU_LABELS if pid in allowed]

def need(ctx, capability):
    role = normalize_role(ctx.get("role"))
    aliases = {"users": "manage_users", "run": "run_agents", "quote": "quote_create", "view": "quote_view", "approve": "reroute", "admin": "inject_storm", "resolve": "customs_edit"}
    cap = aliases.get(capability, capability)
    if cap not in ROLE_CAPS.get(role, set()):
        raise HTTPException(status_code=403, detail=f"Role '{role}' does not have the '{cap}' capability.")

def need_page(user, page_id):
    role = normalize_role(user.get("role"))
    if page_id not in ROLE_MENU.get(role, set()):
        raise HTTPException(status_code=403, detail="Your role cannot access this page.")
