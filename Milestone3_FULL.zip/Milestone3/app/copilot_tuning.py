"""Admin-managed Copilot intent aliases, synonym routing, prompts and answer-rate measurement."""
import re, sqlite3, time
from config import DB_PATH, KIND

DEFAULT_INTENTS = {
    "ports": ["port", "ports", "harbour", "harbor", "terminal", "congestion", "berth", "berth crowding", "dwell time", "port crowding"],
    "shipments": ["shipment", "consignment", "cargo movement", "container", "tracking", "voyage", "transit", "delivery"],
    "quotes": ["quote", "quotation", "freight rate", "freight rate estimate", "spot rate", "pricing", "price estimate", "cost estimate", "margin", "baf"],
    "weather": ["weather", "wind", "wave", "storm", "cyclone", "typhoon", "rough sea", "forecast", "marine conditions"],
    "customs": ["customs", "tariff", "duty", "hs code", "clearance", "clearance paperwork", "import", "export", "documentation"],
    "alerts": ["alert", "incident", "incident register", "disruption", "delay", "exception", "hold", "risk event", "ticket"],
    "carriers": ["carrier", "shipping line", "liner", "operator", "transport provider", "on-time performance", "reliability"],
    "customers": ["customer", "client", "client credit exposure", "shipper", "account", "credit risk"],
    "vessels": ["vessel tracking", "ship tracking", "vessel", "ship", "ais", "live location", "position", "speed", "progress"],
}
DEFAULT_PROMPTS = {
    "answer": "Answer only from live FreightQuote database results or approved Teach Copilot knowledge. Never invent values. If evidence is missing, say what is missing and suggest a supported question.",
    "clarify": "If a question is ambiguous between two data areas, ask one short clarification instead of guessing.",
    "format": "Lead with the direct answer, then give the relevant entity IDs and concise supporting details. Preserve units and distinguish live from simulated data.",
}

def init():
    with sqlite3.connect(DB_PATH) as c:
        c.execute("""CREATE TABLE IF NOT EXISTS copilot_synonyms (
            id INTEGER PRIMARY KEY AUTOINCREMENT, intent TEXT NOT NULL,
            phrase TEXT NOT NULL COLLATE NOCASE UNIQUE, enabled INTEGER NOT NULL DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        c.execute("""CREATE TABLE IF NOT EXISTS copilot_prompts (
            prompt_key TEXT PRIMARY KEY, prompt_text TEXT NOT NULL,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        c.execute("CREATE TABLE IF NOT EXISTS copilot_tuning_state (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        c.execute("INSERT OR IGNORE INTO copilot_tuning_state(key,value) VALUES('phase','before')")
        c.execute("""CREATE TABLE IF NOT EXISTS copilot_query_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT NOT NULL,
            intent TEXT, answered INTEGER NOT NULL, source TEXT,
            phase TEXT NOT NULL DEFAULT 'before', latency_ms INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        for intent, phrases in DEFAULT_INTENTS.items():
            for phrase in phrases:
                c.execute("INSERT OR IGNORE INTO copilot_synonyms(intent,phrase) VALUES(?,?)", (intent, phrase))
        for key, prompt in DEFAULT_PROMPTS.items():
            c.execute("INSERT OR IGNORE INTO copilot_prompts(prompt_key,prompt_text) VALUES(?,?)", (key,prompt))
        c.commit()

def normalize(q):
    return re.sub(r"[^a-z0-9\s]", " ", str(q or "").lower()).strip()

def classify(q):
    qn = " " + normalize(q) + " "
    best, score = "general", 0
    with sqlite3.connect(DB_PATH) as c:
        rows = c.execute("SELECT intent,phrase FROM copilot_synonyms WHERE enabled=1 ORDER BY length(phrase) DESC").fetchall()
    for intent, phrase in rows:
        p = " " + normalize(phrase) + " "
        if p.strip() and p in qn:
            n = len(p)
            if n > score: best, score = intent, n
    return best

def expand_query(question):
    """Attach a canonical domain anchor when a configured synonym identifies an intent."""
    intent = classify(question)
    anchors = {"ports":"port", "shipments":"shipment", "quotes":"quote", "weather":"weather",
               "customs":"customs", "alerts":"ticket", "carriers":"carrier", "customers":"customer", "vessels":"vessel"}
    anchor = anchors.get(intent)
    q = str(question or "").strip()
    return (q + " " + anchor) if anchor and anchor not in normalize(q).split() else q

def prompt_text(key):
    with sqlite3.connect(DB_PATH) as c:
        r = c.execute("SELECT prompt_text FROM copilot_prompts WHERE prompt_key=?", (key,)).fetchone()
    return r[0] if r else DEFAULT_PROMPTS.get(key, "")

def log_query(question, answered, source="", latency_ms=0):
    if not str(question or "").strip(): return
    intent = classify(question)
    with sqlite3.connect(DB_PATH) as c:
        phase_row = c.execute("SELECT value FROM copilot_tuning_state WHERE key='phase'").fetchone()
        phase = phase_row[0] if phase_row else "before"
        c.execute("INSERT INTO copilot_query_logs(question,intent,answered,source,phase,latency_ms) VALUES(?,?,?,?,?,?)",
                  (str(question)[:800], intent, int(bool(answered)), str(source)[:80], phase, int(latency_ms or 0)))
        c.commit()

def add_synonym(intent, phrase):
    intent, phrase = str(intent).strip().lower(), str(phrase).strip()
    if intent not in DEFAULT_INTENTS or not phrase or len(phrase)>80: raise ValueError("Choose a supported intent and enter a phrase (1–80 characters).")
    with sqlite3.connect(DB_PATH) as c:
        c.execute("INSERT INTO copilot_synonyms(intent,phrase) VALUES(?,?)", (intent,phrase))
        c.execute("UPDATE copilot_tuning_state SET value='after' WHERE key='phase'")
        c.commit()

def set_prompt(key, value):
    key, value = str(key).strip(), str(value).strip()
    if key not in DEFAULT_PROMPTS or not value or len(value)>1200: raise ValueError("Choose a valid prompt section and enter text (maximum 1,200 characters).")
    with sqlite3.connect(DB_PATH) as c:
        c.execute("INSERT INTO copilot_prompts(prompt_key,prompt_text,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(prompt_key) DO UPDATE SET prompt_text=excluded.prompt_text,updated_at=CURRENT_TIMESTAMP", (key,value))
        c.execute("UPDATE copilot_tuning_state SET value='after' WHERE key='phase'")
        c.commit()

def insights():
    with sqlite3.connect(DB_PATH) as c:
        c.row_factory = sqlite3.Row
        rows = c.execute("SELECT phase,COUNT(*) total,SUM(answered) answered,ROUND(AVG(latency_ms),1) avg_ms FROM copilot_query_logs GROUP BY phase").fetchall()
        top = c.execute("SELECT intent,COUNT(*) total,SUM(answered) answered FROM copilot_query_logs GROUP BY intent ORDER BY total DESC LIMIT 10").fetchall()
        n_syn = c.execute("SELECT COUNT(*) FROM copilot_synonyms WHERE enabled=1").fetchone()[0]
        n_prompts = c.execute("SELECT COUNT(*) FROM copilot_prompts").fetchone()[0]
    out = {}
    for r in rows:
        total=int(r["total"] or 0); good=int(r["answered"] or 0)
        out[r["phase"]]={"total":total,"answered":good,"unanswered":total-good,"rate":round(100*good/total,1) if total else None,"avg_ms":r["avg_ms"]}
    return {"phases":out,"intents":[dict(r) for r in top],"synonyms":n_syn,"prompts":n_prompts}

def benchmark():
    # Fixed, repeatable questions used to compare answer coverage before and after tuning.
    tests = [
      "Which berth has the highest crowding index?",
      "How many consignments are delayed?",
      "Show the freight rate estimate for recent requests.",
      "Which cargo movements are on customs hold?",
      "Which shipping line has the poorest punctuality?",
      "Show marine conditions at monitored locations.",
      "How many AIS positions are being tracked?",
      "Which clients have the highest credit exposure?",
      "Show clearance paperwork requirements.",
      "Show the incident register for current freight operations."
    ]
    import analyst as AN
    import qa as QA
    with sqlite3.connect(DB_PATH) as c:
        phase_row=c.execute("SELECT value FROM copilot_tuning_state WHERE key='phase'").fetchone()
    phase=phase_row[0] if phase_row else "before"
    results=[]
    for q in tests:
        try:
            tested_q = expand_query(q) if phase == "after" else q
            # Match the live Copilot answer path: analyst handlers first, then
            # the same whitelisted SQL fallback used by /api/copilot.
            r=AN.answer(KIND,tested_q,None,None,None) or QA.answer(KIND,tested_q,None,None)
            ok=bool(r and r.get("answer"))
            results.append({"question":q,"answered":ok})
        except Exception:
            results.append({"question":q,"answered":False})
    good=sum(x["answered"] for x in results)
    for x in results: log_query(x["question"], x["answered"], "Benchmark", 0)
    return {"total":len(results),"answered":good,"unanswered":len(results)-good,"rate":round(100*good/len(results),1),"results":results}
