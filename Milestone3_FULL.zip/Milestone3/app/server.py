"""Web server: FastAPI JSON API + server-sent events + the single-page front end. Models live on the GPU in this process; the simulator and agent cycles run in worker.py."""
import os as _os, time as _time
_os.environ["TZ"] = "Asia/Kolkata"
try: _time.tzset()
except Exception: pass          # all times in this app are India Standard Time (IST)
import sqlite3, os, sys, io, re, csv, json, time, asyncio, subprocess, threading, importlib, datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config
from config import KIND, DB_PATH
from fastapi import FastAPI, Request, Response, HTTPException, UploadFile, File, Form, Header
from fastapi.responses import JSONResponse, StreamingResponse, FileResponse, HTMLResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
import pandas as pd
import numpy as np
import mailer, reports as RP
import privacy as PV, qa as QA, analyst as AN, live_engine as LE, live_rbac as RB, data_feeder as FD, authx, gpu, rag, entities as EN, blocks as B
import views_core as VC, views_misc as VM, persist as PS
import auth as M2A, rbac as M2R      # [M3] Milestone 2 sign-in (bcrypt, lockout ladder, OTP/security-question reset, customer link) and roles
dom = importlib.import_module("domain_franchise" if KIND == "Franchise" else "domain_freight")
V = importlib.import_module("views_franchise" if KIND == "Franchise" else "views_freight")
HERE = os.path.dirname(os.path.abspath(__file__)); STATIC = os.path.join(HERE, "static")
app = FastAPI(title=f"{V.NAME} Platform", docs_url=None, redoc_url=None, openapi_url=None) if os.environ.get("PUBLIC_DOCS") != "1" else FastAPI(title=f"{V.NAME} Platform"); _worker = None; _ready = {"db": False}
import hardening; hardening.install(app, KIND); PV.start()

@app.middleware("http")
async def sec(request, call_next):
    r = await call_next(request); r.headers["X-Content-Type-Options"] = "nosniff"; r.headers["Referrer-Policy"] = "same-origin"; r.headers["Cache-Control"] = "no-store" if request.url.path.startswith("/api") else r.headers.get("Cache-Control", "public, max-age=300"); return r

def _boot():
    from db import init_db; from seed_data import seed_all
    PS.restore()                                                  # bring the database back from Google Drive after a runtime reset
    init_db(); seed_all(); LE.init_live_tables(); authx.init(); M2A.init_auth(); FD.init(); TUNE.init(); _ready["db"] = True; PS.start()
    try: _migrate_taught()                                          # [M3] Milestone 2 copilot_knowledge rows -> copilot_taught (one counter)
    except Exception as e: print("taught migration:", repr(e), file=sys.stderr)
    try:
        _c = LE.conn(); LE._steps_ddl(_c); _c.commit()          # the approval table exists from the first start, not only after the first ticket
    except Exception as e: print("approval table:", repr(e), file=sys.stderr)
    threading.Thread(target=_warm_up, daemon=True).start()
    threading.Thread(target=lambda: rag._seed(), daemon=True).start()   # builds the knowledge base (built-in pack + your Drive chunks) right at start
def _warm_up():
    """Runs once the models are up: one dummy search, rerank, translation and generation, so the first real question is not the one that pays for CUDA kernels and caches."""
    try:
        for _ in range(150):
            m = gpu.S["models"]
            if all(m[k]["state"] in ("ready", "failed") for k in ("embed", "rerank", "nllb")) and m["llm"]["state"] in ("ready", "failed"): break
            time.sleep(4)
        try: rag.search("refund policy and approval limits", "warm", 3, "hybrid", True)
        except Exception: pass
        try: gpu.translate("How many outlets are open today?", "hin_Deva", "eng_Latn")
        except Exception: pass
        try:
            if gpu.llm_ready(): gpu.llm_text([{"role": "user", "content": "Say OK."}], max_new_tokens=4, temperature=0.0)
        except Exception: pass
        try: VC.decision()
        except Exception: pass
    except Exception as e: print("warm-up:", repr(e), file=sys.stderr)
@app.on_event("startup")
def startup():
    global _worker
    _boot(); gpu.start()
    if os.environ.get("NO_WORKER") != "1":
        env = {**os.environ, "APP_KIND": KIND}; _worker = subprocess.Popen([sys.executable, os.path.join(HERE, "worker.py")], env=env, cwd=HERE)
@app.on_event("shutdown")
def shutdown():
    try: PS.stop()
    except Exception: pass
    if _worker:
        try: _worker.terminate()
        except Exception: pass

# ------------------------------------------------------------------ auth + context
def user_of(request: Request):
    """[M3] One identity store: the Milestone 2 `users` table (auth.py, cookie freightquote_session).
    Kept over the reference sign-in because it adds bcrypt, a 3-strike / 5-lockout ladder, e-mail OTP + security-question
    reset, Milestone 1 account import and the customer link that limits a Customer to their own quotes."""
    m = M2A.current_user(request)
    if not m: raise HTTPException(401, "not signed in")
    return {"email": m["email"], "username": m["username"], "role": M2R.normalize_role(m.get("role")), "customer_id": m.get("customer_id"), "id": m.get("id"),
            "avatar": m.get("avatar"), "created_at": m.get("created_at"), "last_login": m.get("last_login")}
def _is_customer(u): return M2R.normalize_role(u.get("role")) == "Customer"
def ctx(u, params=None):
    role = RB.norm(u["role"]) if u["role"] in RB.CAPS else u["role"]; scope = RB.scope_for(u["email"]) if role in RB.SCOPED else None
    return {"dom": dom, "kind": KIND, "role": u["role"], "email": u["email"], "user": u, "scope": scope, "params": params or {}}
def need(c, cap):
    if not RB.can(c["role"], cap): raise HTTPException(403, f"role {c['role']} cannot {cap}")
def menu_for(role): return [m for m in V.MENU if m[0] in V.ROLE_MENU.get(role, {"copilot"})]
def ok(msg="Done", **kw): return {"ok": True, "msg": msg, **kw}
def bad(msg): return JSONResponse({"ok": False, "msg": msg}, status_code=400)

# [M3] Sign-in, sign-up, OTP and password reset come from the Milestone 2 module auth.py (router /api/auth/*, page /login).
# The reference endpoints /api/login, /api/register, /api/otp, /api/question and /api/reset were removed so there is only one account store.
@app.post("/api/logout")
def logout(request: Request):
    u = M2A.current_user(request)
    if u: LE.audit(u["email"], "logout", "", "")
    r = JSONResponse({"ok": True}); sec_ = request.headers.get("x-forwarded-proto") == "https"
    r.set_cookie("sid", "", max_age=0, expires=0, path="/", httponly=True, samesite="lax", secure=sec_); r.delete_cookie("sid", path="/"); r.delete_cookie(M2A.COOKIE_NAME, path="/"); return r
@app.get("/api/public")
def public():
    s = LE.get_state("boot", {}) if _ready["db"] else {}
    return {"kind": KIND, "name": V.NAME, "stage": (s or {}).get("stage", "starting"), "gpu": {"cuda": gpu.S["cuda"], "name": gpu.S["gpu"]}, "questions": list(M2A.SECURITY_QUESTIONS), "email_enabled": mailer.configured(), "demo": M2A.demo_logins()}
@app.get("/api/me")
def me(request: Request):
    u = user_of(request); c = ctx(u); caps = sorted(RB.CAPS.get(u["role"], set()))
    return {"user": u, "kind": KIND, "name": V.NAME, "menu": [{"id": i, "label": l, "icon": ic} for i, l, ic in menu_for(u["role"])], "caps": caps, "scope": c["scope"], "langs": list(gpu.NLLB_LANGS), "questions": list(M2A.SECURITY_QUESTIONS)}

# ------------------------------------------------------------------ live pulse
def pulse():
    rt = LE.get_state("runtime", {}) or {}; boot = LE.get_state("boot", {}) or {}
    d = VC.decision(); oa = B.Q("SELECT status, severity, COUNT(*) n FROM agent_actions WHERE status IN ('open','proposed') GROUP BY status, severity")
    n = lambda st, sv=None: int(oa[(oa.status == st) & ((oa.severity == sv) if sv else True)].n.sum()) if len(oa) else 0
    g = gpu.status()
    return {"stage": boot.get("stage", "starting"), "ticks": rt.get("ticks", 0), "cycles": rt.get("cycles", 0), "last_cycle": rt.get("last_cycle"), "health": d["score"] if d else None, "risk": d["risk"] if d else None, "dec": d["id"] if d else 0,
            "open": n("open"), "critical": n("open", "Critical"), "proposed": n("proposed"), "gpu": {"cuda": g["cuda"], "name": g["gpu"], "used": g["vram_used_gb"], "total": g["vram_gb"], "llm": g["models"]["llm"]["state"], "llm_name": g["models"]["llm"]["name"], "llm_done": g["models"]["llm"].get("done_gb"), "llm_total": g["models"]["llm"].get("total_gb"), "llm_err": g["models"]["llm"]["err"], "nllb": g["models"]["nllb"]["state"], "embed": g["models"]["embed"]["state"], "tok_s": g["stats"]["tok_s"]}, "worker_alive": (_worker is None or _worker.poll() is None)}
@app.get("/api/pulse")
def pulse_http(request: Request): user_of(request); return pulse()
@app.get("/api/stream")
async def stream(request: Request):
    user_of(request)
    async def gen():
        last = None; t0 = time.time()
        while True:
            if await request.is_disconnected(): break
            try: p = await asyncio.to_thread(pulse)
            except Exception as e: p = {"error": str(e)}
            k = json.dumps(p, sort_keys=True, default=str)
            if k != last or time.time() - t0 > 10: last = k; t0 = time.time(); yield f"data: {k}\n\n"
            await asyncio.sleep(1.5)
    return StreamingResponse(gen(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# ------------------------------------------------------------------ pages
_TABS = {}
def _tabs_of(c, f):
    if f not in _TABS: _TABS[f] = f(c, None).get("tabs")
    return _TABS[f]
def _simtabs(t): return (t or [{"id": "main", "label": "Overview"}]) + [{"id": "sim", "label": "Simulator"}]
def _page(c, pid, tab):
    if pid == "command": return VC.command(c, tab or "ops")
    if pid == "approvals": return VC.approvals(c, tab or "awaiting")
    if pid == "kg": return VC.kg_page(c, tab or "net")
    if pid == "copilot": return VM.copilot(c, tab or "chat")
    if pid == "notifications": return VM.notifications(c, tab or "alerts")
    if pid == "twin": return VM.twin(c, tab)
    if pid == "feeds": return VM.feeds(c, tab or "upload")
    if pid == "admin": return VM.admin(c, tab or "runtime")
    if pid == "reports": return VM.reports(c, tab or "pdf")
    if pid == "profile": return VM.profile(c, tab or "me")
    if pid == "users": return B.page("Admin Dashboard", "User access, roles and administrative activity (Milestone 2)", [], live=0)   # [M3] drawn by app.js renderAdminPanel()
    f = V.PAGES.get(pid)
    if f:
        if tab == "sim":
            sm = VM.simulator(c, pid); return {**sm, "title": sm["title"], "tabs": _simtabs(_tabs_of(c, f)), "live": 0}
        o = f(c, None if tab == "main" else tab); _TABS[f] = o.get("tabs"); o["tabs"] = _simtabs(o.get("tabs")); return o
    raise HTTPException(404, "unknown page")
@app.get("/api/page/{pid}")
def page(pid: str, request: Request, tab: str = "", p: str = ""):
    u = user_of(request); c = ctx(u, json.loads(p) if p else {})
    if pid not in V.ROLE_MENU.get(u["role"], set()): raise HTTPException(403, "no access to this page")
    t = time.time(); out = _page(c, pid, tab or None); out["id"] = pid; out["ms"] = round((time.time() - t) * 1000); return JSONResponse(B.clean(out))
@app.get("/api/detail/{eid:path}")
def detail(eid: str, request: Request):
    u = user_of(request); c = ctx(u)
    if _is_customer(u):                                              # [M3] Milestone 2: a Customer may open only their own quotes
        with sqlite3.connect(DB_PATH) as _cn: _qr = _cn.execute("SELECT customer_id FROM freight_quotes WHERE quote_id=?", (eid,)).fetchone()
        if not _qr or not u.get("customer_id") or _qr[0] != u.get("customer_id"): raise HTTPException(403, "You can only view your own quotes.")
    if c["scope"] and not eid.startswith(c["scope"]): raise HTTPException(403, "outside your outlet")
    return JSONResponse(B.clean(V.detail(c, eid)))

# ------------------------------------------------------------------ tickets, cycles, policy
def _tk(aid):
    r = LE.conn().execute("SELECT target, type, status FROM agent_actions WHERE action_id=?", (aid,)).fetchone()
    if not r: raise HTTPException(404, "ticket not found")
    return r
@app.post("/api/approval/request")
async def approval_request(request: Request):
    u = user_of(request); c = ctx(u); need(c, "view"); d = await request.json(); det = str(d.get("detail", "")).strip()[:600]
    if len(det) < 5: return bad("Describe what you need approved (a sentence or two).")
    tg = str(d.get("target", "")).strip()[:60] or "general"
    if c["scope"] and tg != "general" and not tg.startswith(c["scope"]): return bad(f"You can only raise requests for your outlet ({c['scope']}).")
    sev = d.get("severity") if d.get("severity") in ("Info", "Warning", "Critical") else "Warning"
    aid = LE.request_approval(dom, str(d.get("kind", "Other"))[:60], tg, det, sev, u["email"], d.get("levels") or 1)
    return ok(f"Request #{aid} sent. Track it under Approvals > Request approval.", refresh=True)
@app.post("/api/ticket/{aid}/{action}")
async def ticket(aid: int, action: str, request: Request):
    u = user_of(request); c = ctx(u); d = await request.json() if request.headers.get("content-length", "0") != "0" else {}; tg, typ, st = _tk(aid)
    if c["scope"] and not str(tg).startswith(c["scope"]): raise HTTPException(403, "outside your outlet")
    em = u["email"]
    if action in ("approve", "reject"):
        need(c, "approve"); yes = action == "approve"
        if st == "proposed":
            s2, msg = LE.approve_action(dom, aid, em, yes, d.get("note", ""), c["role"])
            if s2 in ("denied", "missing"): return bad(msg)
            return ok(("Approved and executed" if s2 == "final" else (msg[:1].upper() + msg[1:])) if yes else "Rejected")
        elif typ == "quote_approval" and hasattr(dom, "decide"):
            s2, msg = LE.advance(aid, em, c["role"], yes, d.get("note", ""))
            if s2 in ("denied", "missing"): return bad(msg)
            if s2 == "partial": return ok((msg[:1].upper() + msg[1:]))
            dom.decide(aid, yes, em); return ok("Approved and executed" if yes else "Rejected")
        else: raise HTTPException(400, "nothing to approve on this ticket")
    if action == "resolve": need(c, "resolve"); LE.resolve_action(aid, "resolved", f"by {em}", actor=em); return ok("Resolved")
    if action == "assign": need(c, "resolve"); LE.assign_action(aid, d.get("assignee"), em); return ok("Assigned")
    if action == "comment": need(c, "view"); LE.comment_action(aid, em, str(d.get("body", ""))[:500]); return ok("Posted")
    raise HTTPException(400, "unknown action")
@app.post("/api/run_cycle")
def run_cycle(request: Request):
    u = user_of(request); c = ctx(u); need(c, "run"); t = time.time(); LE.run_cycle(dom, "manual", ""); LE.audit(u["email"], "manual_cycle", "all"); return ok(f"Agents finished in {time.time() - t:.1f}s")
@app.post("/api/run_agent")
async def run_agent(request: Request):
    u = user_of(request); c = ctx(u); need(c, "run"); a = (await request.json()).get("agent")
    if a not in dom.AGENTS: raise HTTPException(404, "unknown agent")
    await asyncio.to_thread(_run_one, a); LE.audit(u["email"], "manual_agent", a); return ok(f"{a} re-ran")
def _run_one(agent):
    cid = time.strftime("%m%d-%H%M%S") + "-page"; t = time.time(); s = {"cycle_id": cid, "trigger": "page", "request": "", "queue": [], "results": {}}
    if agent == "digest":
        for a in ("outlet", "inventory", "staff", "marketing", "audit"): s["results"][a] = dom.AGENTS[a](s)
    res = dom.AGENTS[agent](s); LE._log_run(cid, "page", res, int((time.time() - t) * 1000)); s["results"][agent] = res; LE.act(dom, {"actions": res.actions}, cid, {agent: res})
@app.post("/api/sla")
def sla(request: Request): u = user_of(request); c = ctx(u); need(c, "run"); return ok(f"{LE.escalate_overdue(dom)} ticket(s) escalated")
@app.post("/api/notify_test")
def notify_test(request: Request): u = user_of(request); c = ctx(u); need(c, "admin"); LE.notify(dom, "TEST", "Critical", "Test", "Test alert from the Notifications page"); return ok("Sent to every configured channel")
@app.post("/api/policy")
async def policy(request: Request):
    u = user_of(request); c = ctx(u); need(c, "admin"); d = await request.json(); cur = LE.policy(dom)
    for t, m in d.items():
        if t in dom.ACTION_AGENT and m in ("auto", "approval") and cur.get(t, "auto") != m: LE.set_policy(t, m, u["email"])
    return ok("Policy saved")
@app.get("/api/audit.csv")
def audit_csv(request: Request):
    u = user_of(request); c = ctx(u)
    if not (RB.can(c["role"], "admin") or c["role"] == "Auditor"): raise HTTPException(403)
    return PlainTextResponse(B.Q("SELECT ts, actor, event, target, detail FROM audit_log ORDER BY audit_id DESC LIMIT 20000").to_csv(index=False), headers={"Content-Disposition": "attachment; filename=audit_log.csv"}, media_type="text/csv")

# ------------------------------------------------------------------ admin users
@app.post("/api/user/role")
async def user_role(request: Request):
    u = user_of(request); c = ctx(u); need(c, "admin"); d = await request.json()
    if d["role"] not in authx.ROLES: return bad("unknown role")
    authx.set_role(d["email"], d["role"]); LE.audit(u["email"], "role_change", d["email"], d["role"]); return ok("Role updated; it applies on the user's next request")
@app.post("/api/user/unlock")
async def user_unlock(request: Request): u = user_of(request); c = ctx(u); need(c, "admin"); d = await request.json(); authx.unlock(d["email"]); LE.audit(u["email"], "unlock", d["email"]); return ok("Unlocked")
@app.post("/api/user/scope")
async def user_scope(request: Request): u = user_of(request); c = ctx(u); need(c, "admin"); d = await request.json(); RB.set_scope(d["email"], d["outlet"]); LE.audit(u["email"], "scope_assign", d["email"], d["outlet"]); return ok("Saved")

# ------------------------------------------------------------------ digital twin
@app.post("/api/twin/run")
async def twin_run(request: Request):
    u = user_of(request); c = ctx(u); need(c, "view"); d = await request.json(); d.pop("scenario", None); c["email"] = u["email"]; t = time.time()
    if d.get("agents") not in ("yes", True): d["agents"] = False
    else: d["agents"] = True
    try: bl = await asyncio.to_thread(VM.twin_run, c, d)
    except Exception as e: return bad(f"Could not simulate: {e}")
    return ok(f"Simulated in {time.time() - t:.1f}s", blocks=B.clean(bl))
@app.post("/api/twin/saved")
async def twin_saved(request: Request):
    u = user_of(request); c = ctx(u); need(c, "view"); d = await request.json(); import twin2 as T2
    s = T2.saved().set_index("name")
    if d.get("a") not in s.index: return bad("unknown scenario")
    a = json.loads(s.loc[d["a"]].args); bl, _ = await asyncio.to_thread(T2.run, c, a); return ok("Re-run on today's data", blocks=B.clean(bl))
@app.post("/api/twin/compare")
async def twin_cmp(request: Request):
    u = user_of(request); c = ctx(u); need(c, "view"); d = await request.json()
    try: return ok("Compared", blocks=B.clean(await asyncio.to_thread(VM.twin_compare, c, d["a"], d["b"])))
    except Exception as e: return bad(f"Could not compare: {e}")
@app.post("/api/twin/propose")
async def twin_propose(request: Request):
    u = user_of(request); c = ctx(u); need(c, "approve"); d = await request.json(); import twin2 as T2
    txt = await asyncio.to_thread(T2.propose, KIND, str(d.get("action", ""))[:200], str(d.get("detail", "")), u["email"]); return ok("Sent to the approval queue (Actions > awaiting approval)", refresh=False)
@app.post("/api/sim/run")
async def sim_run(request: Request):
    u = user_of(request); c = ctx(u); need(c, "view"); d = await request.json(); d.pop("scenario", None); pg = d.pop("page", None); t = time.time()
    if pg not in ("route", "quotes", "carriers", "weather", "margin", "customs"): return bad("page must be one of route, quotes, carriers, weather, margin, customs")   # [M3 AUDIT]
    try: bl = await asyncio.to_thread(VM.sim_run, c, pg, "sim", d)
    except Exception as e: return bad(f"Could not simulate: {e}")
    return ok(f"Simulated in {time.time() - t:.1f}s", blocks=B.clean(bl))

# ------------------------------------------------------------------ data feeds
@app.post("/api/feed/upload")
async def feed_upload(request: Request, file: UploadFile = File(...), table: str = Form(...)):
    u = user_of(request); c = ctx(u); need(c, "feeder")
    if table not in FD.ALLOWED[KIND]: return bad("table not allowed")
    try: df = FD.read_any(file.filename, await file.read()); mp = FD.auto_map(df, table); n, badn = await asyncio.to_thread(FD.ingest, df, table, mp, "upload:" + file.filename)
    except Exception as e: return bad(str(e))
    return ok(f"{n} rows ingested, {badn} rejected. Columns matched: {len(mp)}.", blocks=[B.table(df.head(8), list(df.columns), title="Preview of the file", h=240, key="fprev")])
@app.post("/api/feed/url")
async def feed_url(request: Request):
    u = user_of(request); c = ctx(u); need(c, "feeder"); d = await request.json()
    if d.get("target") not in FD.ALLOWED[KIND] or not str(d.get("url", "")).startswith("http"): return bad("need an http(s) URL and an allowed table")
    with LE._DB_LOCK, LE.conn() as cn: cn.execute("INSERT INTO feed_urls(url,target,every_s,auth_env,json_path) VALUES(?,?,?,?,?)", (d["url"], d["target"], max(30, int(d.get("every", 300))), (d.get("auth_env") or "").strip() or None, (d.get("json_path") or "").strip() or None))
    LE.audit(u["email"], "feed_url", d["target"], d["url"]); return ok("Feed registered", refresh=True)
@app.post("/ingest/{table}")
@app.post("/api/ingest/{table}")
async def ingest_api(table: str, request: Request, x_api_key: str = Header(default=""), idempotency_key: str = Header(default="")):
    import hmac; k = os.environ.get("INGEST_KEY", "")
    if not k or not hmac.compare_digest(x_api_key.encode(), k.encode()): raise HTTPException(401, "bad or missing X-API-Key (set INGEST_KEY)")
    if table == "ais" and KIND == "Freight": table = "vessels"
    if table not in FD.ALLOWED[KIND]: raise HTTPException(400, "table not allowed")
    if idempotency_key and await asyncio.to_thread(FD.seen_key, table + ":" + idempotency_key): return {"accepted": 0, "rejected": 0, "duplicate": True}
    body = await request.body()
    try:
        rows = [json.loads(l) for l in body.decode().splitlines() if l.strip()] if body[:1] not in (b"[", b"{") or b"\n{" in body.strip() else json.loads(body)
        if isinstance(rows, dict): rows = rows.get("rows", [rows])
        if len(rows) > 50000: raise ValueError("max 50,000 rows per request")
        n, badn = await asyncio.to_thread(FD.ingest, pd.DataFrame(rows), table, None, "api:" + table)
    except Exception as e: raise HTTPException(400, str(e))
    return {"accepted": n, "rejected": badn, "note": "rejected rows are listed in Data Feed Center > Quality"}
@app.post("/api/feed/ais_map")
async def feed_ais_map(request: Request):
    u = user_of(request); need(ctx(u), "feeder"); d = await request.json(); pairs = [l.split(",") for l in str(d.get("pairs", "")).splitlines() if "," in l]; FD.init()
    with LE._DB_LOCK, LE.conn() as cn: cn.executemany("INSERT OR REPLACE INTO ais_map VALUES(?,?)", [(a.strip(), b.strip()) for a, b in pairs])
    LE.audit(u["email"], "ais_map", "vessels", f"{len(pairs)} ids"); return ok(f"{len(pairs)} MMSI to shipment links saved", refresh=True)
@app.get("/api/feed/rejects.csv")
async def feed_rejects(request: Request):
    u = user_of(request); need(ctx(u), "feeder"); FD.init(); df = B.Q("SELECT * FROM feed_rejects ORDER BY id DESC LIMIT 5000")
    return Response(df.to_csv(index=False), media_type="text/csv", headers={"Content-Disposition": 'attachment; filename="rejected_rows.csv"'})
@app.post("/api/gov/purge")
async def gov_purge(request: Request):
    u = user_of(request); need(ctx(u), "admin"); d = await request.json(); dry = str(d.get("mode", "dry")) != "run"; rows = await asyncio.to_thread(PV.purge, dry, u["email"])
    return ok(("Dry run: nothing deleted. " if dry else "Purged. ") + f"{sum(r['older_rows'] for r in rows):,} rows past retention.", blocks=[B.table(rows, ["table", B.num_col("keep_days", "keep (days)", "int"), B.num_col("older_rows", "past retention", "int"), B.num_col("deleted", "deleted", "int")], h=300, key="gv_p")])
@app.post("/api/gov/retention")
async def gov_retention(request: Request):
    u = user_of(request); need(ctx(u), "admin"); d = await request.json(); cur = PV.policy()
    try: cur[str(d["table"])] = max(7, int(d["days"]))
    except Exception: return bad("table and days (min 7) required")
    if d["table"] not in PV.RETENTION: return bad("unknown table")
    LE.set_state("retention", cur); LE.audit(u["email"], "retention_set", d["table"], str(d["days"])); return ok("Retention updated", refresh=True)
@app.post("/api/gov/dsar")
async def gov_dsar(request: Request):
    u = user_of(request); need(ctx(u), "admin"); d = await request.json(); key = str(d.get("subject", "")).strip(); act = d.get("action", "export")
    if not key: return bad("enter a staff id or a login email")
    if act == "erase":
        n = await asyncio.to_thread(PV.erase_subject, key, u["email"]); return ok("Erased / anonymised: " + json.dumps(n))
    data = await asyncio.to_thread(PV.export_subject, key); LE.audit(u["email"], "dsar_export", PV._hash(key), ",".join(data))
    return ok(f"{sum(len(v) for v in data.values())} records found" if data else "Nothing held for this subject.", blocks=[B.md("```\n" + json.dumps(data, indent=1, default=str)[:6000] + "\n```")] if data else [])

# ------------------------------------------------------------------ Franchise actions
@app.post("/api/franchise/review")
async def fr_review(request: Request):
    import uuid; u = user_of(request); c = ctx(u); d = await request.json(); tx = str(d.get("comment", "")).strip()
    if not tx: return bad("Write a comment first")
    if c["scope"] and d["outlet"] != c["scope"]: return bad("outside your outlet")
    src = gpu.detect(tx); en = PV.redact(gpu.translate(tx, "eng_Latn", src)[0] if src != "eng_Latn" else tx)
    try: from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer; sc = SentimentIntensityAnalyzer().polarity_scores(en)["compound"]
    except Exception: sc = (int(d["rating"]) - 3) / 2
    rt = int(d["rating"])
    with LE._DB_LOCK, LE.conn() as cn: cn.execute("INSERT INTO feedback(feedback_id,outlet_id,rating,comment,date,sentiment_score) VALUES(?,?,?,?,?,?)", ("FB-U" + uuid.uuid4().hex[:10], d["outlet"], rt, en, datetime.date.today().isoformat(), .6 * (rt - 3) / 2 + .4 * sc))
    LE.emit("review", d["outlet"], {"rating": rt}); return ok(f"Stored for {d['outlet']} (sentiment {sc:+.2f}{', translated from ' + src if src != 'eng_Latn' else ''}). The Sentiment agent includes it in its next cycle.", refresh=True)
@app.post("/api/franchise/audit")
async def fr_audit(request: Request):
    import uuid; u = user_of(request); c = ctx(u); need(c, "resolve"); d = await request.json(); sc = int(d["score"])
    if c["scope"] and d["outlet"] != c["scope"]: return bad("outside your outlet")
    with LE._DB_LOCK, LE.conn() as cn: cn.execute("INSERT INTO audits(audit_id,outlet_id,audit_date,score,violations,category,status,notes) VALUES(?,?,?,?,?,?,?,?)", ("AUD-U" + uuid.uuid4().hex[:10], d["outlet"], datetime.date.today().isoformat(), sc, int((100 - sc) / 6), d["category"], "Pass" if sc >= 80 else "Warning" if sc >= 60 else "Fail", d.get("notes", "")))
    LE.emit("audit", d["outlet"], {"score": sc}); LE.audit(u["email"], "audit_logged", d["outlet"], str(sc)); await asyncio.to_thread(_run_one, "audit"); return ok("Saved and evaluated by the Audit agent.", refresh=True)

# ------------------------------------------------------------------ Freight actions
@app.post("/api/freight/quote")
async def fq_quote(request: Request):
    u = user_of(request); c = ctx(u); need(c, "quote"); d = await request.json()
    if any(not d.get(k) for k in ("o", "d", "cargo", "weight", "hs")): return bad("o, d, cargo, weight and hs are required")   # [M3 AUDIT]
    if d["o"] == d["d"]: return bad("Origin and destination must differ.")
    if _is_customer(u):                                              # [M3] Milestone 2 data isolation
        if not u.get("customer_id"): raise HTTPException(403, "Your account is not linked to a customer record.")
        d["customer"] = u["customer_id"]
    rid = dom.submit_request(d["o"], d["d"], d["cargo"], float(d["weight"]), d["hs"], d["customer"], "English", d.get("docs") or []); await asyncio.to_thread(dom.run_quote, rid); LE.audit(u["email"], "quote_created", str(rid), f"{d['o']}->{d['d']}")
    return ok("Quote generated", blocks=B.clean(V.quote_result(rid)))
@app.post("/api/freight/storm")
async def fq_storm(request: Request):
    from twin import PRESET_STORMS; u = user_of(request); c = ctx(u); need(c, "admin"); d = await request.json() if request.headers.get("content-length", "0") not in ("0", "2") else {}
    la, lo = PRESET_STORMS.get(d.get("area") or "Red Sea"); dom.inject_storm(la, lo, wind=float(d.get("wind", 24))); LE.audit(u["email"], "inject_storm", d.get("area", "Red Sea")); return ok("Storm injected. The weather agent will propose re-routes on its next cycle.", refresh=True)
@app.post("/api/freight/reroute")
async def fq_reroute(request: Request):
    u = user_of(request); c = ctx(u); need(c, "approve"); j = await request.json(); sid = j["shipment"]; opt = j.get("opt")
    idx = int(str(opt).split(".")[0]) - 1 if opt else None; act = {"type": "reroute", "target": sid}
    if idx is not None: act["opt_label"] = str(opt).split(" · ", 1)[-1]; act["opt_idx"] = idx
    with LE._DB_LOCK, LE.conn() as cn: note = dom.apply(act, cn)
    LE.audit(u["email"], "manual_reroute", sid, note); return ok(note or "no change", refresh=True)
@app.post("/api/freight/attach")
async def fq_attach(request: Request):
    u = user_of(request); c = ctx(u)
    if not (RB.can(c["role"], "resolve") or RB.can(c["role"], "quote")): raise HTTPException(403)
    d = await request.json()
    if not d.get("ref") or not d.get("doc"): return bad("ref and doc are required")
    if _is_customer(u):                                               # [M3 AUDIT] a Customer may attach only to its own quote requests
        ref = str(d["ref"]); own = None
        with sqlite3.connect(DB_PATH) as _cn:
            if ref.startswith("QTE-L") and ref[5:].isdigit(): own = _cn.execute("SELECT customer_id FROM quote_requests WHERE req_id=?", (int(ref[5:]),)).fetchone()
            elif ref.startswith("QTE-"): own = _cn.execute("SELECT customer_id FROM freight_quotes WHERE quote_id=?", (ref,)).fetchone()
        if not own or not u.get("customer_id") or own[0] != u.get("customer_id"): raise HTTPException(403, "You can only attach documents to your own quotes.")
    dom.attach_doc(d["ref"], d["doc"], u["email"]); LE.audit(u["email"], "doc_attached", d["ref"], d["doc"]); return ok("Attached. Quotes re-run immediately; shipments clear on the next customs cycle.", refresh=True)
@app.post("/api/freight/readdoc")
async def fq_readdoc(request: Request, file: UploadFile = File(...)):
    u = user_of(request); data = await file.read(); txt = ""
    try:
        if file.filename.lower().endswith(".pdf"):
            import pdfplumber
            with pdfplumber.open(io.BytesIO(data)) as pdf: txt = "\n".join((pg.extract_text() or "") for pg in pdf.pages)
        else: txt = data.decode("utf-8", errors="ignore")
    except Exception as e: return bad(f"Could not read the file: {e}")
    hs = re.findall(r"HS[- ]?\d{2,8}", txt); q = re.findall(r"QTE-L\d+", txt); wt = re.findall(r"(\d+(?:\.\d+)?)\s*(?:t|tons|kg)\b", txt)
    return ok("Read", blocks=[B.table([{"field": "HS code", "value": ", ".join(dict.fromkeys(hs)) or "-"}, {"field": "Quote reference", "value": ", ".join(dict.fromkeys(q)) or "-"}, {"field": "Weights", "value": ", ".join(wt[:3]) or "-"}], ["field", "value"], title="Fields found", h=170, key="ocr"), B.md("```\n" + txt[:2500] + "\n```")])
@app.get("/api/doc/{name}")
def doc(name: str, request: Request):
    user_of(request); p = os.path.join(getattr(dom, "DATA_DIR", config.DATA_DIR), "docs", os.path.basename(name))
    if not os.path.exists(p): raise HTTPException(404); return FileResponse(p, filename=os.path.basename(name))

# ------------------------------------------------------------------ language, knowledge base
@app.post("/api/translate_batch")
async def translate_batch(request: Request):
    user_of(request); d = await request.json(); texts = [str(t)[:700] for t in d.get("texts", [])[:400]]; out, err = await asyncio.to_thread(gpu.translate_many, texts, d.get("lang", "eng_Latn")); return {"out": out, "err": err}
@app.post("/api/translate_doc")
async def translate_doc(request: Request):
    user_of(request); data = ""; text = ""; lang = "Hindi (हिंदी)"
    if "json" in request.headers.get("content-type", ""):
        j = await request.json(); text = str(j.get("text", "")); lang = j.get("lang", lang)
    else:
        fm = await request.form(); text = str(fm.get("text", "") or ""); lang = fm.get("lang", lang); file = fm.get("file")
        if file is not None and getattr(file, "filename", ""):
            try: data = rag.read_pdf(file.filename, await file.read())
            except Exception as e: return bad(f"Could not read the file: {e}")
    t = (data or text).strip()
    if not t: return bad("Paste text or choose a file")
    src = gpu.detect(t); t0 = time.time(); out, err = await asyncio.to_thread(gpu.translate, t[:20000], gpu.code_of(lang), src)
    if err: return bad(err)
    return ok(f"Translated from {src} to {gpu.code_of(lang)} in {time.time() - t0:.1f}s on {gpu.S['models']['nllb']['device']}", blocks=[B.card("Translation", B.md(out))])
@app.post("/api/kb/upload")
async def kb_upload(request: Request, file: UploadFile = File(...)):
    u = user_of(request)
    try: txt = rag.read_pdf(file.filename, await file.read())
    except Exception as e: return bad(f"Could not read the file: {e}")
    n = await asyncio.to_thread(rag.add, file.filename, "uploaded by you", txt, u["email"]); LE.audit(u["email"], "kb_upload", file.filename, f"{n} chunks"); return ok(f"{n} passages indexed ({gpu.S['models']['embed']['device'] or 'tf-idf'}).", refresh=True)
@app.post("/api/kb/search")
async def kb_search(request: Request):
    u = user_of(request); d = await request.json(); q = d.get("q", ""); mode = {"BM25 only": "bm25", "Dense only": "dense"}.get(d.get("mode"), "hybrid"); t0 = time.time()
    hits = await asyncio.to_thread(rag.search, q, u["email"], 6, mode, True)
    if d.get("live", "no") in ("yes", True): hits += await asyncio.to_thread(rag.live_hits, q, 4)
    return ok(f"{len(hits)} passage(s) in {(time.time() - t0) * 1000:.0f} ms", blocks=[B.card(f"{h['title']} · {h['source']}", B.md(h["text"]), sub=f"score {h['score']} · {h.get('why', '')}") for h in hits] or [B.callout("Nothing relevant found.", "info")])
@app.post("/api/kb/drive")
async def kb_drive(request: Request):
    u = user_of(request); need(ctx(u), "admin"); n = await asyncio.to_thread(rag.import_drive); LE.audit(u["email"], "kb_drive_import", rag.drive_dir(), f"{n} chunks")
    return ok(f"{n} chunks loaded from your Drive RAG index ({rag.drive_dir()})" if n else f"Nothing found in {rag.drive_dir()}/synthetic_kb. Mount Drive and run your RAG builder first.", refresh=True)
@app.get("/api/kb/export")
async def kb_export(request: Request):
    u = user_of(request); data = await asyncio.to_thread(rag.export_json, u["email"]); return JSONResponse(data, headers={"Content-Disposition": 'attachment; filename="kb_export.json"'})
@app.post("/api/kb/import")
async def kb_import(request: Request, file: UploadFile = File(...)):
    u = user_of(request)
    try: n, same = await asyncio.to_thread(rag.import_json, json.loads(await file.read()), u["email"])
    except Exception as e: return bad(f"Could not import: {e}")
    LE.audit(u["email"], "kb_import", file.filename, f"{n} chunks"); return ok(f"{n} passages imported" + (" with their embeddings." if same else "; embeddings will be recomputed on the GPU."), refresh=True)
@app.post("/api/kb/eval")
async def kb_eval(request: Request):
    u = user_of(request); need(c := ctx(u), "view"); rows = await asyncio.to_thread(rag.evaluate, KIND)
    return ok("Evaluated", blocks=[B.table(rows, ["method", B.num_col("recall@1", "recall@1", "num"), B.num_col("recall@3", "recall@3", "num"), B.num_col("MRR", "MRR", "num"), "note"], title="Retrieval quality on the built-in question set", h=240, key="kb_ev"), B.callout("This question set is small and written alongside the sample documents, so scores are optimistic. Use the builder notebook to evaluate on your own corpus and questions.", "info")])

# ------------------------------------------------------------------ Copilot (agents first, then the GPU LLM; NLLB for every language) + executive brief
def _sse(ev, **kw): return f"data: {json.dumps({'ev': ev, **kw}, default=str)}\n\n"
INSIGHT_SYS = "You are the operations copilot. An EXACT RESULT from the database is given in the EVIDENCE: do not repeat it or its table. In at most two short sentences add the most useful insight or next action, using the agent findings and the numbered sources when they help. Use only numbers that appear in the EVIDENCE. Cite a source as [1] when you use it. If you have nothing useful to add, answer exactly: NONE"
SYSTEM = "You are the operations copilot of an agentic platform. Answer ONLY from the EVIDENCE. FORMAT RULES: reply in exactly this layout and nothing else. Line 1: '**Answer:** ' plus one sentence of at most 25 words. Then up to 3 numbered points ('1. ...'), each at most 20 words, one fact each, with entity ids when the evidence has them. Last line, only if the evidence supports an action: '**Next step:** ' plus one short action. Quote numbers exactly as given and never invent any. Cite every fact that comes from a numbered source as [1], [2] matching the SOURCES list; facts from the database or the agents need no citation. If the evidence does not answer the question, reply exactly: I do not have that in the data or documents yet."
def _nums_ok(ans, ev):
    ans = re.sub(r"\[\d{1,2}\]|(?m:^\s*\d{1,2}[.)]\s)", " ", ans)        # citation markers and list numbering are not data
    have = set(re.findall(r"\d+(?:\.\d+)?", ev)); return all(n in have for n in re.findall(r"\d+(?:\.\d+)?", ans))
import copilot_pro as CP
import copilot_tuning as TUNE  # Team integration: Sushma synonym/prompt tuning + benchmark
CP_EXAMPLES = ["Which outlets are at highest risk?", "Why is OUT-007 flagged?", "How is inventory holding up?", "Top 5 outlets by revenue"] if KIND == "Franchise" else ["Mumbai to Singapore 50 t electronics: days, cost and best route", "Which port has the highest congestion?", "How many shipments are on customs hold?", "Quotes with margin below 10%"]
@app.post("/api/copilot")
async def copilot(request: Request):
    u = user_of(request); c = ctx(u); d = await request.json(); q = str(d.get("q", ""))[:800]; lang = d.get("lang", "English"); tgt = gpu.code_of(lang); SID = u["email"] + ":" + str(d.get("sid") or "default")[:40]
    _guard = _copilot_role_guard(u, q)                                # [M3] Milestone 2 RBAC inside the Copilot
    if _guard is not None: return StreamingResponse(_guard, media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
    def gen():
        t0 = time.time(); src = gpu.detect(q); en = q
        if src != "eng_Latn":
            en, err = gpu.translate(q, "eng_Latn", src); yield _sse("stage", text=f"Detected {src}; translated to English with NLLB-200 on {gpu.S['models']['nllb']['device'] or 'cpu'}")
        dec = VC.decision(); exact = None
        try: en = TUNE.expand_query(en)
        except Exception as _tune_err: print("Copilot synonym expansion skipped:", repr(_tune_err), file=sys.stderr)
        direct, en, pres, notes, pids = CP.prepare(KIND, en, SID, dom, VC.decision, CP_EXAMPLES, c.get("scope") or None, PV.mask_role(u["role"]))
        _cust = _is_customer(u)                                       # [M3 AUDIT] Customer: documents and taught answers only, never company data
        if _cust:
            if direct and (direct.get("sql") or (direct.get("route") != "taught" and not re.match(r"^\W*(hi|hello|hey|thanks|thank you|good (morning|afternoon|evening))\b", en, re.I))): direct = None
            pres = None; pids = []
        if notes: yield _sse("note", text=" · ".join(notes))
        if direct:
            txt = direct["text"]
            if tgt != "eng_Latn": txt = gpu.translate(txt, tgt, "eng_Latn")[0]
            CP.log_turn(q, direct.get("route", "chat"), round((time.time() - t0) * 1000))
            yield _sse("final", text=txt, sql=direct.get("sql", ""), sugg=direct.get("sugg"), en=(direct["text"] if tgt != "eng_Latn" else None), lang=lang, ms=round((time.time() - t0) * 1000), tok_s=gpu.S["stats"]["tok_s"]); yield _sse("done"); return
        analytic = bool(re.search(r"\b(why|explain|reason|recommend|should|suggest|advise|what to do|how can|how do|improve|summar)", en, re.I))
        try: exact = None if _cust else (pres or AN.answer(KIND, en, c.get("scope") or None, dec, dom) or QA.answer(KIND, en, c.get("scope") or None, PV.mask_role(u["role"])))
        except Exception as e: print("qa failed:", repr(e), file=sys.stderr)
        try:
            if exact and exact.get("answer") and CP.is_knowledge_q(en) and CP.weak_match(en, exact): exact = None; pres = None; yield _sse("stage", text="That table does not match the question, so it is not shown. Looking in the knowledge base instead…")
        except Exception: pass
        fast = bool(exact and exact.get("answer") and (not analytic or exact.get("complete")))
        trace = []
        kno = bool(not (exact and exact.get("answer")) and not pids and (CP.is_knowledge_q(en) or CP.is_term_q(en))) or _cust
        if fast:
            planned = dom.plan(en); dd = {"narrative": dec["narrative"], "actions": [], "agents": dec["ev"].get("agents", {})} if dec else {"narrative": "", "actions": [], "agents": {}}
            trace = [{"agent": k, "risk": v["risk"], "score": v["score"], "finding": v["summary"][:160]} for k, v in dd.get("agents", {}).items() if k in planned]
            if trace: yield _sse("trace", rows=trace)
        elif kno:
            planned = []; dd = {"narrative": "", "actions": [], "agents": {}}; yield _sse("stage", text="Knowledge question: searching the documents (agents skipped).")
        else:
            planned = dom.plan(en); yield _sse("stage", text="Planner selected: " + ", ".join(planned))
            stale = (not dec) or (datetime.datetime.now() - datetime.datetime.fromisoformat(dec["ts"])).total_seconds() > 300      # the worker refreshes the agents every 60 s: reuse its latest results
            if stale:
                yield _sse("stage", text="Running the selected agents and the Intelligence Engine…"); dd = LE.run_cycle(dom, "copilot", en)
            else: dd = {"narrative": dec["narrative"], "actions": [], "agents": dec["ev"].get("agents", {})}
            yield _sse("stage", text=f"Agents ready in {time.time() - t0:.1f}s")
            trace = [{"agent": k, "risk": v["risk"], "score": v["score"], "finding": v["summary"][:160]} for k, v in dd.get("agents", {}).items() if k in planned]
            if trace: yield _sse("trace", rows=trace)
        if exact and exact.get("answer"):
            yield _sse("stage", text="Exact answer from your live data (read-only query)"); yield _sse("exact", sql=exact["sql"], rows=0 if exact["df"] is None else len(exact["df"]))
        planned = locals().get("planned") or []
        facts = [] if (fast or kno) else EN.facts(KIND, dom, en); sql_fact = ""
        if not (fast or kno):
            try: from intent_router import run_grounded_query; sql_fact, _ = run_grounded_query(en)
            except Exception: pass
        kb = (CP.relevant(en, rag.search(en, u["email"], 3, "hybrid", False)) if fast else (rag.search(en, u["email"], 4, "hybrid", gpu.llm_ready()) + ([] if _cust else rag.live_hits(en, 2)))); acts = dd.get("actions", [])[:8]
        if kb: yield _sse("cites", rows=[{"n": n + 1, "title": h["title"], "source": h["source"], "why": h.get("why", ""), "score": h["score"], "text": h["text"][:240]} for n, h in enumerate(kb)])
        _k0 = None
        if kno and kb and tgt == "eng_Latn":
            _k0 = CP.kb_answer(en, [h for h in kb if h.get("via") != "live"])
            if _k0: yield _sse("partial", text=_k0)                      # instant extractive answer; a model answer replaces it only for how/why/explain questions
        ev = (f"EXACT RESULT (from the database, authoritative): {exact['answer']}\n{QA.md(exact['df'])}\n" if exact and exact.get("answer") else "") + f"{dd.get('narrative', '')} Top actions: " + " | ".join(f"{a['type']} {a['target']} ({a.get('severity')}): {a['detail']}" for a in acts) + (" Entities: " + " ".join(facts) if facts else "") + (f" Data lookup: {str(sql_fact)[:900]}" if sql_fact else "") + (" Sources: " + " ".join(f"[{n + 1}] ({h['title']}) {h['text'][:320]}" for n, h in enumerate(kb)) if kb else "")
        EXAMPLES = ["Which outlets are at highest risk?", "Why is OUT-007 flagged?", "How is inventory holding up?", "Top 5 outlets by revenue"] if KIND == "Franchise" else ["Mumbai to Singapore 50 t electronics: days, cost and best route", "Which port has the highest congestion?", "How many shipments are on customs hold?", "Quotes needing approval"]
        fallback = ("I could not compute an exact answer to that from the tables. What the agents responsible for this question found:\n" + "\n".join(f"- **{t['agent']}** ({t['risk']}): {t['finding']}" for t in trace if t["agent"] in planned) + (("\n\nRelated knowledge: " + "; ".join(h["title"] for h in kb[:3])) if kb else "") + "\n\nTry asking, for example: " + "; ".join(f'"{x}"' for x in EXAMPLES) + ".")
        ans = ""
        insight = False; _deco = None
        if exact and exact.get("answer"):
            _tb0 = (QA.md(exact["df"]) if exact.get("df") is not None else "") + (("\n\n" + exact["extra"]) if exact.get("extra") else "")
            if tgt == "eng_Latn": yield _sse("partial", text=exact["answer"] + (("\n\n" + _tb0) if _tb0 else ""))
            try:
                _deco = CP.decorate(KIND, SID, en, exact, pids)
                if _deco[0]: yield _sse("chart", block=_deco[0])
            except Exception as e: print("decorate failed:", repr(e), file=sys.stderr)
        _rows = 0 if not exact or exact.get("df") is None else len(exact["df"])
        if exact and exact.get("answer") and (not analytic or exact.get("complete")):
            if gpu.llm_ready() and analytic:
                yield _sse("stage", text=f"Writing the insight on {gpu.S['models']['llm']['device']} ({gpu.S['models']['llm']['name']})…")
                for piece in gpu.llm_stream([{"role": "system", "content": INSIGHT_SYS}, {"role": "user", "content": f"EVIDENCE:\n{ev[:2200]}\n\nQUESTION: {en}"}], max_new_tokens=70, temperature=0.0): ans += piece
                ans = ans.strip()
                if ans.upper().startswith("NONE") or len(ans) < 12 or not CP.sane(ans) or not _nums_ok(ans, ev): ans = ""
                else: ans = "**Insight:** " + ans; insight = True; yield _sse("tok", text=ans)
            elif not gpu.llm_ready(): yield _sse("stage", text="LLM not loaded (" + str(gpu.S["models"]["llm"]["state"]) + "): this answer uses SQL, the latest agent findings and the knowledge base only.")
        elif gpu.llm_ready() and not (kno and _k0 and not analytic):
            _tok_ok = False
            if fallback and tgt == "eng_Latn" and not exact: yield _sse("draft", text=fallback)      # shows the agents' findings at once; the model answer replaces it
            yield _sse("stage", text=f"Generating on {gpu.S['models']['llm']['device']} ({gpu.S['models']['llm']['name']})…")
            for piece in gpu.llm_stream([{"role": "system", "content": SYSTEM + (" An EXACT RESULT is given: start from it, do not contradict it, and add only the reasoning or advice asked for." if exact else "")}, {"role": "user", "content": f"EVIDENCE:\n{ev[:2200]}\n\nQUESTION: {en}"}], max_new_tokens=150, temperature=0.0):
                ans += piece
                if not _tok_ok:
                    if len(ans) >= 16:
                        if CP.sane(ans): _tok_ok = True; yield _sse("tok", text=ans)
                        else: break                                         # garbage from the model: stop and fall back to the evidence
                else: yield _sse("tok", text=piece)
            if not CP.sane(ans): ans = ""
            if not _nums_ok(ans, ev): yield _sse("stage", text="The model used a number that is not in the evidence: showing the evidence summary instead."); ans = ""
        else: yield _sse("stage", text="LLM not loaded (" + str(gpu.S["models"]["llm"]["state"]) + (": " + gpu.S["models"]["llm"]["err"] if gpu.S["models"]["llm"]["err"] else "") + "): answering from agent evidence.")
        if re.match(r"^\W*(no evidence|\[no evidence|i do not have that in the data)", ans.strip(), re.I) or len(ans.strip()) < 12: ans = ""
        llm_used = bool(ans.strip())
        if llm_used and not insight: ans = CP.finish(ans, kb)
        kba = None; kgap = False
        if not ans.strip() and not (exact and exact.get("answer")):
            kba = CP.kb_answer(en, [h for h in kb if h.get("via") != "live"])
            if kba: ans = kba
            elif (CP.is_knowledge_q(en) or CP.is_term_q(en)) and not pids:
                ans = "I do not have a document on that topic in the knowledge base yet, and the database has no numbers for it. Add documents with the RAG notebook or in AI Copilot → Knowledge base, then ask again."; kgap = True; CP.unanswered_note(q)
        ans = ans.strip() or (fallback if not (exact and exact.get("answer")) else "")
        tbl = (QA.md(exact["df"]) if exact and exact.get("df") is not None else "") + (("\n\n" + exact["extra"]) if exact and exact.get("extra") else ""); lead = exact["answer"] if exact and exact.get("answer") else ""
        ans_en = (lead + ("\n\n" + ans if ans else "")); final = ans_en + (("\n\n" + tbl) if tbl else "")
        if tgt != "eng_Latn":
            tr, err = gpu.translate(ans_en, tgt, "eng_Latn"); final = tr + (("\n\n" + tbl) if tbl else ""); yield _sse("stage", text=f"Translated to {lang} with NLLB-200" + (f" (failed: {err})" if err else ""))
        _drv = False
        try: _drv = os.path.isdir(rag.drive_dir())
        except Exception: pass
        yield _sse("layers", sql=bool(exact and exact.get("answer")), agents=len(trace), rag=len([h for h in kb if h.get("via") != "live"]), llm=llm_used, llm_state=str(gpu.S["models"]["llm"]["state"]), drive=_drv, kb_hit=bool(kba))
        cb, sg, has = None, ["What can you do?", "Briefing"], False
        if exact and exact.get("answer"):
            cb, sg, has = _deco or CP.decorate(KIND, SID, en, exact, pids); CP.log_turn(q, "exact" if fast or not analytic else "exact+llm", round((time.time() - t0) * 1000))
            if cb and not _deco: yield _sse("chart", block=cb)
        elif ans_en.strip().startswith("I could not compute"): CP.unanswered_note(q); CP.log_turn(q, "unanswered", round((time.time() - t0) * 1000))
        else: CP.log_turn(q, "knowledge" if kba else ("unanswered" if kgap else "agents+llm"), round((time.time() - t0) * 1000))
        try: TUNE.log_query(q, bool(final.strip()) and not final.strip().lower().startswith("i do not have"), "Copilot", round((time.time() - t0) * 1000))
        except Exception as _tune_err: print("Copilot tuning log skipped:", repr(_tune_err), file=sys.stderr)
        yield _sse("final", text=final, sugg=sg, csv=has, rows=(0 if not exact or exact.get("df") is None else len(exact["df"])), sql=(exact or {}).get("sql", ""), en=((ans_en + (("\n\n" + tbl) if tbl else "")) if tgt != "eng_Latn" else None), lang=lang, ms=round((time.time() - t0) * 1000), tok_s=gpu.S["stats"]["tok_s"]); yield _sse("done")
    _ck = (u["role"], str(c.get("scope") or ""), tgt, re.sub(r"\s+", " ", q.lower()).strip(" ?!."))
    _fu = bool(re.search(r"^(and|also|what about|how about|then|those|same)\b|\b(it|its|them|those|that one|this one)\b", q.lower()))
    def gen_cached():
        hit = _RC.get(_ck)
        if hit and not _fu and time.time() - hit[0] < hit[2]:
            t1 = time.time()
            try: CP.prepare(KIND, q, SID, dom, VC.decision, CP_EXAMPLES, c.get("scope") or None, PV.mask_role(u["role"]))      # keeps follow-up context
            except Exception: pass
            yield _sse("stage", text=f"Instant answer: the same question was answered {int(time.time() - hit[0])} s ago (refreshes automatically).")
            for e_ in hit[1]: yield _sse(e_["ev"], **{k_: v_ for k_, v_ in e_.items() if k_ != "ev"}) if e_["ev"] != "final" else _sse("final", **{**{k_: v_ for k_, v_ in e_.items() if k_ != "ev"}, "ms": round((time.time() - t1) * 1000), "cached": True})
            return
        rec = []
        for s_ in gen():
            yield s_
            try:
                e_ = json.loads(s_[6:])
                if e_.get("ev") not in ("stage", "tok"): rec.append(e_)
            except Exception: pass
        if any(e_.get("ev") == "layers" for e_ in rec) and any(e_.get("ev") == "final" for e_ in rec):
            if len(_RC) > 200: _RC.clear()
            _lay = next((e_ for e_ in rec if e_.get("ev") == "layers"), {}); _RC[_ck] = (time.time(), rec, 600 if (not _lay.get("sql") and not _lay.get("agents")) else 60)      # document answers do not depend on live data: keep 10 min
    return StreamingResponse(gen_cached(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
_BRIEF = {}
_RC = {}
def _chat_db():
    c = sqlite3.connect(DB_PATH, timeout=30); c.execute("PRAGMA journal_mode=WAL;"); c.execute("CREATE TABLE IF NOT EXISTS copilot_chats(id TEXT PRIMARY KEY, email TEXT, title TEXT, ts TEXT, data TEXT)"); c.execute("CREATE INDEX IF NOT EXISTS ix_chat_email ON copilot_chats(email, ts)"); return c
@app.get("/api/chats")
async def chats_list(request: Request):
    u = user_of(request)
    with _chat_db() as c: rows = c.execute("SELECT id, title, ts FROM copilot_chats WHERE email=? ORDER BY ts DESC LIMIT 60", (u["email"],)).fetchall()
    return {"ok": True, "chats": [{"id": r[0], "title": r[1], "ts": r[2]} for r in rows]}
@app.get("/api/chats/{cid}")
async def chats_get(cid: str, request: Request):
    u = user_of(request)
    with _chat_db() as c: r = c.execute("SELECT title, data FROM copilot_chats WHERE id=? AND email=?", (cid, u["email"])).fetchone()
    if not r: raise HTTPException(404, "chat not found")
    return {"ok": True, "title": r[0], "msgs": json.loads(r[1])}
@app.post("/api/chats/save")
async def chats_save(request: Request):
    u = user_of(request); d = await request.json(); cid = re.sub(r"[^a-zA-Z0-9_-]", "", str(d.get("id") or ""))[:40] or ("c" + str(int(time.time() * 1000))); msgs = d.get("msgs") or []
    if not isinstance(msgs, list) or not msgs: return bad("nothing to save")
    msgs = [{"role": m.get("role"), "text": str(m.get("text", ""))[:20000], "en": (str(m["en"])[:20000] if m.get("en") else None), "lang": m.get("lang"), "sql": str(m.get("sql") or "")[:1500]} for m in msgs[-80:]]
    title = next((m["text"] for m in msgs if m["role"] == "user"), "Chat")[:70]; now = datetime.datetime.now().isoformat(timespec="seconds")
    with _chat_db() as c:
        o = c.execute("SELECT email FROM copilot_chats WHERE id=?", (cid,)).fetchone()
        if o and o[0] != u["email"]: raise HTTPException(403, "not your chat")
        c.execute("INSERT OR REPLACE INTO copilot_chats VALUES(?,?,?,?,?)", (cid, u["email"], title, now, json.dumps(msgs)))
    PS.soon()
    return {"ok": True, "id": cid}
@app.delete("/api/chats/{cid}")
async def chats_del(cid: str, request: Request):
    u = user_of(request)
    with _chat_db() as c: c.execute("DELETE FROM copilot_chats WHERE id=? AND email=?", (cid, u["email"]))
    return {"ok": True}
@app.post("/api/weather/refresh")
async def wx_refresh(request: Request):
    u = user_of(request); c = ctx(u); need(c, "run")
    if KIND != "Freight": raise HTTPException(404)
    import weather as WX; n, msg = await asyncio.to_thread(WX.refresh); LE.audit(u["email"], "weather_refresh", "ports", msg)
    return ok(("Real weather updated: " if n else "Could not reach Open-Meteo, simulated values stay: ") + msg, refresh=True)
@app.post("/api/brief")
async def brief(request: Request):
    u = user_of(request)
    if _is_customer(u): raise HTTPException(403, "The executive brief is for staff roles.")       # [M3 AUDIT]
    d = await request.json(); lang = d.get("lang", "English"); tgt = gpu.code_of(lang); dec = VC.decision()
    def gen():
        if not dec: yield _sse("final", text="No decision yet."); return
        key = (dec["id"], tgt)
        if key in _BRIEF: yield _sse("final", text=_BRIEF[key]); return
        ev = json.dumps({k: v for k, v in dec["ev"].items() if k != "agents"}, default=str)[:1500] + " Agents: " + json.dumps(dec["ev"].get("agents", {}), default=str)[:1800]; txt = ""
        if gpu.llm_ready():
            for piece in gpu.llm_stream([{"role": "system", "content": "Write a 4-line executive briefing for the owner: status, biggest risk, what to approve now, what to watch. Use only numbers present in the data."}, {"role": "user", "content": ev}], max_new_tokens=200): txt += piece; yield _sse("tok", text=piece)
            if not _nums_ok(txt, ev): txt = ""
        txt = txt.strip() or dec["narrative"]; out = gpu.translate(txt, tgt, "eng_Latn")[0] if tgt != "eng_Latn" else txt; _BRIEF[key] = out; yield _sse("final", text=out)
    return StreamingResponse(gen(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# ------------------------------------------------------------------ reports, exports, profile, invitations
@app.get("/api/report/{rid}")
async def report(rid: str, request: Request, arg: str = ""):
    u = user_of(request); c = ctx(u)
    if "reports" not in V.ROLE_MENU.get(u["role"], set()): raise HTTPException(403, "no access to reports")
    if c["scope"] and arg and not arg.startswith(c["scope"]) and rid == "fr_outlet": raise HTTPException(403, "outside your outlet")
    try: name, data = await asyncio.to_thread(RP.build_pdf, KIND, rid, c, arg or None)
    except KeyError: raise HTTPException(404, "unknown report")
    LE.audit(u["email"], "report", rid, arg); return Response(data, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{name}"'})
@app.post("/api/report/email")
async def report_email(request: Request):
    u = user_of(request); c = ctx(u); d = await request.json(); rid = d.get("rid")
    if "reports" not in V.ROLE_MENU.get(u["role"], set()): raise HTTPException(403)
    try: name, data = await asyncio.to_thread(RP.build_pdf, KIND, rid, c, d.get("arg") or None)
    except KeyError: return bad("unknown report")
    okk, msg = await asyncio.to_thread(mailer.send, u["email"], f"{V.NAME}: {name}", "Your report is attached. It was generated from the live data by the agent network.", [(name, data, "application/pdf")])
    LE.audit(u["email"], "report_email", rid, msg); return {"ok": okk, "msg": msg}
@app.get("/api/export/{table}.csv")
def export(table: str, request: Request):
    u = user_of(request); c = ctx(u)
    if "reports" not in V.ROLE_MENU.get(u["role"], set()): raise HTTPException(403)
    if table not in RP.EXPORTS[KIND]: raise HTTPException(404)
    LE.audit(u["email"], "export", table); return Response(RP.export_csv(KIND, table, c["scope"]), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{table}.csv"'})
@app.post("/api/profile")
async def profile_save(request: Request):
    u = user_of(request); d = await request.json(); okk, msg = authx.update_name(u["email"], d.get("username", ""))
    if okk: authx.set_prefs(u["email"], lang=d.get("lang", "English")); LE.audit(u["email"], "profile", u["email"])
    return {"ok": okk, "msg": msg, "refresh": okk}
@app.post("/api/profile/prefs")
async def profile_prefs(request: Request):
    u = user_of(request); d = await request.json(); authx.set_prefs(u["email"], email_alerts=int(d.get("email_alerts") == "on"), daily_digest=int(d.get("daily_digest") == "on")); return ok("Preferences saved")
@app.post("/api/profile/password")
async def profile_pw(request: Request):
    u = user_of(request); d = await request.json(); okk, msg = await asyncio.to_thread(authx.change_password, u["email"], d.get("old", ""), d.get("new", ""))
    if okk: LE.audit(u["email"], "password_change", u["email"])
    return {"ok": okk, "msg": msg}
@app.post("/api/user/invite")
async def user_invite(request: Request):
    u = user_of(request); c = ctx(u); need(c, "admin"); d = await request.json(); okk, msg = await asyncio.to_thread(authx.invite, d.get("email", ""), d.get("username", ""), d.get("role", "")); LE.audit(u["email"], "invite", d.get("email", ""), d.get("role", "")); return {"ok": okk, "msg": msg, "refresh": okk}
@app.post("/api/user/deactivate")
async def user_deactivate(request: Request):
    u = user_of(request); c = ctx(u); need(c, "admin"); d = await request.json()
    if d["email"].lower() == u["email"].lower(): return bad("You cannot deactivate yourself.")
    authx.deactivate(d["email"], d.get("on") == "Deactivate"); LE.audit(u["email"], "deactivate" if d.get("on") == "Deactivate" else "reactivate", d["email"]); return ok("Done", refresh=True)

@app.get("/api/backup")
def backup(request: Request):
    import sqlite3, tempfile; u = user_of(request); c = ctx(u); need(c, "admin")
    fd, p = tempfile.mkstemp(suffix=".db"); os.close(fd); src = sqlite3.connect(DB_PATH); dst = sqlite3.connect(p); src.backup(dst); dst.close(); src.close()
    data = open(p, "rb").read(); os.remove(p); LE.audit(u["email"], "backup", DB_PATH); return Response(data, media_type="application/octet-stream", headers={"Content-Disposition": f'attachment; filename="{os.path.basename(DB_PATH)}"'})

@app.get("/api/health")
def health(): return {"ok": True, "gpu": gpu.status()}
@app.get("/")
def index(request: Request):
    if not M2A.current_user(request): return FileResponse(os.path.join(STATIC, "login.html"), headers={"Cache-Control": "no-store"})   # [M3] Milestone 2 sign-in page
    return FileResponse(os.path.join(STATIC, "index.html"), headers={"Cache-Control": "no-store"})
app.mount("/static", StaticFiles(directory=STATIC), name="static")

@app.get("/api/copilot/suggest")
def copilot_suggest(request: Request, q: str = ""):
    user_of(request); return {"items": CP.suggest(q[:80], CP_EXAMPLES)}
@app.get("/api/copilot/csv")
def copilot_csv(request: Request, sid: str = "default"):
    from fastapi.responses import Response
    u = user_of(request); t = CP.last_csv(u["email"] + ":" + sid[:40])
    if t is None: raise HTTPException(404, "nothing to export yet")
    return Response(t, media_type="text/csv", headers={"Content-Disposition": "attachment; filename=copilot_result.csv"})
@app.post("/api/copilot/feedback")
async def copilot_feedback(request: Request):
    user_of(request); d = await request.json(); CP.feedback(str(d.get("q", "")), bool(d.get("helpful"))); return {"ok": True}
# ------------------------------------------------------------------ teach the Copilot (admin): find unanswered questions, add the answers
@app.post("/api/copilot/teach")
async def teach_add(request: Request):
    u = user_of(request); need(ctx(u), "admin"); d = await request.json()
    i = await asyncio.to_thread(CP.teach, d.get("question", ""), d.get("answer", ""), d.get("keywords", ""), u["email"])
    if not i: return bad("Give a question (4+ characters) and an answer (10+ characters).")
    _RC.clear()      # [M3] a taught answer must replace a cached "I do not know" at once
    LE.audit(u["email"], "copilot_teach", str(d.get("question", ""))[:80], "taught"); st = CP.teach_stats(); return ok(f"Saved. The Copilot will now answer this, and rephrased versions of it. {st['taught']} taught so far.", refresh=True)
@app.post("/api/copilot/teach/delete")
async def teach_delete(request: Request):
    u = user_of(request); need(ctx(u), "admin"); d = await request.json(); CP.taught_del(int(d.get("id", 0))); return ok("Removed.", refresh=True)
@app.post("/api/copilot/teach/import")
async def teach_import(request: Request, file: UploadFile = File(...)):
    u = user_of(request); need(ctx(u), "admin"); import csv as _csv, io as _io
    try: rows = list(_csv.DictReader(_io.StringIO((await file.read()).decode("utf-8-sig", errors="ignore"))))
    except Exception as e: return bad(f"Could not read the CSV: {e}")
    n = 0; skipped = 0
    for r in rows[:500]:
        r = {str(a or "").strip().lower(): (b or "") for a, b in r.items()}
        if await asyncio.to_thread(CP.teach, r.get("question") or r.get("q", ""), r.get("answer") or r.get("a", ""), r.get("keywords", ""), u["email"]): n += 1
        else: skipped += 1
    _RC.clear()      # [M3]
    LE.audit(u["email"], "copilot_teach_import", file.filename, f"{n} taught"); return ok(f"{n} question(s) taught" + (f", {skipped} row(s) skipped (need question + answer columns)" if skipped else "") + f". {CP.teach_stats()['taught']} taught in total.", refresh=True)
@app.get("/api/copilot/teach/export")
async def teach_export(request: Request):
    u = user_of(request); need(ctx(u), "admin"); import csv as _csv, io as _io
    o = _io.StringIO(); w = _csv.writer(o); w.writerow(["question", "answer", "keywords", "added_by", "when"])
    for r in CP.taught_rows(): w.writerow([r["question"], r["answer"], r["keywords"], r["by"], r["when"]])
    return Response(o.getvalue(), media_type="text/csv", headers={"Content-Disposition": 'attachment; filename="taught_questions.csv"'})
@app.post("/api/copilot/probe")
async def copilot_probe(request: Request):
    """Runs a list of questions (one per line) through the real Copilot and reports which ones it could not answer. Unanswered ones land in the backlog."""
    u = user_of(request); need(ctx(u), "admin"); d = await request.json()
    qs = [re.sub(r"^\s*(\d+[.)]|[-*])\s*", "", x).strip() for x in str(d.get("questions", "")).splitlines()]; qs = [x for x in dict.fromkeys(qs) if len(x) > 3][:25]
    if not qs: return bad("Paste at least one question, one per line.")
    import hardening as _hd
    _sp = (request.scope.get("server") or (None, None))[1]; ports = [x for x in dict.fromkeys([_sp, int(os.environ.get("PORT", 0) or 0) or None, 8000, request.url.port]) if x]
    cookie = request.headers.get("cookie", ""); auth = request.headers.get("authorization", "")
    def run():
        import requests as _rq; out = []; base = None
        for pt in ports:                                              # find the port this server really listens on
            try:
                if _rq.get(f"http://127.0.0.1:{pt}/api/time", timeout=4).status_code < 500: base = f"http://127.0.0.1:{pt}"; break
            except Exception: continue
        for q in qs:
            route = "error"; ftxt = ""; fsql = ""; why = ""
            if not base: out.append({"question": q, "result": "Error", "route": "error", "reply": "Could not reach the server on localhost. Reload the page and try again."}); continue
            try:
                r = _rq.post(base + "/api/copilot", json={"q": q, "sid": "probe-" + u["email"]}, headers={"Cookie": cookie, "Authorization": auth, "X-Internal": _hd.INTERNAL}, stream=True, timeout=120)
                if r.status_code != 200: raise RuntimeError(f"HTTP {r.status_code}")
                for ln in r.iter_lines():
                    if ln.startswith(b"data: "):
                        try: ev = json.loads(ln[6:])
                        except Exception: continue
                        if ev.get("ev") == "final": ftxt = ev.get("text", "")
                        elif ev.get("ev") == "exact": fsql = ev.get("sql", "")
                with sqlite3.connect(DB_PATH, timeout=30) as c: row = c.execute("SELECT route FROM copilot_log WHERE q=? ORDER BY id DESC LIMIT 1", (q[:300],)).fetchone()
                route = row[0] if row else "unknown"
                if route in ("exact", "agents+llm", "exact+llm") and CP.weak_match(q, {"answer": ftxt, "sql": fsql}): route = "weak"; CP.log_turn(q, "weak", 0)
            except Exception as e: route = "error"; why = repr(e)[:80]
            out.append({"question": q, "result": "Error" if route == "error" else ("UNANSWERED" if route == "unanswered" else ("Weak match: check" if route == "weak" else "Answered")), "route": route, "reply": why if route == "error" else ftxt[:110].replace("\n", " ")})
        return out
    res = await asyncio.to_thread(run); na = sum(1 for r in res if r["result"] not in ("Answered", "Error")); er = sum(1 for r in res if r["result"] == "Error")
    return ok(f"{len(res)} tested: {len(res) - na - er} answered, {na} unanswered or weak (added to the backlog below)" + (f", {er} could not be tested (see the reply column)" if er else "") + ".", blocks=[B.table(res, ["question", B.pill_col("result"), "route", "reply"], h=min(420, 60 + 34 * len(res)), key="probe_out")], refresh=True)
@app.get("/api/copilot/insights")
def copilot_insights(request: Request):
    u = user_of(request); need(ctx(u), "admin"); return CP.insights()
@app.get("/api/time")
def api_time():
    n = datetime.datetime.now(); return {"iso": n.isoformat(timespec="seconds"), "tz": "Asia/Kolkata", "label": n.strftime("%a %d %b %Y, %I:%M %p IST")}
@app.get("/api/copilot/unanswered")
def copilot_unanswered(request: Request):
    u = user_of(request); need(ctx(u), "admin"); return {"rows": CP.unanswered()}
LE.set_chain_defaults(dom)
@app.post("/api/approval/chain")
async def approval_chain(request: Request):
    u = user_of(request); c = ctx(u); need(c, "admin"); d = await request.json(); cur = LE.get_state("approval_chain", {}) or {}; n = 0
    valid = set(dom.ACTION_AGENT) | {"req:" + k for k in dom.REQUEST_KINDS}
    for k, v in d.items():
        if k not in valid or v not in dom.CHAIN_PRESETS: continue
        ch = [x.strip() for x in v.split("→")]
        if cur.get(k) != ch: cur[k] = ch; n += 1; LE.audit(u["email"], "approval_chain", k, " → ".join(ch))
    LE.set_state("approval_chain", cur); return ok(f"{n} approval chain(s) saved. New requests use them at once.", refresh=True)

# ====================================================================================================
# [M3] Milestone 2 work brought into the final app: sign-in page, Admin dashboard, Teach card, role guard
# ====================================================================================================
app.include_router(M2A.router)                     # /api/auth/login, /register, /profile, /otp/*, /reset-security, /admin/* ...
@app.get("/login")
def login_page(): return FileResponse(os.path.join(STATIC, "login.html"), headers={"Cache-Control": "no-store"})
@app.get("/auth-admin")
def auth_admin_page(request: Request):
    u = user_of(request)
    if u["role"] != "Admin": raise HTTPException(403, "Administrator access required.")
    return FileResponse(os.path.join(STATIC, "auth_admin.html"), headers={"Cache-Control": "no-store"})

ADMIN_ROLES = ("Admin", "Operations Manager", "Freight Broker", "Auditor", "Customer")
def _admin_users_guard(request: Request):
    """Admin dashboard (Milestone 2): only the Admin role. Any other role gets HTTP 403."""
    u = user_of(request)
    if u["role"] != "Admin": raise HTTPException(403, f"Role '{u['role']}' does not have the 'manage_users' capability.")
    return u, ctx(u)
def _admin_audit(conn, actor, event, target="", detail=""):
    conn.execute("INSERT INTO audit_log(ts,actor,event,target,detail) VALUES(?,?,?,?,?)", (datetime.datetime.now().isoformat(timespec="seconds"), actor, event, str(target), str(detail)[:1000]))

@app.get("/admin")
def admin_dashboard(request: Request):
    _admin_users_guard(request); return FileResponse(os.path.join(STATIC, "admin.html"), headers={"Cache-Control": "no-store"})
def _lock_view(d, now):
    st = str(d.get("account_status") or "active").strip().lower(); is_perm = bool(d.get("is_permanent")); temp = False
    if d.get("lock_until"):
        try: temp = float(d.get("lock_until")) > now
        except (TypeError, ValueError): temp = False
    if not temp and int(d.get("attempts") or 0) >= M2A.MAX_FAILED_ATTEMPTS and (now - float(d.get("last_attempt") or 0)) < M2A.LOCKOUT_DURATION_SECONDS: temp = True
    return (st in {"locked", "inactive"}) or is_perm or temp
@app.get("/api/admin/users")
def admin_dashboard_users(request: Request):
    _admin_users_guard(request); now = time.time()
    with M2A.db() as conn:
        rows = conn.execute("""SELECT u.id, u.email, u.username, u.role, u.account_status, u.created_at, u.last_login, u.customer_id,
                   COALESCE(l.is_permanent, 0) as is_permanent, COALESCE(l.attempts, 0) as attempts, COALESCE(l.last_attempt, 0) as last_attempt, u.lock_until
            FROM users u LEFT JOIN auth_lockouts l ON lower(l.email) = lower(u.email) ORDER BY lower(u.username), lower(u.email)""").fetchall()
    out = []
    for r in rows:
        d = dict(r); lk = _lock_view(d, now); d.update(is_locked=lk, account_status="inactive" if lk else "active", display_status="Inactive" if lk else "Active"); out.append(d)
    return {"ok": True, "users": out}
@app.get("/api/admin/kpis")
def admin_dashboard_kpis(request: Request):
    _admin_users_guard(request); now = time.time()
    with M2A.db() as conn:
        total = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        roles = {str(r["role"] or "Customer"): int(r["n"]) for r in conn.execute("SELECT role, COUNT(*) n FROM users GROUP BY role")}
        rows = conn.execute("""SELECT u.account_status, u.lock_until, COALESCE(l.is_permanent,0) is_permanent, COALESCE(l.attempts,0) attempts, COALESCE(l.last_attempt,0) last_attempt
            FROM users u LEFT JOIN auth_lockouts l ON lower(l.email)=lower(u.email)""").fetchall()
    return {"ok": True, "total": int(total), "roles": roles, "locked": sum(1 for r in rows if _lock_view(dict(r), now))}
@app.get("/api/admin/activity")
def admin_dashboard_activity(request: Request):
    _admin_users_guard(request)
    with M2A.db() as conn: rows = conn.execute("SELECT ts,actor,event,target,detail FROM audit_log ORDER BY audit_id DESC LIMIT 50").fetchall()
    return {"ok": True, "events": [dict(r) for r in rows]}
@app.post("/api/admin/users")
async def admin_dashboard_add_user(request: Request):
    user, c = _admin_users_guard(request); d = await request.json()
    email = str(d.get("email", "")).strip().lower(); username = str(d.get("username", "")).strip(); password = str(d.get("temporary_password", "")); role = str(d.get("role", "")).strip()
    err = M2A._email_error(email)
    if err: raise HTTPException(400, err)
    if not username or len(username) > 80: raise HTTPException(400, "Username is required and must be 80 characters or fewer.")
    if not password: raise HTTPException(400, "Temporary password is required.")
    err = M2A._password_error(password, password)
    if err: raise HTTPException(400, err)
    if role == "Admin": raise HTTPException(400, "Admin accounts cannot be created directly. Create the user with a standard role, then promote to Admin.")
    if role not in ("Operations Manager", "Freight Broker", "Auditor", "Customer"): raise HTTPException(400, "Choose one of the supported roles: Operations Manager, Freight Broker, Auditor, Customer.")
    with M2A.db() as conn:
        try:
            customer_id = "CUST-" + __import__("uuid").uuid4().hex[:12].upper() if role == "Customer" else None
            conn.execute("INSERT INTO users(username,email,password_hash,role,account_status,customer_id,created_at) VALUES(?,?,?,?,'active',?,?)",
                         (username, email, M2A._hash(password), role, customer_id, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            if customer_id: conn.execute("INSERT OR IGNORE INTO customers(customer_id,name,industry,priority_tier,credit_risk) VALUES(?,?, 'General', 'Standard', 0.25)", (customer_id, username))
            _admin_audit(conn, user["email"], "user_created", email, "role=" + role)
        except sqlite3.IntegrityError: raise HTTPException(409, "That email address or username is already registered.")
    return {"ok": True, "msg": "User created."}
@app.patch("/api/admin/users/{uid}/role")
@app.post("/api/admin/users/{uid}/role")
async def admin_dashboard_role(uid: int, request: Request):
    user, c = _admin_users_guard(request); d = await request.json(); role = str(d.get("role", "")).strip()
    if role not in ADMIN_ROLES: raise HTTPException(400, "Choose one of the supported roles.")
    with M2A.db() as conn:
        target = conn.execute("SELECT id,email,username,role,customer_id FROM users WHERE id=?", (uid,)).fetchone()
        if not target: raise HTTPException(404, "User not found.")
        if target["role"] == "Admin" or target["email"].lower() == M2A.ADMIN_EMAIL: raise HTTPException(400, "The Administrator account cannot be modified as it is already at the highest level.")
        if role == "Admin": raise HTTPException(400, "Regular accounts cannot be promoted to Admin. The Admin role is reserved for the Administrator account.")
        customer_id = None
        if role == "Customer":
            customer_id = target["customer_id"] or ("CUST-" + __import__("uuid").uuid4().hex[:12].upper())
            conn.execute("INSERT OR IGNORE INTO customers(customer_id,name,industry,priority_tier,credit_risk) VALUES(?,?, 'General', 'Standard', 0.25)", (customer_id, target["username"] or customer_id))
        conn.execute("UPDATE users SET role=?, customer_id=? WHERE id=?", (role, customer_id, uid))
        _admin_audit(conn, user["email"], "role_changed", target["email"], f'{target["role"]} -> {role}')
    return {"ok": True, "msg": "Role updated."}
@app.post("/api/admin/users/{uid}/status")
async def admin_dashboard_status(uid: int, request: Request):
    user, c = _admin_users_guard(request); d = await request.json(); status = str(d.get("status", "")).strip().lower()
    if status not in {"active", "locked", "inactive"}: raise HTTPException(400, "Status must be Active or Inactive/Locked.")
    with M2A.db() as conn:
        target = conn.execute("SELECT id,email,role,account_status FROM users WHERE id=?", (uid,)).fetchone()
        if not target: raise HTTPException(404, "User not found.")
        if status in {"locked", "inactive"} and uid == user.get("id"): raise HTTPException(400, "You cannot lock your own account.")
        if status in {"locked", "inactive"} and (target["role"] == "Admin" or target["email"].lower() == M2A.ADMIN_EMAIL): raise HTTPException(400, "The Administrator account cannot be locked.")
        if status == "active":
            conn.execute("UPDATE users SET account_status='active', failed_attempts=0, lock_until=NULL WHERE id=?", (uid,)); conn.execute("DELETE FROM auth_lockouts WHERE lower(email)=lower(?)", (target["email"],))
            _admin_audit(conn, user["email"], "user_unlocked", target["email"], "status=active"); return {"ok": True, "msg": "Account unlocked and activated."}
        conn.execute("UPDATE users SET account_status='locked' WHERE id=?", (uid,)); _admin_audit(conn, user["email"], "user_locked", target["email"], "status=inactive")
    return {"ok": True, "msg": "Account locked."}
@app.delete("/api/admin/users/{uid}")
@app.post("/api/admin/users/{uid}/delete")
def admin_dashboard_delete_user(uid: int, request: Request):
    user, c = _admin_users_guard(request)
    with M2A.db() as conn:
        target = conn.execute("SELECT id,email,role FROM users WHERE id=?", (uid,)).fetchone()
        if not target: raise HTTPException(404, "User not found.")
        if uid == user.get("id"): raise HTTPException(400, "You cannot delete your own account.")
        if target["role"] == "Admin" or target["email"].lower() == M2A.ADMIN_EMAIL: raise HTTPException(400, "The Administrator account cannot be deleted.")
        _admin_audit(conn, user["email"], "user_deleted", target["email"], "role=" + str(target["role"]))
        conn.execute("DELETE FROM users WHERE id=?", (uid,)); conn.execute("DELETE FROM auth_lockouts WHERE lower(email)=lower(?)", (target["email"],))
    return {"ok": True, "msg": "User deleted."}

# ---- Teach Copilot card on the Milestone 2 Admin dashboard. Writes the same store as Admin → Teach Copilot (copilot_taught),
#      so there is one counter (50 / 50) and taught answers work for rephrased questions too.
TEACH_TARGET = 50
def _teach_one(q, a, keywords, category, by):
    q, a = str(q or "").strip(), str(a or "").strip()
    if not q or not a or q.lower() == "nan" or a.lower() == "nan": return False
    with sqlite3.connect(DB_PATH, timeout=30) as conn:
        conn.execute("INSERT INTO copilot_knowledge(question,answer,category) VALUES(?,?,?) ON CONFLICT(question) DO UPDATE SET answer=excluded.answer, category=excluded.category", (q, a, category or "General"))
    return bool(CP.teach(q, a, keywords or "", by))
def _migrate_taught():
    with sqlite3.connect(DB_PATH, timeout=30) as conn:
        try: rows = conn.execute("SELECT question, answer, category FROM copilot_knowledge").fetchall()
        except sqlite3.OperationalError: rows = []
    have = {r["question"].strip().lower() for r in CP.taught_rows()}
    for q, a, cat in rows:
        if q.strip().lower() not in have: CP.teach(q, a, "", "milestone2")
@app.get("/api/admin/teach/count")
def teach_count(request: Request):
    _admin_users_guard(request); n = CP.teach_stats()["taught"]
    return {"ok": True, "total": n, "target": TEACH_TARGET, "remaining": max(0, TEACH_TARGET - n)}
@app.post("/api/admin/teach")
async def teach_copilot(request: Request):
    u, c = _admin_users_guard(request); d = await request.json()
    if not str(d.get("question", "")).strip() or not str(d.get("answer", "")).strip(): raise HTTPException(400, "Question and answer are required.")
    okk = await asyncio.to_thread(_teach_one, d.get("question"), d.get("answer"), d.get("keywords", ""), d.get("category", "General"), u["email"])
    if not okk: return bad("Give a question (4+ characters) and an answer (10+ characters).")
    _RC.clear(); LE.audit(u["email"], "copilot_teach", str(d.get("question", ""))[:80], "taught"); n = CP.teach_stats()["taught"]
    return {"ok": True, "total": n, "target": TEACH_TARGET, "msg": f"Copilot knowledge saved. {n} / {TEACH_TARGET} taught."}
@app.post("/api/admin/teach/upload")
async def teach_upload(request: Request, file: UploadFile = File(...)):
    u, c = _admin_users_guard(request)
    if not file.filename.lower().endswith(".csv"): raise HTTPException(400, "Please upload a CSV file.")
    try: df = pd.read_csv(io.BytesIO(await file.read()))
    except Exception: raise HTTPException(400, "Invalid CSV file.")
    df.columns = [str(x).strip().lower() for x in df.columns]
    if not {"question", "answer"}.issubset(df.columns): raise HTTPException(400, "CSV must contain question and answer columns.")
    added = 0
    for _, r in df.iterrows():
        if await asyncio.to_thread(_teach_one, r["question"], r["answer"], r.get("keywords", "") if "keywords" in df.columns else "", r.get("category", "General") if "category" in df.columns else "General", u["email"]): added += 1
    _RC.clear(); LE.audit(u["email"], "copilot_teach_import", file.filename, f"{added} taught"); n = CP.teach_stats()["taught"]
    return {"ok": True, "imported": added, "total": n, "target": TEACH_TARGET, "msg": f"CSV imported: {added} question(s). {n} / {TEACH_TARGET} taught."}

# ---- Copilot role boundary (Milestone 2): Customer sees only their own quotes; some roles may not read some topics.
_ROLE_TOPICS = {"Operations Manager": [(r"\b(quotes?|pricing|margins?|customers?|credit risk)\b", "commercial quote and customer-credit data")],
                "Freight Broker": [(r"\b(customs|duty|duties|tariffs?|weather|storms?|wind|waves?|audit|internal tickets?)\b", "operations, customs and weather data")]}
_KNOWLEDGE_OK = re.compile(r"\b(what is|what are|what does|explain|define|meaning|difference between|how does|how do|incoterm|fob|cif|exw|ddp|bill of lading|letter of credit|demurrage|detention|hs code)\b", re.I)
_DATA_WORDS = re.compile(r"\b(\d+|highest|lowest|top|most|least|cheapest|costliest|latest|average|total|number|count|how many|list|all|which|status|our|my)\b", re.I)   # [M3 AUDIT]
def _copilot_role_guard(u, q):
    role = u["role"]; t0 = time.time()
    def one(text, sql="", rows=0):
        if sql: yield _sse("exact", sql=sql, rows=rows)
        yield _sse("final", text=text, sql=sql, rows=rows, ms=round((time.time() - t0) * 1000)); yield _sse("done")
    if role == "Customer":
        if CP.defined_term(q) and not _DATA_WORDS.search(q): return None   # [M3 AUDIT] only definitions ("What is demurrage?") skip the guard; the Copilot then answers from documents only
        if not u.get("customer_id"): return one("Your account is not linked to a customer record. Contact the platform administrator.")
        if not re.search(r"quote|shipment|order|status|price|cost|margin|route|carrier|\bmy\b", q, re.I):
            return one("Customer Copilot is limited to your own quotes and shipments, plus general trade questions (Incoterms, documents, customs terms). Ask about your quote status, shipment status, price, route or carrier.")
        sql = ("SELECT q.quote_id,q.shipment_id,q.customer_id,q.carrier,q.final_price,q.status,q.created_at,s.status AS shipment_status,s.origin_port,s.dest_port "
               "FROM freight_quotes q LEFT JOIN shipments s ON s.shipment_id=q.shipment_id WHERE q.customer_id=? ORDER BY q.created_at DESC LIMIT 100")
        try:
            with sqlite3.connect(DB_PATH) as cn: cn.row_factory = sqlite3.Row; rows = cn.execute(sql, (u["customer_id"],)).fetchall()
        except Exception: return one("Could not load your account's quote information.")
        if not rows: return one("There are no quotes or shipments linked to your account yet.", sql, 0)
        ans = "Your recent quotes and linked shipments:\n" + "\n".join(f"- **{r['quote_id']}**: {r['status']}, ${float(r['final_price'] or 0):,.2f}, carrier {r['carrier'] or 'not assigned'}, shipment {r['shipment_id'] or 'not assigned'} ({r['shipment_status'] or 'status pending'}), lane {r['origin_port'] or '?'} → {r['dest_port'] or '?'}" for r in rows[:20])
        return one(ans, sql, len(rows))
    if CP.defined_term(q) and not _DATA_WORDS.search(q): return None      # [M3 AUDIT] definitions only; data questions still meet the role topic limits
    ql = AN._normalise_question(q) if hasattr(AN, "_normalise_question") else q.lower()
    blocked = next((label for pat, label in _ROLE_TOPICS.get(role, []) if re.search(pat, ql, re.I)), None)
    if blocked:
        return one(f"Sorry, your {role} role cannot read {blocked}. Try one of these questions allowed for your role:\n- Which carrier has the best on-time performance?\n- How many shipments are delayed?\n- Which route has the highest shipment volume?")
    return None

# ------------------------------------------------------------------ [M3 TEAM INTEGRATION] Copilot tuning administration
@app.get("/api/admin/copilot/tuning/insights")
def copilot_tuning_insights(request: Request):
    _admin_users_guard(request)
    return TUNE.insights()

@app.post("/api/admin/copilot/tuning/benchmark")
def copilot_tuning_benchmark(request: Request):
    _admin_users_guard(request)
    return TUNE.benchmark()

@app.get("/api/admin/copilot/tuning/settings")
def copilot_tuning_settings(request: Request):
    _admin_users_guard(request)
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        synonyms = [dict(row) for row in conn.execute("SELECT id,intent,phrase,enabled FROM copilot_synonyms ORDER BY intent,phrase")]
        prompts = {row["prompt_key"]: row["prompt_text"] for row in conn.execute("SELECT prompt_key,prompt_text FROM copilot_prompts")}
    return {"synonyms": synonyms, "prompts": prompts}

@app.post("/api/admin/copilot/tuning/synonyms")
async def copilot_tuning_add_synonym(request: Request):
    _admin_users_guard(request)
    data = await request.json()
    try:
        TUNE.add_synonym(data.get("intent"), data.get("phrase"))
    except sqlite3.IntegrityError:
        raise HTTPException(409, "That synonym already exists.")
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"ok": True, "insights": TUNE.insights()}

@app.post("/api/admin/copilot/tuning/prompts")
async def copilot_tuning_save_prompt(request: Request):
    _admin_users_guard(request)
    data = await request.json()
    try:
        TUNE.set_prompt(data.get("key"), data.get("text"))
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"ok": True, "msg": "Copilot prompt updated."}
