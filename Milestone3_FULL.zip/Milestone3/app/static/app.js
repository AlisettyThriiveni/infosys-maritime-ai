"use strict";
// [M3] Milestone 2 design: light / dark theme (remembered per browser) and mobile navigation
// ---------------------------------------------------------------- Theme & Mobile Nav
function initTheme(){
  const saved=localStorage.getItem("fq_theme")||(window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");
  document.documentElement.setAttribute("data-theme",saved);
  return saved;
}
function updateThemeBtn(){
  const btn=document.getElementById("themeBtn");
  if(!btn)return;
  const isDark=document.documentElement.getAttribute("data-theme")==="dark";
  btn.innerHTML=isDark?'<span class="t-ico">☀️</span> Light':'<span class="t-ico">🌙</span> Dark';
}
function toggleTheme(){
  const cur=document.documentElement.getAttribute("data-theme")==="dark"?"dark":"light";
  const next=cur==="dark"?"light":"dark";
  document.documentElement.setAttribute("data-theme",next);
  localStorage.setItem("fq_theme",next);
  updateThemeBtn();
}
initTheme();
const $=(s,r=document)=>r.querySelector(s);
const esc=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function h(tag,attrs,...kids){const e=document.createElement(tag);for(const k in(attrs||{})){const v=attrs[k];if(v==null||v===false)continue;if(k==="class")e.className=v;else if(k==="html")e.innerHTML=v;else if(k.startsWith("on"))e.addEventListener(k.slice(2),v);else e.setAttribute(k,v===true?"":v)}for(const c of kids.flat())if(c!=null&&c!==false)e.append(c.nodeType?c:document.createTextNode(c));return e}
const TONE={Critical:"#cd2b31",High:"#cd2b31",Fail:"#cd2b31",rejected:"#cd2b31","On Hold":"#cd2b31",overdue:"#cd2b31",Warning:"#ab6400",Medium:"#ab6400","Pending Approval":"#ab6400",proposed:"#793aaf",Info:"#3451b2",open:"#3451b2",Low:"#0b7a6c",Pass:"#0b7a6c",Approved:"#0b7a6c",approved:"#0b7a6c",resolved:"#0b7a6c","auto-closed":"#6b7080",live:"#0b7a6c",Healthy:"#0b7a6c",Watch:"#ab6400",Rejected:"#6b7080"};
const tone=v=>TONE[v]||(/crit|high|fail|bad|reject|hold/i.test(v)?"#cd2b31":/warn|med|pend/i.test(v)?"#ab6400":/ok|pass|low|good|appr|done|clear|live/i.test(v)?"#0b7a6c":"#6b7080");
const ICON={bot:"M12 8V4H8M4 12a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2zM2 14h2M20 14h2M9 15v1M15 15v1",users:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8",store:"M3 9l1-5h16l1 5M3 9v11h18V9M3 9a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0M9 20v-6h6v6",boxes:"M21 8l-9-5-9 5 9 5zM3 8v8l9 5 9-5V8M12 13v8",megaphone:"M3 11v2a1 1 0 0 0 1 1h3l8 5V5L7 10H4a1 1 0 0 0-1 1zM19 8a5 5 0 0 1 0 8",messages:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",clipboard:"M9 4h6v3H9zM8 5H6a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2M9 13l2 2 4-4",bell:"M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0",network:"M12 2v6M12 16v6M5 6l5 4M19 6l-5 4M5 18l5-4M19 18l-5-4M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8",flask:"M10 2v7L4 20a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1l-6-11V2M8 2h8M7 15h10",upload:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12",shield:"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10",radar:"M12 12l7-7M12 2a10 10 0 1 0 10 10M12 6a6 6 0 1 0 6 6M12 10a2 2 0 1 0 2 2",route:"M6 19a3 3 0 1 0 0-6 3 3 0 0 0 0 6M18 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6M9 16h6a3 3 0 0 0 0-6H9a3 3 0 0 1 0-6h3",dollar:"M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",truck:"M1 3h15v13H1zM16 8h4l3 3v5h-7M5.5 21a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5M18.5 21a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5",cloud:"M17.5 19a4.5 4.5 0 1 0-1.4-8.8A6 6 0 1 0 5 15a4 4 0 0 0 1 4z",trend:"M3 17l6-6 4 4 8-8M15 7h6v6",chart:"M3 3v18h18M7 15l4-4 3 3 5-6",check:"M22 11.1V12a10 10 0 1 1-5.9-9.1M22 4L12 14l-3-3",user:"M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8",file:"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M9 13h6M9 17h6"};
const icon=n=>{const s=document.createElementNS("http://www.w3.org/2000/svg","svg");s.setAttribute("viewBox","0 0 24 24");const p=document.createElementNS("http://www.w3.org/2000/svg","path");p.setAttribute("d",ICON[n]||ICON.file);s.append(p);return s};
const S={me:null,page:null,tab:null,params:{},lang:localStorage.getItem("lang")||"English",pulse:null,tree:null,timer:null,seq:0,boot:null};
const LANGS_CODE={};
async function api(path,opt={}){const o={credentials:"same-origin",...opt};if(opt.json!==undefined){o.method=o.method||"POST";o.headers={"Content-Type":"application/json"};o.body=JSON.stringify(opt.json)}
 const r=await fetch(path,o);let d=null;try{d=await r.json()}catch(e){}
 if(r.status===401&&S.me&&!path.includes("login")){S.me=null;render();return{ok:false,msg:"Session ended"}}
 if(!r.ok&&d&&!d.msg)d.msg=d.detail||("Error "+r.status);if(!d)d={ok:false,msg:"Error "+r.status};return d}
function toast(msg,bad){const t=h("div",{class:bad?"bad":""},msg);$("#toast").append(t);setTimeout(()=>t.remove(),bad?7000:4500)}
const fmt={num:v=>v==null?"–":(typeof v==="number"?(Math.abs(v)>=1000?v.toLocaleString(undefined,{maximumFractionDigits:1}):+v.toFixed(2)):v),int:v=>v==null?"–":Math.round(v).toLocaleString(),money:v=>v==null?"–":"$"+Math.round(v).toLocaleString()};
function md(t){let s=esc(t||"");s=s.replace(/```([\s\S]*?)```/g,(_,c)=>"<pre>"+c.trim()+"</pre>").replace(/`([^`]+)`/g,"<code>$1</code>").replace(/\*\*([^*]+)\*\*/g,"<b>$1</b>").replace(/\[(\d{1,2})\]/g,'<sup style="font-weight:600;color:#2b6cb0">[$1]</sup>');const L=s.split("\n");let o="",inl=false,tb=null;const row=l=>l.trim().replace(/^\||\|$/g,"").split("|").map(x=>x.trim());const endT=()=>{if(tb){o+='<div class="tbl" style="margin:8px 0"><table><thead><tr>'+row(tb[0]).map(x=>"<th>"+x+"</th>").join("")+"</tr></thead><tbody>"+tb.slice(2).map(r=>"<tr>"+row(r).map(x=>"<td>"+x+"</td>").join("")+"</tr>").join("")+"</tbody></table></div>";tb=null}};for(let i=0;i<L.length;i++){const l=L[i];if(/^\s*\|.*\|\s*$/.test(l)){if(inl){o+="</ul>";inl=false}(tb=tb||[]).push(l);continue}endT();const m=l.match(/^\s*[-*•]\s+(.*)/),nm=l.match(/^\s*(\d{1,2})\.\s+(.*)/);if(nm){if(inl){o+="</ul>";inl=false}o+='<div style="margin:2px 0 2px 4px"><b>'+nm[1]+".</b> "+nm[2]+"</div>"}else if(m){if(!inl){o+="<ul>";inl=true}o+="<li>"+m[1]+"</li>"}else{if(inl){o+="</ul>";inl=false}const hd=l.match(/^(#{1,3})\s+(.*)/);o+=hd?`<h${hd[1].length}>${hd[2]}</h${hd[1].length}>`:(l.trim()?l+"<br>":"")}}endT();if(inl)o+="</ul>";return o}

// ---------------------------------------------------------------- block renderers (each returns {el, update(b)})
function mount(b,key){const f=R[b.t];if(!f){return{el:h("div",{class:"card"},"Unsupported block: "+b.t),update(){}}}const m=f(b,key);m.t=b.t;m.k=b.key||b.id||"";return m}
function mountList(parent,blocks,key){const hs=blocks.map((b,i)=>mount(b,key+"/"+i));hs.forEach(x=>parent.append(x.el));return hs}
function updList(parent,hs,blocks,key){if(hs.length!==blocks.length||hs.some((x,i)=>x.t!==blocks[i].t||x.k!==(blocks[i].key||blocks[i].id||""))){parent.replaceChildren();return mountList(parent,blocks,key)}hs.forEach((x,i)=>x.update(blocks[i]));return hs}
const R={};
R.kpis=b=>{const el=h("div",{class:"kpis"});const up=b=>{el.replaceChildren(...b.items.map(i=>h("div",{class:"kpi "+(i.tone||"")},h("div",{class:"l"},i.label),h("div",{class:"v"},typeof i.value==="number"?fmt.num(i.value):i.value),i.sub?h("div",{class:"s"},i.sub):null)))};up(b);return{el,update:up}};
R.callout=b=>{const el=h("div");const up=b=>{el.className="callout "+(b.tone||"info");el.replaceChildren(h("div",null,b.title?h("b",null,b.title+" "):null,h("span",{html:md(b.text)})))};up(b);return{el,update:up}};
R.md=b=>{const el=h("div",{class:"md"});const up=b=>el.innerHTML=md(b.text);up(b);return{el,update:up}};
R.row=(b,k)=>{const el=h("div",{class:"row"});const sty=r=>el.style.gridTemplateColumns=(r||b.cols.map(()=>1)).map(x=>x+"fr").join(" ");sty(b.ratio);let hs=[];const wrap=[];const up=nb=>{sty(nb.ratio);if(hs.length!==nb.cols.length||hs.some((x,i)=>x.t!==nb.cols[i].t)){el.replaceChildren();hs=nb.cols.map((c,i)=>{const m=mount(c,k+"/"+i);el.append(m.el);return m})}else hs.forEach((x,i)=>x.update(nb.cols[i]))};up(b);return{el,update:up}};
R.col=(b,k)=>{const el=h("div",{class:"col"});let hs=mountList(el,b.blocks,k);return{el,update:nb=>{hs=updList(el,hs,nb.blocks,k)}}};
R.card=(b,k)=>{const el=h("div",{class:"card"});const hd=h("h3"),sub=h("div",{class:"sub"}),body=h("div");el.append(hd,sub,body);let hs=[];const up=(nb,first)=>{hd.textContent=nb.title||"";hd.style.display=nb.title?"":"none";sub.textContent=nb.sub||"";sub.style.display=nb.sub?"":"none";hs=first?mountList(body,nb.blocks,k):updList(body,hs,nb.blocks,k)};up(b,true);return{el,update:nb=>up(nb)}};
R.hero=b=>{const el=h("div",{class:"hero"});const up=b=>{const c=b.risk?tone(b.risk):"#8b8d98";el.replaceChildren(h("div",{class:"sc",style:"color:"+c},b.score==null?"–":Math.round(b.score)),h("div",{style:"flex:1"},h("h2",null,b.title," ",b.risk?h("span",{class:"pill",style:`color:${c};border-color:${c}`},b.risk):null),h("p",null,b.blurb),h("p",{style:"color:#454a58"},b.summary||"No run yet."),h("p",null,b.ts?`last run ${b.ts.slice(11,19)} · ${b.ms} ms`:"")),b.can_run?h("button",{class:"btn primary",onclick:async e=>{e.target.disabled=true;const r=await api("/api/run_agent",{json:{agent:b.agent}});toast(r.msg,!r.ok);e.target.disabled=false;reloadPage()}},"Run now"):null)};up(b);return{el,update:up}};
R.brief=b=>{const el=h("div",{class:"card"});const out=h("div",{class:"md"});const up=b=>{out.dataset.def=b.text;if(!out.dataset.ai)out.innerHTML=md(b.text)};el.append(h("h3",null,"Executive briefing"),out,b.can_brief?h("button",{class:"btn sm",style:"margin-top:8px",onclick:async e=>{e.target.disabled=true;out.dataset.ai="1";out.textContent="";let acc="";await sse("/api/brief",{lang:S.lang},ev=>{if(ev.ev==="tok"){acc+=ev.text;out.innerHTML=md(acc)}if(ev.ev==="final")out.innerHTML=md(ev.text)});e.target.disabled=false}},"Write with the GPU model"):null);up(b);return{el,update:up}};
R.button=b=>{const el=h("button",{class:"btn "+(b.tone||"primary"),onclick:async()=>{if(b.payload&&b.payload.download){window.open(b.url,"_blank");return}if(b.confirm&&!confirm(b.confirm))return;el.disabled=true;const r=await api(b.url,{json:b.payload||{}});toast(r.msg||"Done",!r.ok);el.disabled=false;if(r.refresh)reloadPage()}},b.label);return{el,update(){}}};
R.table=b=>{const el=h("div"),title=h("h3",{style:"margin:0 0 6px;font-size:13.5px"}),sub=h("div",{class:"sub"}),srch=h("input",{class:"srch",placeholder:"Search…",oninput:()=>{st.q=srch.value.toLowerCase();draw()}}),box=h("div",{class:"tbl"}),st={sort:null,dir:1,q:""};let cur=b;el.append(title,sub,srch,box);
 const draw=()=>{const b=cur;title.textContent=b.title||"";title.style.display=b.title?"":"none";sub.textContent=b.sub||"";sub.style.display=b.sub?"":"none";srch.style.display=b.search?"":"none";if(b.h)box.style.maxHeight=b.h+"px";
  let rows=b.rows;if(st.q)rows=rows.filter(r=>Object.values(r).some(v=>String(v).toLowerCase().includes(st.q)));if(st.sort)rows=[...rows].sort((x,y)=>{const a=x[st.sort],c=y[st.sort];return(a==null)-(c==null)||(a>c?1:a<c?-1:0)*st.dir});
  const mx={};b.cols.forEach(c=>{if(c.type==="pct"){mx[c.k]=Math.max(...b.rows.map(r=>Math.abs(r[c.k]||0)))<=1.0001?100:1}});
  const th=h("tr",null,...b.cols.map(c=>h("th",{onclick:()=>{st.dir=st.sort===c.k?-st.dir:1;st.sort=c.k;draw()}},c.label+(st.sort===c.k?(st.dir>0?" ▲":" ▼"):""))));
  const tb=rows.slice(0,400).map(r=>{const tr=h("tr",{class:b.open?"cl":""},...b.cols.map(c=>{const v=r[c.k];const t=c.type||"text";let n;
    if(t==="pill"&&v!=null&&v!=="")n=h("span",{class:"pill",style:`color:${tone(v)};border-color:${tone(v)}55;background:${tone(v)}18`},v);
    else if(t==="bar"){const m=c.max||100,p=Math.max(0,Math.min(100,(v||0)/m*100)),col=c.k.match(/risk|prob|congest|ci|index/i)?(p>66?"#e5484d":p>40?"#f5a524":"#12a594"):(p<60?"#e5484d":p<80?"#f5a524":"#12a594");n=h("div",{class:"bar"},h("span",null,v==null?"–":fmt.num(v)),h("i",null,h("b",{style:`width:${p}%;background:${col}`})))}
    else if(t==="pct")n=document.createTextNode(v==null?"–":(+(v*mx[c.k]).toFixed(1))+"%");else if(t==="money")n=document.createTextNode(fmt.money(v));else if(t==="int")n=document.createTextNode(fmt.int(v));else if(t==="num")n=document.createTextNode(fmt.num(v));else n=document.createTextNode(v==null?"":v);
    return h("td",{title:typeof v==="string"&&v.length>40?v:null},n)}));if(b.open)tr.onclick=()=>UI.openEntity(r[b.open.col]);return tr});
  const sc=box.scrollTop;box.replaceChildren(h("table",null,h("thead",null,th),h("tbody",null,...tb)));box.scrollTop=sc;if(!rows.length)box.append(h("div",{class:"sub",style:"padding:12px"},"No rows."))};
 draw();return{el,update:nb=>{cur=nb;draw()}}};
R.tickets=b=>{const el=h("div"),st={f:"all",open:new Set()};let cur=b;const body=h("div"),fl=h("div",{class:"filters"});el.append(h("h3",{style:"margin:0 0 6px;font-size:13.5px"},b.title||"Tickets"),h("div",{class:"sub"},b.sub||""),fl,body);
 const act=async(id,a,json)=>{const r=await api(`/api/ticket/${id}/${a}`,{json:json||{}});toast(r.msg,!r.ok);if(document.activeElement)document.activeElement.blur();st.sig=null;reloadPage(true)};
 const draw=()=>{const items=cur.items;st.sig=JSON.stringify(items)+st.f+[...st.open];const cnt=k=>k==="all"?items.length:k==="proposed"?items.filter(i=>i.status==="proposed").length:k==="overdue"?items.filter(i=>i.overdue).length:items.filter(i=>i.sev===k).length;
  fl.replaceChildren(...["all","proposed","Critical","Warning","Info","overdue"].map(k=>h("span",{class:"chip"+(st.f===k?" on":""),onclick:()=>{st.f=k;draw()}},(k==="proposed"?"awaiting approval":k)+" · "+cnt(k))));
  const list=items.filter(i=>st.f==="all"||(st.f==="proposed"?i.status==="proposed":st.f==="overdue"?i.overdue:i.sev===st.f));
  body.replaceChildren(...list.slice(0,80).map(i=>{const c=tone(i.sev);const t=h("div",{class:"tk "+i.sev+" "+i.status},
   h("div",{class:"h"},h("b",null,"#"+i.id+" "+i.type.replace(/_/g," ")),h("span",{class:"pill",style:`color:${c};border-color:${c}66`},i.sev),i.status==="proposed"?h("span",{class:"pill",style:"color:#8e4ec6;border-color:#8e4ec666"},"awaiting approval"):null,i.overdue?h("span",{class:"pill",style:"color:#e5484d;border-color:#e5484d66"},"overdue"):null,h("a",{href:"#",onclick:e=>{e.preventDefault();UI.openEntity(i.target)}},i.target)),
   h("div",{class:"d"},i.detail),h("div",{class:"m"},h("span",null,"agent: "+i.agent),h("span",null,"owner: "+(i.owner||"–")),h("span",null,"assignee: "+(i.assignee||"unassigned")),h("span",null,"due "+(i.due||"–")),h("span",null,i.ts)),
   i.chain&&i.chain.length?h("div",{class:"m"},h("span",null,"approval chain: "),...i.chain.map(s=>h("span",{class:"pill",style:`color:${s.status==="approved"?"#1a9e6e":s.status==="rejected"?"#e5484d":"#8e4ec6"};border-color:currentColor`},"L"+s.step+" "+s.role+(s.status==="approved"?" ✓ "+s.by:s.status==="rejected"?" ✗":" …")))):null,
   i.status==="proposed"&&i.turn&&!i.can_approve?h("div",{class:"m"},"Waiting for a "+i.turn+" to decide"):null,
   i.note?h("div",{class:"m"},"note: "+i.note):null,
   h("div",{class:"a"},i.status==="proposed"&&i.can_approve?[h("button",{class:"btn ok sm",onclick:()=>act(i.id,"approve")},"Approve & execute"),h("button",{class:"btn danger sm",onclick:()=>act(i.id,"reject")},"Reject")]:null,
    i.quote&&i.can_approve&&i.status!=="proposed"?[h("button",{class:"btn ok sm",onclick:()=>act(i.id,"approve")},"Approve quote"),h("button",{class:"btn danger sm",onclick:()=>act(i.id,"reject")},"Reject")]:null,
    i.can_resolve?[h("button",{class:"btn sm",onclick:()=>act(i.id,"resolve")},"Resolve"),(()=>{const a=h("input",{class:"in",style:"width:170px",placeholder:"assign to email",value:i.assignee||""});return h("span",{style:"display:flex;gap:4px"},a,h("button",{class:"btn sm",onclick:()=>a.value&&act(i.id,"assign",{assignee:a.value})},"Assign"))})()]:null,
    h("button",{class:"btn sm",onclick:()=>{st.open.has(i.id)?st.open.delete(i.id):st.open.add(i.id);draw()}},"Comments ("+i.comments.length+")")),
   st.open.has(i.id)?h("div",{class:"cm"},...i.comments.map(c=>h("div",null,h("b",null,c.by),` ${c.ts}: ${c.body}`)),(()=>{const t=h("input",{class:"in",placeholder:"Write a comment and press Enter",onkeydown:e=>{if(e.key==="Enter"&&t.value.trim())act(i.id,"comment",{body:t.value})}});return t})()):null);return t}));if(!list.length)body.append(h("div",{class:"sub"},"Nothing here."))};
 draw();return{el,update:nb=>{if(el.contains(document.activeElement)&&document.activeElement.tagName==="INPUT"){cur=nb;return}if(JSON.stringify(nb.items)+st.f+[...st.open]===st.sig)return;cur=nb;draw()}}};
// ---- charts
const FN={size3:v=>Math.max(8,Math.min(34,Math.sqrt(Math.abs(v[3]||10))*1.6)),scatterTip:p=>`<b>${esc(p.value[2]||"")}</b><br>${esc(p.seriesName||"")}<br>${p.value[0]}, ${p.value[1]}`,nodeTip:p=>p.dataType==="node"?`<b>${esc(p.name)}</b><br>${esc(p.data.tip||"")}`:"",nodeLabel:p=>p.data.showLabel?p.name:""};
function revive(o){if(Array.isArray(o))return o.map(revive);if(o&&typeof o==="object"){if(o.__fn)return FN[o.__fn];const r={};for(const k in o)r[k]=revive(o[k]);return r}return o}
echarts.registerTheme("lt",{color:["#5b5bd6","#12a594","#f5a524","#8e4ec6","#e5484d","#30a46c","#d6409f","#3e63dd","#8b8d98"],backgroundColor:"transparent",textStyle:{fontFamily:"Inter, system-ui, sans-serif",color:"#454a58"},legend:{textStyle:{color:"#454a58"}},categoryAxis:{axisLine:{lineStyle:{color:"#d9dce8"}},axisTick:{show:false},axisLabel:{color:"#6b7080"},splitLine:{lineStyle:{color:"#eceef6"}}},valueAxis:{axisLine:{show:false},axisTick:{show:false},axisLabel:{color:"#6b7080"},splitLine:{lineStyle:{color:"#eceef6"}}},tooltip:{backgroundColor:"#fff",borderColor:"#e6e8f0",textStyle:{color:"#1c2024"},extraCssText:"box-shadow:0 8px 24px rgba(20,24,40,.12);border-radius:10px"}});
const CH=[];function lazy(box,fn){let d=0;const t=()=>{if(d)return;if(box.isConnected&&box.clientWidth>0){d=1;fn()}else setTimeout(t,60)};t()}
R.chart=b=>{const el=h("div"),box=h("div",{style:`height:${b.h||290}px`});el.append(h("h3",{style:"margin:0 0 4px;font-size:13.5px;display:"+(b.title?"block":"none")},b.title||""),box);let ch=null,cur=b;
 const init=()=>{ch=echarts.init(box,"lt",{renderer:"canvas"});CH.push(ch);ch.setOption(revive(cur.opt),true);
  ch.on("click",p=>{const o=cur.open;if(!o)return;let id=null;if(o.bar)id=p.name;else if(o.scatter)id=p.value&&p.value[2];else if(o.graph)id=p.data&&p.data.open;else if(p.data&&p.data.open)id=p.data.open;if(id)UI.openEntity(id)});
  if(cur.open)box.style.cursor="pointer"};
 lazy(box,init);
 return{el,update:nb=>{cur=nb;if(ch){const r=JSON.stringify(nb.opt);if(box._h!==r){box._h=r;ch.setOption(revive(nb.opt),{replaceMerge:["series","xAxis","yAxis"]})}}},};};
window.addEventListener("resize",()=>CH.forEach(c=>{try{c.resize()}catch(e){}}));
// ---- map
function shiftGeo(g,sh){const mv=c=>typeof c[0]==="number"?[c[0]+sh,c[1]]:c.map(mv);return{type:"FeatureCollection",features:g.features.map(f=>({type:"Feature",properties:f.properties,geometry:{type:f.geometry.type,coordinates:mv(f.geometry.coordinates)}}))}}
let WORLD=null;async function world(){if(WORLD)return WORLD;try{const t=await(await fetch("/static/vendor/world.topo.json")).json();WORLD=topojson.feature(t,t.objects.countries)}catch(e){WORLD={type:"FeatureCollection",features:[]}}return WORLD}
R.map=b=>{const el=h("div"),box=h("div",{class:"map",style:`height:${b.h||470}px`}),lg=h("div",{class:"lg"});el.append(box,lg);let M=null,grp=null,cur=b;
 const draw=()=>{grp.clearLayers();const SH=[-360,0,360];cur.layers.forEach(L=>{if(L.type==="lines")L.lines.forEach(l=>{if(l.pts.length<2)return;SH.forEach(sh=>{const p=L2.polyline(l.pts.map(q=>[q[0],q[1]+sh]),{color:l.color||"#5b5bd6",weight:l.w||2,dashArray:l.dash||null,opacity:.9,lineJoin:"round",renderer:M._r});if(l.tip)p.bindTooltip(l.tip,{sticky:true});grp.addLayer(p)})});
   else if(L.type==="circles")L.items.forEach(c=>SH.forEach(sh=>{const k=L2.circle([c.lat,c.lon+sh],{radius:c.r_m,color:c.color||"#e5484d",weight:1,fillOpacity:.18,renderer:M._r});if(c.tip)k.bindTooltip(c.tip);grp.addLayer(k)}));
   else if(L.type==="points")[...L.pts].sort((a,c)=>(a.z||0)-(c.z||0)).forEach(p=>SH.forEach(sh=>{const m=L2.circleMarker([p.lat,p.lon+sh],{radius:p.r||5,color:"#ffffff",weight:1.2,fillColor:p.color||"#5b5bd6",fillOpacity:.95,renderer:M._r});if(p.tip)m.bindTooltip(p.tip,{sticky:true});const o=p.open||(cur.open?p.id:null)||p.id;if(o)m.on("click",()=>UI.openEntity(o));grp.addLayer(m)}))});
  lg.replaceChildren(...(cur.legend||[]).map(([t,c])=>h("span",null,h("i",{style:"background:"+c}),t)))};
 const L2=L;const go=async()=>{M=L2.map(box,{zoomControl:true,worldCopyJump:true,attributionControl:false,minZoom:1,preferCanvas:true});M._r=L2.canvas({padding:.5});const w=await world();[-360,0,360].forEach(sh=>L2.geoJSON(sh?shiftGeo(w,sh):w,{renderer:M._r,style:{color:"#b9b2a0",weight:.8,fillColor:"#f3efe6",fillOpacity:1},interactive:false}).addTo(M));grp=L2.layerGroup().addTo(M);
  const v=cur.view||{};if(v.bounds)M.fitBounds(v.bounds);else M.setView(v.center||[20,0],v.zoom||2);draw();setTimeout(()=>M.invalidateSize(),50)};
 lazy(box,go);
 return{el,update:nb=>{cur=nb;if(M&&grp)draw()}}};
// ---- forms
R.form=b=>{const el=h("div",{class:b.title||b.inline?"":""});const res=h("div",{class:"res"});const f=h("form",{class:"f"+(b.inline?" inline":"")});let ins={};
 b.fields.forEach(fl=>{const w=h("div",{class:"fld"+(fl.type==="textarea"||fl.type==="checks"||fl.type==="multi"?" wide":"")});if(fl.type!=="hidden")w.append(h("label",null,fl.label||fl.name));let i;
  if(fl.type==="select")i=h("select",{name:fl.name},...fl.options.map(o=>h("option",{value:o,selected:String(o)===String(fl.value)},o)));
  else if(fl.type==="multi"){i=h("select",{name:fl.name,multiple:true,size:5},...fl.options.map(o=>h("option",{value:o,selected:(fl.value||[]).includes(o)},o)))}
  else if(fl.type==="checks"){i=h("div",{class:"chk"},...fl.options.map(o=>h("label",null,h("input",{type:"checkbox",value:o,checked:(fl.value||[]).includes(o)}),o)));i.get=()=>[...i.querySelectorAll("input:checked")].map(x=>x.value)}
  else if(fl.type==="textarea")i=h("textarea",{name:fl.name,placeholder:fl.placeholder||""},fl.value||"");
  else if(fl.type==="range"){const v=h("span",{style:"color:#12a594"},fl.value);i=h("input",{type:"range",name:fl.name,min:fl.min,max:fl.max,step:fl.step||1,value:fl.value,oninput:e=>v.textContent=e.target.value});w.firstChild.append(" ",v)}
  else if(fl.type==="file")i=h("input",{type:"file",name:fl.name,accept:fl.accept||null});
  else if(fl.type==="hidden"){i=h("input",{type:"hidden",name:fl.name,value:fl.value});w.style.display="none"}
  else i=h("input",{type:fl.type==="number"?"number":fl.type==="date"?"date":fl.type==="password"?"password":"text",name:fl.name,value:fl.value==null?"":fl.value,min:fl.min,max:fl.max,step:fl.step||(fl.type==="number"?"any":null),placeholder:fl.placeholder||""});
  i.fl=fl;ins[fl.name]=i;w.append(i);f.append(w)});
 const btn=h("button",{class:"btn "+(b.tone||"primary"),type:"submit"},b.submit||"Submit");f.append(h("div",{class:"fld"},btn));
 f.addEventListener("submit",async e=>{e.preventDefault();const v={};let fd=null;for(const n in ins){const i=ins[n],fl=i.fl;if(fl.type==="file"){if(i.files[0]){fd=fd||new FormData();fd.append(n,i.files[0])}}else if(fl.type==="checks")v[n]=i.get();else if(fl.type==="multi")v[n]=[...i.selectedOptions].map(o=>o.value);else if(fl.type==="number"||fl.type==="range")v[n]=i.value===""?null:+i.value;else v[n]=i.value}
  if(b.url.startsWith("get:")){const q=new URLSearchParams();for(const n in v)if(v[n]!==""&&v[n]!=null)q.set(n,v[n]);window.open(b.url.slice(4)+"?"+q,"_blank");return}
  if(b.url.startsWith("page:")){const[,id,tab]=b.url.split(":");UI.go(id,tab||S.tab,v);return}
  btn.disabled=true;const t0=btn.textContent;btn.textContent="Working…";let r;
  if(fd){for(const n in v)fd.append(n,Array.isArray(v[n])?v[n].join(","):v[n]);r=await api(b.url,{method:"POST",body:fd})}else r=await api(b.url,{json:v});
  btn.disabled=false;btn.textContent=t0;toast(r.msg||(r.ok?"Done":"Failed"),!r.ok);res.replaceChildren();if(r.blocks){const hs=mountList(res,r.blocks,"res");}if(r.refresh)reloadPage(true)});
 if(b.title||b.sub){const c=h("div",{class:"card"},b.title?h("h3",null,b.title):null,b.sub?h("div",{class:"sub"},b.sub):null,f,res);el.append(c)}else el.append(f,res);return{el,update(){}}};
// ---- chat
async function sse(url,json,on){const r=await fetch(url,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json"},body:JSON.stringify(json)});if(!r.ok){on({ev:"final",text:"Error "+r.status});return}const rd=r.body.getReader(),dec=new TextDecoder();let buf="";for(;;){const{value,done}=await rd.read();if(done)break;buf+=dec.decode(value,{stream:true});let i;while((i=buf.indexOf("\n\n"))>=0){const m=buf.slice(0,i);buf=buf.slice(i+2);if(m.startsWith("data: ")){try{on(JSON.parse(m.slice(6)))}catch(e){}}}}}
R.chat=b=>{let cid=null,hist=[],sid="s"+Math.random().toString(36).slice(2,10),qh=[],qi=-1;const el=h("div",{class:"card chat"}),msgs=h("div",{class:"msgs"});
 const inp=h("input",{placeholder:"Ask anything: the exact SQL engine answers first, then the agents, knowledge base and GPU model for open questions",autocomplete:"off",list:"cpl",onkeydown:e=>{if(e.key==="Enter"){send(inp.value)}else if(e.key==="ArrowUp"&&qh.length){qi=Math.min(qi+1,qh.length-1);inp.value=qh[qh.length-1-qi];e.preventDefault()}else if(e.key==="ArrowDown"){qi=Math.max(qi-1,-1);inp.value=qi<0?"":qh[qh.length-1-qi];e.preventDefault()}},oninput:()=>suggest()});
 const dl=h("datalist",{id:"cpl"});let st=null;
 const suggest=()=>{clearTimeout(st);st=setTimeout(async()=>{const v=inp.value.trim();if(v.length<2){dl.replaceChildren();return}const r=await api("/api/copilot/suggest?q="+encodeURIComponent(v));dl.replaceChildren(...(r.items||[]).map(x=>h("option",{value:x})))},160)};
 const lang=h("select",{class:"in",style:"width:auto",onchange:()=>{S.lang=lang.value;localStorage.setItem("lang",S.lang)}},...b.langs.map(l=>h("option",{value:l,selected:l===S.lang},l)));
 const hsel=h("select",{class:"in",style:"width:auto;max-width:260px",onchange:()=>{if(hsel.value)openChat(hsel.value)}},h("option",{value:""},"Previous chats…"));
 const listChats=async()=>{const r=await api("/api/chats");if(!r.chats)return;hsel.replaceChildren(h("option",{value:""},r.chats.length?`Previous chats (${r.chats.length})`:"No saved chats yet"),...r.chats.map(c=>h("option",{value:c.id,selected:c.id===cid},c.title+" · "+(c.ts||"").replace("T"," ").slice(5,16))));return r.chats};
 const chipRow=items=>h("div",{class:"filters",style:"margin:8px 0 0"},...items.map(e=>h("span",{class:"chip",onclick:()=>send(e)},e)));
 const tools=(m,q)=>{const row=h("div",{class:"st",style:"display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-top:6px"});
  const cp=h("a",{class:"lnk",style:"cursor:pointer",onclick:()=>{navigator.clipboard&&navigator.clipboard.writeText(m.text);cp.textContent="Copied"}},"Copy");row.append(cp);
  if(m.csv)row.append(h("a",{class:"lnk",href:"/api/copilot/csv?sid="+encodeURIComponent(m.sid||sid),download:"copilot_result.csv"},"Download CSV"));
  const fb=v=>async()=>{await api("/api/copilot/feedback",{json:{q:q||"",helpful:v}});up.remove();dn.remove();row.append(h("span",null,v?"Thanks, noted":"Noted, logged to improve"))};
  const up=h("a",{class:"lnk",style:"cursor:pointer",title:"Helpful",onclick:fb(true)},"👍"),dn=h("a",{class:"lnk",style:"cursor:pointer",title:"Not helpful",onclick:fb(false)},"👎");row.append(up,dn);return row};
 const sqlBox=sql=>sql?h("details",{class:"cites"},h("summary",null,"Show the exact query"),h("pre",{style:"white-space:pre-wrap;font-size:11px"},sql)):null;
 const enToggle=(m,o,host)=>{if(!m.en)return;const tg=h("a",{class:"lnk",style:"cursor:pointer;font-size:12px",onclick:()=>{const on=tg._e=!tg._e;o.innerHTML=md(on?m.en:m.text);tg.textContent=on?"Show "+(m.lang||"translation"):"Show English original"}},"Show English original");host.append(h("div",{class:"st"},"Translated with NLLB-200 ",tg))};
 const showMsg=(m,i)=>{if(m.role==="user"){msgs.append(h("div",{class:"m u"},m.text));return}const o=h("div",{class:"md"});o.innerHTML=md(m.text);const a=h("div",{class:"m a"},o);enToggle(m,o,a);const sb=sqlBox(m.sql);if(sb)a.append(sb);a.append(tools(m,(hist[i-1]||{}).text));msgs.append(a)};
 const welcome=()=>{if(hist.length)return;msgs.append(h("div",{class:"m a"},h("div",{class:"md"},h("b",null,"Hi, I am your operations copilot."),h("div",{class:"st",style:"margin-top:4px"},"Exact answers come from SQL (the query is shown). Open questions use the agents, the knowledge base and the GPU model. I understand typos, follow-ups and 37 languages. Pick one to start:")),chipRow(["Briefing","What can you do?",...b.examples.slice(0,3)])))};
 const openChat=async id=>{const r=await api("/api/chats/"+encodeURIComponent(id));if(!r.msgs)return;cid=id;hist=r.msgs;msgs.replaceChildren();hist.forEach(showMsg);msgs.lastChild&&msgs.lastChild.scrollIntoView({block:"nearest"});listChats()};
 const newChat=()=>{cid=null;hist=[];msgs.replaceChildren();hsel.value="";sid="s"+Math.random().toString(36).slice(2,10);welcome();inp.focus()};
 const delChat=async()=>{if(!cid||!confirm("Delete this chat?"))return;await api("/api/chats/"+encodeURIComponent(cid),{method:"DELETE"});newChat();listChats()};
 const saveChat=async()=>{const r=await api("/api/chats/save",{json:{id:cid,msgs:hist}});if(r.id){cid=r.id;listChats()}};
 listChats().then(cs=>{if(cs&&cs.length&&!hist.length)openChat(cs[0].id);else welcome()});
 const send=async q=>{q=q.trim();if(!q)return;inp.value="";dl.replaceChildren();qh.push(q);qi=-1;hist.push({role:"user",text:q});msgs.append(h("div",{class:"m u"},q));
  const a=h("div",{class:"m a"}),stg=h("div"),tr=h("div"),out=h("div",{class:"md"}),ch=h("div"),foot=h("div");a.append(stg,tr,out,ch,foot);msgs.append(a);let acc="",base="";const sc=()=>{msgs.lastChild.scrollIntoView({block:"nearest"})};
  await sse("/api/copilot",{q,lang:S.lang,sid},ev=>{
   if(ev.ev==="stage"){stg.append(h("div",{class:"st"},ev.text))}
   else if(ev.ev==="note")stg.append(h("div",{class:"st"},"✎ "+ev.text));
   else if(ev.ev==="cites"){const d=h("details",{class:"cites"},h("summary",null,`Sources (${ev.rows.length})`),...ev.rows.map(r=>h("div",{class:"st",title:r.text},h("b",null,`[${r.n}] `),`${r.title} · ${r.source} · ${r.why||r.score}`)));stg.append(d)}
   else if(ev.ev==="trace"){tr.replaceChildren(h("div",{class:"tbl",style:"margin:6px 0"},h("table",null,h("tbody",null,...ev.rows.map(r=>h("tr",null,h("td",null,r.agent),h("td",null,h("span",{class:"pill",style:`color:${tone(r.risk)};border-color:${tone(r.risk)}55`},r.risk)),h("td",{style:"white-space:normal"},r.finding)))))))}
   else if(ev.ev==="partial"){base=ev.text;out.innerHTML=md(base)}
   else if(ev.ev==="draft"){if(!acc&&!base)out.innerHTML=md(ev.text)}
   else if(ev.ev==="tok"){acc+=ev.text;out.innerHTML=md(base?base+"\n\n"+acc:acc)}
   else if(ev.ev==="layers"){const f=(ok,t,tip)=>h("span",{class:"chip",style:"cursor:default;margin-right:4px;"+(ok?"":"opacity:.55"),title:tip||""},(ok?"✓ ":"✗ ")+t);stg.append(h("div",{class:"filters",style:"margin:4px 0"},f(ev.sql,"SQL"),f(ev.agents>0,"Agents"+(ev.agents?" "+ev.agents:""),"Findings of the latest agent cycle"),f(ev.rag>0||ev.kb_hit,"RAG"+(ev.rag?" "+ev.rag:""),ev.drive?"Google Drive knowledge connected":"Google Drive not mounted: only the built-in knowledge pack"),f(ev.llm,"LLM",ev.llm?"":"LLM state: "+ev.llm_state)))}
   else if(ev.ev==="chart"){const c=R.chart(ev.block);ch.append(c.el||c)}
   else if(ev.ev==="final"){out.innerHTML=md(ev.text);const m={role:"assistant",text:ev.text,en:ev.en,lang:ev.lang,sql:ev.sql,csv:ev.csv,sid};hist.push(m);saveChat();enToggle(m,out,stg);const sb=sqlBox(ev.sql);if(sb)foot.append(sb);foot.append(h("div",{class:"st"},`${ev.rows>0?ev.rows+" rows · ":""}done in ${(ev.ms/1000).toFixed(1)}s`+(ev.tok_s?` · ${ev.tok_s} tok/s`:"")),tools(m,q));if(ev.sugg&&ev.sugg.length)foot.append(chipRow(ev.sugg))}
   sc()})};
 el.append(h("div",{style:"display:flex;gap:8px;align-items:center;flex-wrap:wrap"},h("button",{class:"btn sm",onclick:newChat},"+ New chat"),hsel,h("button",{class:"btn sm ghost",onclick:delChat,title:"Delete this chat"},"Delete"),h("b",{style:"margin-left:8px"},"Answer language"),lang,h("span",{class:"sub",style:"margin:0"},"NLLB-200 translates in and out · ↑ recalls your last questions")),msgs,h("div",{class:"cin"},inp,dl,(()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return null;const VL={Hindi:"hi-IN",Tamil:"ta-IN",Telugu:"te-IN",Kannada:"kn-IN",Malayalam:"ml-IN",Bengali:"bn-IN",Gujarati:"gu-IN",Marathi:"mr-IN",Punjabi:"pa-IN",Urdu:"ur-IN",Arabic:"ar-SA",French:"fr-FR",German:"de-DE",Spanish:"es-ES",Portuguese:"pt-PT",Chinese:"zh-CN",Japanese:"ja-JP",Korean:"ko-KR",Russian:"ru-RU",Indonesian:"id-ID",Turkish:"tr-TR",Italian:"it-IT",Dutch:"nl-NL",Thai:"th-TH",Vietnamese:"vi-VN"};let rec=null;const mic=h("button",{class:"btn",title:"Speak your question (browser speech recognition)",onclick:()=>{if(rec){rec.stop();return}rec=new SR();const k=Object.keys(VL).find(x=>S.lang.startsWith(x));rec.lang=k?VL[k]:"en-IN";rec.interimResults=true;rec.onresult=e=>{inp.value=[...e.results].map(r=>r[0].transcript).join(" ")};rec.onend=()=>{rec=null;mic.textContent="🎤";if(inp.value.trim())send(inp.value)};mic.textContent="⏺";try{rec.start()}catch(e){rec=null;mic.textContent="🎤"}}},"🎤");return mic})(),h("button",{class:"btn primary",onclick:()=>send(inp.value)},"Ask")));return{el,update(){}}};


// ---------------------------------------------------------------- shell
const UI={};
document.addEventListener("click",e=>{const n=e.target.closest&&e.target.closest(".side .nav");if(n&&window.innerWidth<=768){const sd=document.querySelector(".side");if(sd)sd.classList.remove("open")}});
UI.logout=async()=>{try{await Promise.race([api("/api/logout",{json:{}}),new Promise(r=>setTimeout(r,2500))])}catch(e){}try{localStorage.clear();sessionStorage.clear()}catch(e){}S.me=null;location.replace(location.pathname)};
UI.openEntity=async id=>{if(!id)return;$("#dt").textContent=id;$("#db").replaceChildren(h("div",{class:"boot"},h("div",{class:"spin"}),"Loading…"));$("#drawer").classList.add("on");const d=await api("/api/detail/"+encodeURIComponent(id));if(d.title===undefined){$("#db").replaceChildren(h("div",{class:"callout warn"},d.msg||"Not available"));return}$("#dt").textContent=d.title||id;$("#db").replaceChildren();mountList($("#db"),d.blocks||[],"d");translateUI($("#db"))};
UI.closeDrawer=()=>$("#drawer").classList.remove("on");
UI.go=(id,tab,params)=>{S.page=id;S.tab=tab||null;S.params=params||{};history.replaceState(null,"","#"+id+(S.tab?":"+S.tab:""));loadPage(false);renderNav()};
// [M3] Milestone 2 pages drawn in the browser: My Profile and the Admin dashboard (users, roles, locks, activity, Teach card)
async function renderProfilePanel(){
 const box=$("#blocks");
 box.replaceChildren(h("div",{class:"boot"},h("div",{class:"spin"}),"Loading profile…"));
 const d=await api("/api/auth/profile");
 if(!d.ok){box.replaceChildren(h("div",{class:"callout error"},h("b",null,"Error: "),d.msg||"Could not load profile."));return}
 const p=d.profile||{};
 $("#ttl").textContent="My Profile";
 $("#sub").textContent="Account credentials, authorization level and security settings";

 const initials=(p.username||p.email||"U").slice(0,2).toUpperCase();
 const customAvatar=p.avatar||localStorage.getItem("fq_avatar_"+p.email);
 const fileInput=h("input",{type:"file",accept:"image/*",style:"display:none",onchange:e=>{
   const file=e.target.files[0];if(!file)return;
   if(file.size>3*1024*1024){toast("Please select an image smaller than 3MB.",true);return}
   const reader=new FileReader();
   reader.onload=evt=>{
     const img=new Image();
     img.onload=async()=>{
       const canvas=document.createElement("canvas");
       const maxDim=240;let w=img.width,h_=img.height;
       if(w>h_){if(w>maxDim){h_=Math.round(h_*maxDim/w);w=maxDim}}else{if(h_>maxDim){w=Math.round(w*maxDim/h_);h_=maxDim}}
       canvas.width=w;canvas.height=h_;
       const ctx=canvas.getContext("2d");ctx.drawImage(img,0,0,w,h_);
       const dataUrl=canvas.toDataURL("image/jpeg",0.88);
       localStorage.setItem("fq_avatar_"+p.email,dataUrl);
       try{await api("/api/auth/profile/avatar",{json:{avatar:dataUrl}})}catch(err){}
       toast("Profile picture updated!");
       renderProfilePanel();
     };
     img.src=evt.target.result;
   };
   reader.readAsDataURL(file);
 }});
 const avatarImg=h("div",{class:"profile-avatar",title:"Click to change profile picture",style:"cursor:pointer",onclick:()=>fileInput.click()},
   customAvatar?h("img",{src:customAvatar,alt:p.username||"Profile picture"}):initials
 );
 const changePicBtn=h("button",{class:"btn sm",style:"margin-top:8px;display:inline-flex;align-items:center;gap:6px",onclick:()=>fileInput.click()},"📷 Change Picture");
 const removePicBtn=h("button",{class:"btn sm ghost",style:customAvatar?"margin-top:8px;margin-left:8px":"display:none",onclick:async()=>{
   localStorage.removeItem("fq_avatar_"+p.email);
   try{await api("/api/auth/profile/avatar",{json:{avatar:""}})}catch(err){}
   toast("Profile picture removed.");
   renderProfilePanel();
 }},"🗑️ Remove");

 const heroCard=h("div",{class:"card profile-hero",style:"margin-bottom:18px"},
   h("div",{style:"display:flex;flex-direction:column;align-items:center;gap:6px"},avatarImg,fileInput),
   h("div",{class:"profile-meta",style:"flex:1"},
     h("div",{style:"display:flex;gap:10px;align-items:center;flex-wrap:wrap"},
       h("h2",{style:"margin:0;font-size:20px;font-weight:700"},p.username||"—"),
       h("span",{class:"pill pill-pri",style:"font-weight:700"},p.role||"Customer"),
       h("span",{class:"pill pill-ok",style:"font-weight:600;display:inline-flex;align-items:center;gap:4px"},h("span",{class:"dot g"}),"Active Account")
     ),
     h("div",{class:"sub",style:"margin-top:4px"},p.email),
     h("div",{style:"margin-top:8px"},changePicBtn,removePicBtn)
   )
 );

 const infoCard=h("div",{class:"card",style:"margin-bottom:18px"},
   h("h3",{style:"margin:0 0 12px"},"Account Overview"),
   h("div",{class:"grid4"},
     h("div",{class:"meta-item"},h("div",{class:"sub"},"Account ID"),h("b",null,"USR-"+String(p.id||"0").padStart(4,"0"))),
     h("div",{class:"meta-item"},h("div",{class:"sub"},"Customer ID"),h("b",null,p.customer_id||"—")),
     h("div",{class:"meta-item"},h("div",{class:"sub"},"Member Since"),h("b",null,p.created_at||"—")),
     h("div",{class:"meta-item"},h("div",{class:"sub"},"Last Login"),h("b",null,p.last_login||"Not recorded"))
   ),
   h("div",{class:"sub",style:"margin-top:14px;font-size:12px"},"Security Notice: Passwords and cryptographic hashes are never stored in plain text or returned to the browser.")
 );

 const field=(label,name,val="",type="text",req=false)=>h("label",{class:"fld"},h("span",null,label+(req?" *":"")),h("input",{class:"in",name,type,value:val,autocomplete:"off",required:req}));

 const updateForm=h("form",{class:"card"},
   h("h3",{style:"margin:0 0 4px"},"Security & Password Update"),
   h("div",{class:"sub",style:"margin-bottom:14px"},"To update your username or password, enter your current password for verification."),
   h("div",{class:"grid2"},
     field("Current Password (required)","current_password","","password",true),
     field("New Username","new_username",p.username||""),
     field("New Password","new_password","","password"),
     field("Confirm New Password","confirm_password","","password")
   ),
   h("div",{class:"sub",style:"margin-top:10px;font-size:12px"},"Password policy: Minimum 8 characters with at least one uppercase letter, one lowercase letter, one number, and one special character."),
   h("div",{style:"margin-top:16px"},
     h("button",{class:"btn primary",type:"submit"},"Save Changes")
   )
 );

 updateForm.addEventListener("submit",async e=>{
   e.preventDefault();
   const v=Object.fromEntries(new FormData(updateForm).entries());
   const submitBtn=updateForm.querySelector("button[type=submit]");
   if(submitBtn){submitBtn.disabled=true;submitBtn.textContent="Saving…"}
   try{
     const r=await api("/api/auth/profile",{json:{current_password:v.current_password,username:v.new_username,new_password:v.new_password,confirm_password:v.confirm_password}});
     toast(r.msg||"Saved",!r.ok);
     if(r.ok){
       const me=await api("/api/me");
       if(me.user)S.me=me;
       renderNav();updateThemeBtn();
       renderProfilePanel();
     }
   }finally{
     if(submitBtn){submitBtn.disabled=false;submitBtn.textContent="Save Changes"}
   }
 });

 box.replaceChildren(heroCard,infoCard,updateForm);
}

async function renderUsersPanel(){
 const box=$("#blocks");box.replaceChildren(h("div",{class:"boot"},h("div",{class:"spin"}),"Loading users…"));const d=await api("/api/auth/admin/users");if(!d.ok){box.replaceChildren(h("div",{class:"callout error"},d.msg||"Could not load users"));return}
 const roles=["Admin","Operations Manager","Freight Broker","Auditor","Customer"];const table=h("div",{class:"card"},h("h3",null,"Users and role assignments"),h("div",{class:"sub"},"Role changes take effect on the next API request. Password hashes are never returned."));
 const t=h("table",null);t.append(h("thead",null,h("tr",null,...["Username","Email","Role","Customer ID","Joined","Last login","Save"].map(x=>h("th",null,x)))));const tb=h("tbody");for(const u of d.users||[]){const sel=h("select",{class:"in"},...roles.map(r=>h("option",{value:r,selected:r===u.role},r)));const save=h("button",{class:"btn sm",onclick:async()=>{const r=await api("/api/auth/admin/users/role",{json:{user_id:u.id,role:sel.value}});toast(r.msg||"Updated",!r.ok);if(r.ok)renderUsersPanel()}},"Save");tb.append(h("tr",null,h("td",null,u.username||"—"),h("td",null,u.email),h("td",null,sel),h("td",null,u.customer_id||"—"),h("td",null,u.created_at||"—"),h("td",null,u.last_login||"—"),h("td",null,save)))}t.append(tb);table.append(h("div",{class:"tbl"},t));box.replaceChildren(table);
}
async function renderActivityPanel(){
 const box=$("#blocks");box.replaceChildren(h("div",{class:"boot"},h("div",{class:"spin"}),"Loading activity…"));const d=await api("/api/auth/admin/activity?limit=500");if(!d.ok){box.replaceChildren(h("div",{class:"callout error"},d.msg||"Could not load activity"));return}
 const card=h("div",{class:"card"},h("h3",null,"Recent platform activity"),h("div",{class:"sub"},`${(d.events||[]).length} recent events`));const t=h("table",null,h("thead",null,h("tr",null,...["Time","Actor","Event","Target","Details"].map(x=>h("th",null,x)))));const tb=h("tbody");for(const e of d.events||[])tb.append(h("tr",null,...[e.ts,e.actor,e.event,e.target,e.detail].map(x=>h("td",null,x||"—"))));t.append(tb);card.append(h("div",{class:"tbl"},t));box.replaceChildren(card);
}

function validateEmail(email){
  if(!email||typeof email!=="string") return "Email address is required.";
  email=email.trim();
  if(email.length>254) return "Email address must be 254 characters or fewer.";
  if(!email.includes("@")) return "Email address must contain an '@' symbol separating prefix and domain.";
  const parts=email.split("@");
  if(parts.length!==2) return "Email address must contain exactly one '@' symbol.";
  const [local,domain]=parts;
  if(!local) return "Email prefix (local part) cannot be empty.";
  if(local.length>64) return "Email prefix cannot exceed 64 characters.";
  if(local.startsWith(".")) return "Email prefix cannot start with a dot.";
  if(local.endsWith(".")) return "Email prefix cannot end with a dot.";
  if(local.includes("..")) return "Email prefix cannot contain consecutive dots.";
  if(!/^[A-Za-z0-9_%+-]+(?:\.[A-Za-z0-9_%+-]+)*$/.test(local)){
    return "Email prefix can only contain letters, numbers, and special characters (. _ - % +).";
  }
  if(!domain) return "Domain name cannot be empty.";
  if(domain.length>253) return "Domain name is too long.";
  if(domain.includes("..")) return "Domain name cannot contain consecutive dots.";
  if(!domain.includes(".")) return "Domain must contain a domain name and a top-level domain (like .com, .org, .net) separated by a dot.";
  const dparts=domain.split(".");
  const tld=dparts[dparts.length-1];
  if(!/^[A-Za-z]{2,}$/.test(tld)){
    return "Top-level domain (TLD) must be at least 2 alphabetical characters (e.g. .com, .org, .net).";
  }
  for(let i=0;i<dparts.length-1;i++){
    const lbl=dparts[i];
    if(!lbl) return "Domain labels cannot be empty.";
    if(lbl.startsWith("-")||lbl.endsWith("-")) return "Domain label cannot start or end with a hyphen.";
    if(!/^[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$/.test(lbl)){
      return "Domain label contains invalid characters.";
    }
  }
  return null;
}

async function renderAdminPanel(){
 const box=$("#blocks");
 box.replaceChildren(h("div",{class:"boot"},h("div",{class:"spin"}),"Loading Admin Dashboard…"));
 const [kpisRes,usersRes,actRes]=await Promise.all([api("/api/admin/kpis"),api("/api/admin/users"),api("/api/admin/activity")]);
 if(!usersRes.ok&&usersRes.msg){box.replaceChildren(h("div",{class:"callout error"},usersRes.msg||"Access denied."));return}
 $("#ttl").textContent="Admin Dashboard";
 $("#sub").textContent="User access, roles, account status, and platform audit logs";
 const kpis=kpisRes.ok?kpisRes:{total:(usersRes.users||[]).length,locked:0,roles:{}};
 const users=usersRes.users||[],events=actRes.events||[],rolesList=["Admin","Operations Manager","Freight Broker","Auditor","Customer"],addRolesList=["Customer","Freight Broker","Auditor","Operations Manager"];

 const kpiCards=h("div",{class:"grid4",style:"margin-bottom:18px"},
   h("div",{class:"card metric"},h("div",{class:"sub"},"Total Users"),h("b",{style:"font-size:26px"},kpis.total)),
   h("div",{class:"card metric"},h("div",{class:"sub"},"Locked Users"),h("b",{style:"font-size:26px;color:#cd2b31"},kpis.locked)),
   h("div",{class:"card metric"},h("div",{class:"sub"},"Administrators"),h("b",{style:"font-size:26px;color:#2855d9"},(kpis.roles||{}).Admin||0)),
   h("div",{class:"card metric"},h("div",{class:"sub"},"Users by Role"),h("div",{style:"display:flex;flex-wrap:wrap;gap:4px;margin-top:6px"},...Object.entries(kpis.roles||{}).map(([r,c])=>h("span",{class:"pill",style:"font-size:11px"},`${r}: ${c}`))))
 );

 const addEmail=h("input",{class:"in",type:"email",placeholder:"user@example.com",required:true});
 const addUser=h("input",{class:"in",placeholder:"Username",required:true});
 const addPass=h("input",{class:"in",type:"password",placeholder:"Password",required:true,onkeydown:e=>{if(e.key===" ")e.preventDefault()},oninput:e=>{if(/\s/.test(addPass.value))addPass.value=addPass.value.replace(/\s/g,"")}});
 const addRole=h("select",{class:"in"},...addRolesList.map(r=>h("option",{value:r},r)));
 const addForm=h("form",{class:"card",style:"margin-bottom:18px"},
   h("h3",null,"Add New User"),
   h("div",{class:"sub"},"Create a user account. Password rules: min 8 chars, uppercase, lowercase, number, and special character."),
   h("div",{class:"grid2",style:"margin-top:10px"},
     h("label",{class:"fld"},h("span",null,"Email"),addEmail),
     h("label",{class:"fld"},h("span",null,"Username"),addUser),
     h("label",{class:"fld"},h("span",null,"Password"),addPass),
     h("label",{class:"fld"},h("span",null,"Role"),addRole)
   ),
   h("button",{class:"btn primary",type:"submit",style:"margin-top:12px"},"Create User")
 );
 addForm.addEventListener("submit",async e=>{
   e.preventDefault();
   const emailVal=addEmail.value.trim().toLowerCase();
   const emailErr=validateEmail(emailVal);
   if(emailErr){ toast(emailErr, true); return; }
   const res=await api("/api/admin/users",{json:{email:emailVal,username:addUser.value.trim(),temporary_password:addPass.value,role:addRole.value}});
   toast(res.msg||"User created",!res.ok);
   if(res.ok){addEmail.value="";addUser.value="";addPass.value="";renderAdminPanel()}
 });

 const uTable=h("table",null);
 uTable.append(h("thead",null,h("tr",null,...["Email","Username","Role","Status","Created","Last Login","Actions"].map(x=>h("th",null,x)))));
 const uBody=h("tbody");
 for(const u of users){
   const isLocked=Boolean(u.is_locked||String(u.account_status||"").toLowerCase()==="locked"||String(u.account_status||"").toLowerCase()==="inactive"||String(u.display_status||"").toLowerCase()==="inactive");
   const isAdmin=(u.role==="Admin"||String(u.email||"").toLowerCase()==="admin@infosys.com");
   let roleCell;
   if(isAdmin){
     roleCell=h("span",{class:"pill",style:"font-weight:700;background:#edf2ff;color:#2855d9"},"Admin");
   }else{
     roleCell=h("select",{class:"in",style:"min-width:140px;padding:4px 6px"},...addRolesList.map(r=>h("option",{value:r,selected:r===u.role},r)));
     roleCell.addEventListener("change",async()=>{
       const old=u.role;
       const res=await api("/api/admin/users/"+u.id+"/role",{method:"PATCH",json:{role:roleCell.value}});
       toast(res.msg||"Role updated",!res.ok);
       if(!res.ok)roleCell.value=old;else renderAdminPanel();
     });
   }
   let actionsCell;
   if(isAdmin){
     actionsCell=h("span",{class:"muted",style:"color:var(--muted);font-weight:600;padding-left:14px"},"—");
   }else{
     const lockBtn=h("button",{class:"btn sm "+(isLocked?"primary":"secondary"),onclick:async()=>{
       const action=isLocked?"Unlock":"Lock";
       if(!confirm(`${action} account ${u.email}?`))return;
       const res=await api("/api/admin/users/"+u.id+"/status",{json:{status:isLocked?"active":"locked"}});
       toast(res.msg||`Account ${action.toLowerCase()}ed`,!res.ok);
       if(res.ok)renderAdminPanel();
     }},isLocked?"Unlock":"Lock");
     const delBtn=h("button",{class:"btn sm danger",style:"margin-left:6px",onclick:async()=>{
       if(!confirm(`Delete user ${u.email}? This cannot be undone.`))return;
       const res=await api("/api/admin/users/"+u.id,{method:"DELETE"});
       toast(res.msg||"User deleted",!res.ok);
       if(res.ok)renderAdminPanel();
     }},"Delete");
     actionsCell=h("div",{style:"display:flex"},lockBtn,delBtn);
   }
   const statusPill=h("span",{class:"pill "+(isLocked?"pill-bad":"pill-ok"),style:isLocked?"color:#cd2b31;font-weight:700":"color:#147d55;font-weight:700"},isLocked?"Inactive":"Active");
   uBody.append(h("tr",null,h("td",null,u.email),h("td",null,u.username||"—"),h("td",null,roleCell),h("td",null,statusPill),h("td",null,u.created_at||"—"),h("td",null,u.last_login||"—"),h("td",null,actionsCell)));
 }
 uTable.append(uBody);
 const usersCard=h("div",{class:"card",style:"margin-bottom:18px"},
   h("h3",null,"Users"),
   h("div",{class:"sub"},"Manage accounts, promote/demote roles, lock/unlock sessions, or remove accounts. Password hashes are never shown."),
   h("div",{class:"tbl"},uTable)
 );

 const aTable=h("table",null);
 aTable.append(h("thead",null,h("tr",null,...["When (IST)","Who","What","Target","Details"].map(x=>h("th",null,x)))));
 const aBody=h("tbody");
 if(!events.length){aBody.append(h("tr",null,h("td",{colspan:5,style:"text-align:center;padding:18px"},"No activity logged yet.")))}
 else{for(const ev of events){aBody.append(h("tr",null,h("td",null,ev.ts||"—"),h("td",null,ev.actor||"—"),h("td",null,h("span",{class:"pill"},ev.event||"—")),h("td",null,ev.target||"—"),h("td",null,ev.detail||"—")))}}
 aTable.append(aBody);
 const actCard=h("div",{class:"card"},h("h3",null,"Activity Log · Latest 50 Actions"),h("div",{class:"sub"},"Audit trail of administrative actions (who, what, when)."),h("div",{class:"tbl"},aTable));


 const teachProgress = h("h3", {style:"margin:12px 0"}, "Loading progress...");
 const teachBar = h("progress", {max:"50",value:"0",style:"width:100%"});
 const teachQuestion = h("input", {class:"in",placeholder:"Enter your question"});
 const teachAnswer = h("textarea", {class:"in",placeholder:"Enter the correct answer",rows:"4",style:"width:100%;margin-top:10px"});
 const teachMessage = h("div", {class:"sub",style:"margin-top:10px"});

 const teachSave = h("button", {class:"btn primary",style:"margin-top:10px",onclick:async()=>{
   const question=teachQuestion.value.trim();
   const answer=teachAnswer.value.trim();

   if(!question||!answer){
     teachMessage.textContent="Enter both question and answer.";
     return;
   }

   const result=await api("/api/admin/teach",{json:{question,answer}});
   teachMessage.textContent=result.msg||(result.ok?"Saved successfully.":"Could not save.");
   if(result.ok){
     teachQuestion.value="";
     teachAnswer.value="";
     loadTeachProgress();
   }
 }}, "Teach Copilot");

 const teachCSV = h("input", {type:"file",accept:".csv",style:"display:block;margin-top:12px"});
 const teachUpload = h("button", {class:"btn secondary",style:"margin-top:10px",onclick:async()=>{
   const file=teachCSV.files[0];
   if(!file){
     teachMessage.textContent="Please select a CSV file.";
     return;
   }

   const form=new FormData();
   form.append("file",file);

   try{
     const response=await fetch("/api/admin/teach/upload",{
       method:"POST",
       credentials:"same-origin",
       body:form
     });
     const result=await response.json();
     teachMessage.textContent=result.msg||(response.ok?"CSV uploaded.":"Upload failed.");
     if(response.ok)loadTeachProgress();
   }catch(error){
     teachMessage.textContent="CSV upload failed. Please try again.";
   }
 }}, "Upload CSV");

 async function loadTeachProgress(){
   const result=await api("/api/admin/teach/count");


   teachProgress.textContent=`Copilot Knowledge: ${result.total} / ${result.target}`;
   teachBar.value=result.total;
 }

 const teachCopilotCard=h("div",{class:"card",style:"margin-bottom:18px"},
   h("h3",null,"Teach Copilot"),
   h("div",{class:"sub"},"Add knowledge and improve Copilot answers."),
   teachProgress,
   teachBar,
   h("h4",{style:"margin-top:18px"},"Add Question & Answer"),
   teachQuestion,
   teachAnswer,
   teachSave,
   h("hr",{style:"margin:18px 0;border-color:var(--line)"}),
   h("h4",null,"Upload Questions CSV"),
   teachCSV,
   teachUpload,
   teachMessage
 );

 loadTeachProgress();

 box.replaceChildren(kpiCards,addForm,usersCard,teachCopilotCard,actCard);
}
async function loadPage(silent){const seq=++S.seq;clearTimeout(S.timer);const q=new URLSearchParams();if(S.tab)q.set("tab",S.tab);if(Object.keys(S.params).length)q.set("p",JSON.stringify(S.params));
 if(!silent){S.tree=null;$("#blocks").replaceChildren(h("div",{class:"boot"},h("div",{class:"spin"}),"Loading…"))}
 const t=performance.now();const d=await api(`/api/page/${S.page}?`+q);if(seq!==S.seq)return;
 if(d.blocks===undefined){$("#blocks").replaceChildren(h("div",{class:"callout error"},d.msg||"Could not load"));return}
 S.ms=Math.round(performance.now()-t);$("#ttl").textContent=d.title;$("#sub").textContent=d.sub||"";document.title=d.title+" · "+S.me.name;
 const tabs=$("#tabs");tabs.replaceChildren(...(d.tabs||[]).map(x=>h("b",{class:(S.tab||d.tabs[0].id)===x.id?"on":"",onclick:()=>{S.params={};UI.go(S.page,x.id)}},x.label)));tabs.style.display=d.tabs?"":"none";
 $("#acts").replaceChildren(...(d.actions||[]).map(a=>h("button",{class:"btn "+(a.tone||"primary"),onclick:async e=>{e.target.disabled=true;const r=await api(a.url,{json:{}});toast(r.msg,!r.ok);e.target.disabled=false;reloadPage(true)}},a.label)));
 const box=$("#blocks");
 if(S.page==="profile"){$("#tabs").style.display="none";renderProfilePanel();S.live=0;return}        // [M3] Milestone 2 profile
 if(S.page==="users"||S.page==="activity"){$("#tabs").style.display="none";renderAdminPanel();S.live=0;return}   // [M3] Milestone 2 Admin dashboard
 const focus=document.activeElement&&box.contains(document.activeElement)&&["INPUT","TEXTAREA","SELECT"].includes(document.activeElement.tagName);
 if(!S.tree||silent===false||!S.tree.ok){box.replaceChildren();S.tree={hs:mountList(box,d.blocks,"p"),ok:1,id:S.page,tab:S.tab};translateUI(box)}else S.tree.hs=updList(box,S.tree.hs,d.blocks,"p");
 S.live=d.live||0;sched()}
function sched(){clearTimeout(S.timer);if(S.live&&S.lang==="English"||S.live&&true)S.timer=setTimeout(()=>{if(!document.hidden)loadPage(true);else sched()},S.live*1000)}
function reloadPage(soft){loadPage(!!soft)}
async function translateUI(root){if(S.lang==="English")return;const nodes=[];const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let n;while((n=w.nextNode())){const t=n.nodeValue.trim();if(t.length>2&&/[A-Za-z]{3}/.test(t)&&!n.parentElement.closest("script,style,pre,code,.m.u,.mono,.noTr,input,select,option")&&!n._tr&&!(n.parentElement.closest("td")&&t.split(/\s+/).length<4)&&!/^[A-Z]{2,6}-?[A-Z]?\d+$/.test(t))nodes.push(n)}
 const list=nodes.slice(0,300);if(!list.length)return;const r=await api("/api/translate_batch",{json:{texts:list.map(n=>n.nodeValue.trim()),lang:S.lang}});if(r.out)list.forEach((n,i)=>{if(r.out[i]){n.nodeValue=r.out[i];n._tr=1}})}
const GROUPS=[["Assistant",["copilot","approvals"]],["Agents",["workforce","outlets","inventory","marketing","sentiment","audit","route","quotes","carriers","weather","margin","customs"]],["Insights",["twin","reports","notifications"]],["Platform",["feeds","users","admin","profile"]]];
function renderNav(){const nav=$("#nav");if(!nav)return;const items=[];const used=new Set();const mk=m=>h("div",{class:"nav"+(m.id===S.page?" on":"")+(m.id==="command"?" cmd":""),"data-id":m.id,onclick:()=>UI.go(m.id)},icon(m.icon),h("span",null,m.label.replace(/^Agent \d+ · /,"")),h("em",{class:"bd",style:"display:none"}));
 GROUPS.forEach(([g,ids])=>{const ms=S.me.menu.filter(m=>ids.includes(m.id));if(!ms.length)return;items.push(h("div",{class:"ngrp"},g));ms.forEach(m=>{used.add(m.id);items.push(mk(m))})});
 S.me.menu.filter(m=>!used.has(m.id)&&m.id!=="command").forEach(m=>items.push(mk(m)));const c=S.me.menu.find(m=>m.id==="command");if(c)items.push(mk(c));
 nav.replaceChildren(...items);updBadges()}
// ---- command palette (Ctrl/Cmd+K): pages, entities, ask the copilot
UI.palette=()=>{if($(".kpal"))return;let sel=0,rows=[];const inp=h("input",{placeholder:"Jump to a page, open an entity (e.g. OUT-007, QTE-0012, SHP-…), or ask the Copilot…"}),lst=h("div",{class:"lst"}),ov=h("div",{class:"kpal",onclick:e=>{if(e.target===ov)close()}},h("div",null,inp,lst));
 const close=()=>{ov.remove();document.removeEventListener("keydown",kd,true)};
 const build=()=>{const q=inp.value.trim(),ql=q.toLowerCase();rows=[];S.me.menu.filter(m=>!ql||m.label.toLowerCase().includes(ql)||m.id.includes(ql)).forEach(m=>rows.push({g:"Pages",t:m.label.replace(/^Agent \d+ · /,""),s:"go to",f:()=>UI.go(m.id)}));
  if(/^[A-Za-z]{2,5}-?[A-Za-z]?\d+$/.test(q))rows.unshift({g:"Open",t:q.toUpperCase(),s:"entity",f:()=>UI.openEntity(q.toUpperCase())});
  if(q.length>2)rows.push({g:"Ask",t:"Ask the Copilot: "+q,s:"agents + RAG",f:()=>{UI.go("copilot");setTimeout(()=>{const i=document.querySelector(".cin input");if(i){i.value=q;i.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter"}))}},700)}});
  rows.push({g:"Account",t:"Sign out",s:"",f:()=>UI.logout()});if(sel>=rows.length)sel=rows.length-1;
  let last="";lst.replaceChildren(...rows.flatMap((r,i)=>{const e=[];if(r.g!==last){last=r.g;e.push(h("div",{class:"gl"},r.g))}e.push(h("div",{class:"it"+(i===sel?" on":""),onclick:()=>{close();r.f()}},r.t,h("small",null,r.s)));return e}))};
 const kd=e=>{if(e.key==="Escape"){close()}else if(e.key==="ArrowDown"){sel=Math.min(rows.length-1,sel+1);build();e.preventDefault()}else if(e.key==="ArrowUp"){sel=Math.max(0,sel-1);build();e.preventDefault()}else if(e.key==="Enter"&&document.activeElement===inp){const r=rows[sel];if(r){close();r.f()}}};
 document.addEventListener("keydown",kd,true);inp.addEventListener("input",()=>{sel=0;build()});document.body.append(ov);build();inp.focus()};
document.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"&&S.me){e.preventDefault();UI.palette()}});
function updBadges(){const p=S.pulse;if(!p)return;const cc=$('.nav[data-id="command"] .bd');if(cc){const n=p.critical;cc.style.display=n?"":"none";cc.textContent=n;cc.className="bd"}const ap=$('.nav[data-id="approvals"] .bd');if(ap){const n=p.proposed;ap.style.display=n?"":"none";ap.textContent=n;ap.className="bd a"}
 const g=p.gpu||{};$("#gpu").innerHTML=`<span class="dot ${g.cuda?"g":"r"}"></span>${g.cuda?esc(g.name||"GPU")+" · "+g.used+"/"+g.total+" GB":"NO GPU"} · LLM ${g.llm==="downloading"?"downloading "+(g.llm_done||0)+"/"+(g.llm_total||"?")+" GB":g.llm} · NLLB ${g.nllb}${g.tok_s?" · "+g.tok_s+" tok/s":""}`;
 $("#hl").innerHTML=`<span class="dot g live"></span>live · health ${p.health==null?"–":Math.round(p.health)} · open ${p.open} · crit ${p.critical} · cycle ${p.cycles}`;$("#warn").style.display=g.cuda?"none":"";if(!p.worker_alive)$("#hl").innerHTML+=' · <b style="color:#e5484d">worker down</b>'}
function openStream(){if(S.es)S.es.close();const es=new EventSource("/api/stream");S.es=es;es.onmessage=e=>{const p=JSON.parse(e.data);if(p.error)return;const old=S.pulse;S.pulse=p;updBadges();if(old&&p.dec!==old.dec&&S.live)loadPage(true)};es.onerror=()=>{}}
// ---------------------------------------------------------------- auth screens
async function render(){const app=$("#app");if(S.es){S.es.close();S.es=null}
 const pub=await api("/api/public");S.pub=pub;
 if(!S.me){const m=await api("/api/me");if(m.user)S.me=m}
 if(!S.me){location.replace("/login");return}      // [M3] Milestone 2 sign-in page (auth.py)
 app.replaceChildren(h("div",{class:"side"},h("div",{class:"brand"},h("i",null,icon("radar")),h("div",null,S.me.name,h("small",null,S.me.user.role+" · "+S.me.user.email))),h("div",{class:"ksearch",onclick:()=>UI.palette()},"Search or ask…",h("kbd",null,"Ctrl K")),h("div",{id:"nav"}),h("div",{class:"sp"}),h("div",{class:"foot sub",style:"padding:8px"},h("button",{class:"btn sm",onclick:()=>UI.logout()},"Sign out"))),
  h("div",{class:"main"},h("div",{id:"warn",class:"warnbar",style:"display:none"},"No CUDA GPU detected: models run on CPU and will be slow. In Colab choose Runtime → Change runtime type → T4 GPU, then restart."),
   h("div",{class:"top"},h("button",{class:"mob-toggle",id:"mobNavBtn",title:"Toggle navigation",onclick:()=>{const s=document.querySelector(".side");if(s)s.classList.toggle("open")}},"☰"),h("div",null,h("h1",{id:"ttl"}),h("div",{class:"sub",id:"sub"})),h("div",{class:"sp"}),h("div",{id:"acts",style:"display:flex;gap:8px;align-items:center"}),h("button",{id:"themeBtn",class:"theme-toggle-btn",onclick:toggleTheme,title:"Toggle light/dark mode",html:document.documentElement.getAttribute("data-theme")==="dark"?'<span class="t-ico">☀️</span> Light':'<span class="t-ico">🌙</span> Dark'}),h("span",{class:"chip",id:"hl"},"connecting…"),h("span",{class:"chip",id:"gpu"}),h("span",{class:"chip",id:"ist",title:"India Standard Time"}),(()=>{const s=h("select",{class:"in",style:"width:auto;padding:4px 8px",onchange:()=>{S.lang=s.value;localStorage.setItem("lang",S.lang);loadPage(false)}},...S.me.langs.map(l=>h("option",{value:l,selected:l===S.lang},l)));return s})()),
   h("div",{class:"content"},h("div",{class:"tabs",id:"tabs"}),h("div",{id:"pg"},h("div",{class:"blocks",id:"blocks"})))));

 renderNav();updateThemeBtn();const hs=(location.hash||"").slice(1).split(":");const ok=S.me.menu.find(m=>m.id===hs[0]);S.page=ok?hs[0]:S.me.menu[0].id;S.tab=ok&&hs[1]||null;S.params={};
 loadPage(false);openStream();api("/api/pulse").then(p=>{if(!p.error){S.pulse=p;updBadges()}})}
// [M3] authView() removed: sign-in, sign-up and reset are the Milestone 2 page /login (static/login.html + auth.py)
window.UI=UI;render();
;(()=>{const f=new Intl.DateTimeFormat("en-IN",{timeZone:"Asia/Kolkata",weekday:"short",day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit",hour12:true});const t=()=>{const e=document.getElementById("ist");if(e)e.textContent="🕐 "+f.format(new Date())+" IST"};t();setInterval(t,1000)})();
