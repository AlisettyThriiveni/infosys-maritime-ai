"""Franchise simulators. Every model reads the live tables, states its assumptions, and returns money-denominated results.
run_X(a) -> {"blocks": [...], "m": {metrics used by the Digital Twin}}.  All randomness is seeded, so base and scenario use common random numbers."""
import numpy as np, pandas as pd
import blocks as B
from blocks import Q, TEAL, BLUE, AMBER, RED, VIOLET
GREY = "#8b8d98"
def g(a, k, d):
    try: return float(a.get(k, d))
    except Exception: return float(d)
def inr(x):
    x = float(x); s = "-" if x < 0 else ""; x = abs(x)
    return s + ("₹%.2f Cr" % (x / 1e7) if x >= 1e7 else "₹%.2f L" % (x / 1e5) if x >= 1e5 else "₹{:,.0f}".format(x))
ASSUME = {"inventory": "Daily demand is random (volatility is a setting). A reorder is placed when stock reaches the threshold and arrives after the lead time. Outlet revenue and costs are treated as monthly. Unit value = annualised revenue ÷ units demanded. Margin = 1 − operating costs ÷ revenue. 100 simulated 30-day futures per SKU, each with a shared ±10% demand swing across all SKUs; the same random numbers are used for baseline and scenario.",
          "workforce": "Hourly wage = salary ÷ 160. Overtime pays 1.5×, temp cover 1.3×. Each overtime hour per person per week adds 0.4 points of attrition probability. Replacing a leaver costs 50% of annual pay. Uncovered hours cost revenue in proportion to the lost labour share (80% productivity).",
          "pnl": "Price elasticity −1.2. 65% of operating costs are variable with volume; the rest are fixed. Revenue and costs in your outlets table are treated as monthly.",
          "marketing": "Response follows conversions = k·budget^α per channel (diminishing returns, α is a setting), with k fitted from your campaigns. The optimiser equalises marginal conversions across channels at a fixed total budget.",
          "sentiment": "New reviews are a mix of 1.5★ (negative wave) and 4.3★. Recovery reviews are 4.6★. Revenue moves 7% per star (public restaurant/retail studies; your own elasticity may differ).",
          "audit": "Probability an outlet fails = logistic(score vs pass mark 65, scale 6). Fine per violation is a setting. Remediation takes days you choose."}
def _cb(t): return B.callout(ASSUME[t], "info", "Assumptions (change the sliders; edit the model in sim_fr.py)")
# ------------------------------------------------------------------------------------------------ inventory
def _inv_frame():
    d = Q("SELECT i.outlet_id, i.sku_name, i.current_stock, i.reorder_threshold, i.weekly_demand, i.lead_time_days, o.revenue, o.operating_costs FROM inventory i JOIN outlets o USING(outlet_id)")
    d = d[d.weekly_demand > 0].reset_index(drop=True)
    tot = d.groupby("outlet_id").weekly_demand.transform("sum") * 52; d["uv"] = (d.revenue * 12 / tot).clip(1, 5000); d["gm"] = (1 - d.operating_costs / d.revenue).clip(.1, .6); return d
def _inv_core(d, dp, dl, buf, cv, T=30, R=100, seed=7):
    rng = np.random.default_rng(seed); N = len(d); dd = (d.weekly_demand.values / 7 * (1 + dp))[:, None]; lead = np.maximum(1, d.lead_time_days.values + int(round(dl)))[:, None]
    thr = (d.reorder_threshold.values * (1 + buf))[:, None]; Q_ = np.maximum(2 * d.weekly_demand.values[:, None] * (1 + dp), thr * 1.5)
    stock = np.repeat(d.current_stock.values[:, None].astype(np.float32), R, 1); pend = np.zeros((N, R), bool); arr = np.zeros((N, R)); lost = np.zeros((N, R), np.float32); out = np.zeros((T, N, R), bool)
    z = rng.standard_normal((T, N, R)).astype(np.float32); shock = np.exp(0.10 * rng.standard_normal((1, R))).astype(np.float32); day_lost = np.zeros((T, R), np.float64)
    uvv = d.uv.values[:, None]
    for t in range(T):
        dem = np.maximum(0, dd * shock * (1 + cv * z[t])); stock -= dem; short = np.maximum(0, -stock); lost += short; stock = np.maximum(stock, 0); out[t] = short > 0
        day_lost[t] = (short * uvv).sum(0)
        land = pend & (t >= arr); stock = np.where(land, stock + Q_, stock); pend &= ~land
        go = (~pend) & (stock <= thr); pend |= go; arr = np.where(go, t + lead, arr)
    return {"lost": lost, "out": out, "day_lost": day_lost, "stock0": d.current_stock.values, "dd": dd[:, 0], "Q": Q_[:, 0]}
def run_inventory(a):
    d = _inv_frame(); dp, dl, buf, cv = g(a, "pct", 0) / 100, g(a, "days", 0), g(a, "buffer", 0) / 100, g(a, "cv", 30) / 100; outs = a.get("outlets") or []
    if outs: d = d[d.outlet_id.isin(outs)].reset_index(drop=True)
    if not len(d): return {"blocks": [B.callout("No inventory rows for this selection.", "warn")], "m": {}}
    base = _inv_core(d, 0, 0, 0, cv); sc = _inv_core(d, dp, dl, 0, cv); uv = d.uv.values; gm = d.gm.values
    lv = lambda r: (r["lost"] * uv[:, None]); tot = lambda r: lv(r).sum(0)
    b_t, s_t = tot(base), tot(sc); p = lambda r: r["out"].sum(0).mean(1)
    bp, sp = p(base), p(sc); dem = d.weekly_demand.values / 7 * 30; fr = lambda r, dm: float(1 - r["lost"].mean(1).sum() / dm.sum()); gmm = float(np.average(gm, weights=uv * d.weekly_demand.values))
    daily = lambda r: np.cumsum(r["day_lost"], 0)
    cb, cs = daily(base), daily(sc); dif = (cs - cb) * gmm; x = [f"D{t + 1}" for t in range(cb.shape[0])]
    # buffer sweep under the scenario
    rows = []
    for b in (0, .1, .2, .3, .4, .5):
        r = _inv_core(d, dp, dl, b, cv); lost_m = float(tot(r).mean() * gmm); hold = float((d.reorder_threshold.values * b * uv * 0.25 * (30 / 365)).sum()); rows.append((b, lost_m, hold, lost_m + hold))
    best = min(rows, key=lambda r: r[3]); cur_total = rows[0][3]
    d["p_base"], d["p_scn"] = bp, sp; d["loss"] = lv(sc).mean(1); d["cover_days"] = d.current_stock / (d.weekly_demand / 7 * (1 + dp)).replace(0, np.nan)
    d["need_order"] = np.ceil(np.maximum(0, d.weekly_demand * (1 + dp) / 7 * (d.lead_time_days + dl + 3) - d.current_stock))
    top = d.sort_values("loss", ascending=False).head(15)
    byo = d.groupby("outlet_id").agg(loss=("loss", "sum"), skus_at_risk=("p_scn", lambda s: int((s > .5).sum()))).sort_values("loss", ascending=False).head(10).reset_index()
    bl = [_cb("inventory"), B.kpis(("Fill rate (demand served)", f"{fr(sc, dem * (1 + dp)):.1%}", f"now {fr(base, dem):.1%}", "Critical" if fr(sc, dem * (1 + dp)) < fr(base, dem) - .02 else None), ("Expected lost sales, 30 days", inr(s_t.mean()), f"P10–P90 {inr(np.percentile(s_t, 10))} – {inr(np.percentile(s_t, 90))}", None),
                              ("Lost gross margin", inr(s_t.mean() * gmm), f"+{inr((s_t.mean() - b_t.mean()) * gmm)} vs baseline"), ("Best safety buffer", f"+{best[0]:.0%}", f"saves {inr(cur_total - best[3])} vs none"), ("SKUs out of stock 5+ days", int((sp >= 5).sum()), f"now {int((bp >= 5).sum())}"))]
    bl.append(B.row(B.card("Cumulative lost sales over 30 days (expected)", B.chart(B.line(x, {"baseline": [round(float(v.mean()), 0) for v in cb], "scenario": [round(float(v.mean()), 0) for v in cs]}, area=False, colors=[GREY, RED]), h=260, key="inv_c"),
                           sub="Average of 100 simulated futures; P10 to P90 band is in the Digital Twin"),
                    B.card("Safety-buffer trade-off", B.chart(B.bar([f"+{r[0]:.0%}" for r in rows], {"lost margin": [round(r[1]) for r in rows], "holding cost": [round(r[2]) for r in rows]}, stack=True, colors=[RED, AMBER]), h=260, key="inv_b"), sub="Higher buffer: fewer stock-outs, more stock held")))
    bl.append(B.table(top[["outlet_id", "sku_name", "current_stock", "cover_days", "p_base", "p_scn", "loss", "need_order"]].rename(columns={"p_base": "days_out_now", "p_scn": "days_out_scn", "loss": "expected_lost_sales"}), ["outlet_id", "sku_name", B.num_col("current_stock", "stock", "int"), B.num_col("cover_days", "days of cover", "num"), B.num_col("days_out_now", "stock-out days now", "num"), B.num_col("days_out_scn", "under scenario", "num"), B.num_col("expected_lost_sales", "expected lost sales", "money"), B.num_col("need_order", "order now (units)", "int")], title="SKUs to act on first", h=420, open={"kind": "outlet", "col": "outlet_id"}, key="inv_t"))
    bl.append(B.table(byo, ["outlet_id", B.num_col("loss", "expected lost sales", "money"), B.num_col("skus_at_risk", "SKUs at risk", "int")], title="Most exposed outlets", h=300, open={"kind": "outlet", "col": "outlet_id"}, key="inv_o"))
    return {"blocks": bl, "m": {"d_samples": ((s_t - b_t) * gmm), "loss": float(s_t.mean() * gmm), "loss_base": float(b_t.mean() * gmm), "loss_p10": float(np.percentile(s_t, 10) * gmm), "loss_p90": float(np.percentile(s_t, 90) * gmm), "best_buffer": best[0], "buf_rows": rows, "buffer_saving": float(cur_total - best[3]), "at_risk": int((sp >= 5).sum()), "fill": fr(sc, dem * (1 + dp)), "fill_base": fr(base, dem), "curve": [float(v.mean()) for v in dif], "curve_lo": [float(np.percentile(v, 10)) for v in dif], "curve_hi": [float(np.percentile(v, 90)) for v in dif], "need": top[["outlet_id", "sku_name", "need_order"]].head(5).to_dict("records")}}
# ------------------------------------------------------------------------------------------------ workforce
def run_workforce(a):
    ab, cap, temp = g(a, "pct", 0) / 100, g(a, "ot_cap", 10), g(a, "temp", 0) / 100; outs = a.get("outlets") or []
    s = Q("SELECT outlet_id, COUNT(*) n, AVG(salary) sal, AVG(overtime_hrs) ot, AVG(predicted_attrition_prob) att FROM staff GROUP BY outlet_id"); o = Q("SELECT outlet_id, revenue FROM outlets")
    d = s.merge(o, on="outlet_id")
    if outs: d = d[d.outlet_id.isin(outs)]
    if not len(d): return {"blocks": [B.callout("No staff data.", "warn")], "m": {}}
    def model(ab_, cap_, temp_):
        n = d.n.values.astype(float); avail = n * (1 - ab_); need = (n - avail) * 40; hr = d.sal.values / 160; capw = cap_ * avail; ot_h = np.minimum(need, capw); rest = need - ot_h
        tmp_h = rest * temp_; gap = rest - tmp_h; ot_cost = ot_h * hr * 1.5 * 4.3; tmp_cost = tmp_h * hr * 1.3 * 4.3
        ot_pp = (ot_h / np.maximum(avail, 1)); att_up = np.minimum(.5, ot_pp * 0.004 * 1.0 * (1 if True else 0)); leav = n * att_up; repl = leav * d.sal.values * 12 * .5
        rev = gap / np.maximum(n * 40 * 4.3, 1) * 0.8 * d.revenue.values; return {"ot_cost": ot_cost, "tmp_cost": tmp_cost, "gap_h": gap * 4.3, "leav": leav, "repl": repl, "rev": rev, "cover": 1 - gap / np.maximum(need, 1) if need.sum() else np.ones(len(n))}
    b = model(0, cap, 0); s_ = model(ab, cap, temp); tot = lambda m: m["ot_cost"] + m["tmp_cost"] + m["repl"] + m["rev"]
    d = d.assign(ot_cost=s_["ot_cost"], tmp_cost=s_["tmp_cost"], gap_h=s_["gap_h"], leavers=s_["leav"], revenue_at_risk=s_["rev"], total=tot(s_), coverage=np.where((d.n * ab) > 0, 1 - s_["gap_h"] / np.maximum(d.n * ab * 40 * 4.3, 1), 1))
    sweep = [round(float(tot(model(v / 100, cap, temp)).sum())) for v in (0, 10, 20, 30, 40)]
    top = d.sort_values("total", ascending=False).head(15)
    bl = [_cb("workforce"), B.kpis(("Overtime + temp cost / month", inr(d.ot_cost.sum() + d.tmp_cost.sum()), f"overtime {inr(d.ot_cost.sum())}"), ("Uncovered labour hours", f"{d.gap_h.sum():,.0f}", "service gap" if d.gap_h.sum() else "fully covered", "Critical" if d.gap_h.sum() > 500 else None), ("Revenue at risk / month", inr(d.revenue_at_risk.sum())), ("Extra expected leavers", f"{d.leavers.sum():.1f}", f"replacement {inr(s_['repl'].sum())}")),
          B.row(B.card("Total monthly cost by absenteeism", B.chart(B.bar(["0%", "10%", "20%", "30%", "40%"], {"cost": sweep}, colors=[VIOLET]), h=250, key="wf_sw"), sub="Overtime, temp cover, replacements, lost revenue"),
                B.card("Outlets with the largest cost", B.chart(B.bar(top.outlet_id, {"overtime": [round(x) for x in top.ot_cost], "temp": [round(x) for x in top.tmp_cost], "revenue at risk": [round(x) for x in top.revenue_at_risk]}, stack=True, colors=[AMBER, BLUE, RED]), h=250, key="wf_o"))),
          B.table(top[["outlet_id", "n", "ot_cost", "tmp_cost", "gap_h", "leavers", "revenue_at_risk", "coverage"]], ["outlet_id", B.num_col("n", "staff", "int"), B.num_col("ot_cost", "overtime cost", "money"), B.num_col("tmp_cost", "temp cost", "money"), B.num_col("gap_h", "uncovered hrs", "int"), B.num_col("leavers", "extra leavers", "num"), B.num_col("revenue_at_risk", "revenue at risk", "money"), B.num_col("coverage", "coverage", "pct")], title="Outlets to staff first", h=420, open={"kind": "outlet", "col": "outlet_id"}, key="wf_t")]
    return {"blocks": bl, "m": {"cost": float(d.total.sum()), "ot": float(d.ot_cost.sum() + d.tmp_cost.sum()), "rev_risk": float(d.revenue_at_risk.sum()), "leavers": float(d.leavers.sum()), "gap_h": float(d.gap_h.sum()), "sweep": sweep, "model": lambda ab_, cap_, temp_: float(tot(model(ab_, cap_, temp_)).sum())}}
# ------------------------------------------------------------------------------------------------ outlet P&L
def run_pnl(a):
    dp, pp, cp = g(a, "pct", 0) / 100, g(a, "price", 0) / 100, g(a, "cost", 0) / 100; outs = a.get("outlets") or []
    o = Q("SELECT outlet_id, location, revenue, operating_costs FROM outlets")
    if outs: o = o[o.outlet_id.isin(outs)]
    e = -1.2; v = .65
    def pl(dp_, pp_, cp_):
        vol = (1 + dp_) * (1 + e * pp_); rev = o.revenue * vol * (1 + pp_); cost = o.operating_costs * (v * vol * (1 + cp_) + (1 - v) * (1 + cp_)); return rev, cost, rev - cost, vol
    r0, c0, p0, _ = pl(0, 0, 0); r1, c1, p1, vol = pl(dp, pp, cp)
    # effect decomposition (sequential)
    ps = [p0.sum(), pl(dp, 0, 0)[2].sum(), pl(dp, pp, 0)[2].sum(), p1.sum()]; deltas = [ps[1] - ps[0], ps[2] - ps[1], ps[3] - ps[2]]
    o = o.assign(profit_now=p0, profit_scn=p1, delta=p1 - p0, margin_scn=np.where(r1 > 0, p1 / r1, 0))
    sweep = [round(float(pl(x / 100, pp, cp)[2].sum())) for x in (-30, -15, 0, 15, 30)]
    worst = o.sort_values("delta").head(15)
    bl = [_cb("pnl"), B.kpis(("Total profit", inr(p1.sum()), f"{inr(p1.sum() - p0.sum())} vs now", "Critical" if p1.sum() < p0.sum() * .9 else "Low" if p1.sum() > p0.sum() * 1.02 else None), ("Margin", f"{p1.sum() / max(r1.sum(), 1):.1%}", f"now {p0.sum() / max(r0.sum(), 1):.1%}"), ("Loss-making outlets", int((p1 < 0).sum()), f"now {int((p0 < 0).sum())}", "Critical" if (p1 < 0).sum() > (p0 < 0).sum() else None), ("Revenue", inr(r1.sum()), f"{inr(r1.sum() - r0.sum())}")),
          B.row(B.card("What moved profit", B.chart(B.waterfall(["Demand", "Price", "Costs"], [round(x) for x in deltas], "Net change"), h=260, key="pl_w")),
                B.card("Profit vs demand change", B.chart(B.bar(["-30%", "-15%", "0", "+15%", "+30%"], {"profit": sweep}, colors=[TEAL]), h=260, key="pl_s"), sub="With your price and cost settings")),
          B.table(worst[["outlet_id", "location", "profit_now", "profit_scn", "delta", "margin_scn"]], ["outlet_id", "location", B.num_col("profit_now", "profit now", "money"), B.num_col("profit_scn", "profit scenario", "money"), B.num_col("delta", "change", "money"), B.num_col("margin_scn", "margin", "pct")], title="Outlets hit hardest", h=420, open={"kind": "outlet", "col": "outlet_id"}, key="pl_t")]
    return {"blocks": bl, "m": {"profit_delta": float(p1.sum() - p0.sum()), "loss_makers": int((p1 < 0).sum()), "profit": float(p1.sum()), "model": lambda dp_, pp_, cp_: float(pl(dp_, pp_, cp_)[2].sum() - p0.sum())}}
# ------------------------------------------------------------------------------------------------ marketing
def _mk_frame():
    m = Q("SELECT channel, SUM(budget) B, SUM(conversions) C, COUNT(*) n FROM marketing WHERE budget>0 GROUP BY channel"); m["channel"] = m.channel.replace({"Influencer Campaign": "Influencer", "Social Media": "Social"}); return m.groupby("channel", as_index=False).agg(B=("B", "sum"), C=("C", "sum"), n=("n", "sum"))
def run_marketing(a):
    bp, al = g(a, "pct", 0) / 100, g(a, "alpha", 70) / 100; m = _mk_frame()
    if not len(m): return {"blocks": [B.callout("No campaigns.", "warn")], "m": {}}
    k = m.C / m.B ** al; B0 = m.B.values; tot = B0.sum() * (1 + bp); conv = lambda Bv: float((k.values * Bv ** al).sum())
    w = (k.values * al) ** (1 / (1 - al)); opt = tot * w / w.sum(); keep = B0 * (1 + bp)
    m = m.assign(budget_now=B0, budget_keep=keep, budget_opt=opt, conv_now=m.C, conv_keep=k.values * keep ** al, conv_opt=k.values * opt ** al, cpc_now=B0 / m.C, cpc_opt=opt / (k.values * opt ** al))
    sweep = [round(conv(B0 * (1 + x / 100))) for x in (-30, -15, 0, 25, 50)]; up = conv(opt) - conv(keep)
    bl = [_cb("marketing"), B.kpis(("Conversions now", f"{m.C.sum():,.0f}"), ("Conversions with this budget", f"{conv(keep):,.0f}", f"{conv(keep) - m.C.sum():+,.0f}"), ("With optimal allocation", f"{conv(opt):,.0f}", f"+{up:,.0f} for the same spend", "Low" if up > 0 else None), ("Cost per conversion", inr(tot / conv(opt)), f"now {inr(B0.sum() / m.C.sum())}")),
          B.row(B.card("Budget by channel", B.chart(B.bar(m.channel, {"now": [round(x) for x in B0], "this scenario": [round(x) for x in keep], "optimal": [round(x) for x in opt]}, colors=[GREY, BLUE, TEAL]), h=270, key="mk_b")),
                B.card("Diminishing returns", B.chart(B.bar(["-30%", "-15%", "0", "+25%", "+50%"], {"conversions": sweep}, colors=[VIOLET]), h=270, key="mk_s"), sub="Total conversions as the whole budget changes")),
          B.table(m[["channel", "n", "budget_now", "budget_opt", "conv_now", "conv_opt", "cpc_now", "cpc_opt"]], ["channel", B.num_col("n", "campaigns", "int"), B.num_col("budget_now", "budget now", "money"), B.num_col("budget_opt", "optimal budget", "money"), B.num_col("conv_now", "conversions now", "int"), B.num_col("conv_opt", "conversions optimal", "int"), B.num_col("cpc_now", "cost/conv now", "money"), B.num_col("cpc_opt", "cost/conv optimal", "money")], title="Where to move money", h=330, key="mk_t")]
    return {"blocks": bl, "m": {"uplift": float(up), "conv": conv(keep), "conv_opt": conv(opt), "conv_now": float(m.C.sum())}}
# ------------------------------------------------------------------------------------------------ sentiment
def run_sentiment(a):
    neg, n_new, star = g(a, "pct", 25) / 100, g(a, "n_new", 30), 0.07; outs = a.get("outlets") or []
    f = Q("SELECT outlet_id, COUNT(*) n, AVG(rating) r FROM feedback GROUP BY outlet_id"); o = Q("SELECT outlet_id, revenue FROM outlets"); d = f.merge(o, on="outlet_id")
    if outs: d = d[d.outlet_id.isin(outs)]
    mix = neg * 1.5 + (1 - neg) * 4.3; d = d.assign(r_new=(d.n * d.r + n_new * mix) / (d.n + n_new)); d["rec_n"] = np.ceil(np.maximum(0, n_new * (d.r - mix) / (4.6 - d.r).clip(lower=.1)))
    d["rev_risk"] = np.maximum(0, d.r - d.r_new) * star * d.revenue; sw = [round(float((d.n * d.r + n_new * ((x / 100) * 1.5 + (1 - x / 100) * 4.3)).sum() / (d.n + n_new).sum()), 2) for x in (0, 10, 25, 50, 75)]
    wt = d.sort_values("rev_risk", ascending=False).head(15)
    bl = [_cb("sentiment"), B.kpis(("Average rating", f"{(d.r_new * d.n).sum() / d.n.sum():.2f}★", f"now {(d.r * d.n).sum() / d.n.sum():.2f}★"), ("Outlets below 3.5★", int((d.r_new < 3.5).sum()), f"now {int((d.r < 3.5).sum())}", "Critical" if (d.r_new < 3.5).sum() > (d.r < 3.5).sum() else None), ("Revenue at risk", inr(d.rev_risk.sum())), ("Good reviews needed to recover", f"{d.rec_n.sum():,.0f}", "4.6★ replies across the chain")),
          B.card("Chain rating vs share of negative reviews", B.chart(B.bar(["0%", "10%", "25%", "50%", "75%"], {"rating": sw}, colors=[AMBER], max_=5), h=240, key="se_s")),
          B.table(wt[["outlet_id", "n", "r", "r_new", "rev_risk", "rec_n"]], ["outlet_id", B.num_col("n", "reviews", "int"), B.num_col("r", "rating now", "num"), B.num_col("r_new", "rating after", "num"), B.num_col("rev_risk", "revenue at risk", "money"), B.num_col("rec_n", "good reviews to recover", "int")], title="Outlets most exposed", h=400, open={"kind": "outlet", "col": "outlet_id"}, key="se_t")]
    return {"blocks": bl, "m": {"rev_risk": float(d.rev_risk.sum()), "below35": int((d.r_new < 3.5).sum())}}
# ------------------------------------------------------------------------------------------------ audit
def run_audit(a):
    raise_ = g(a, "raise", 0); extra = g(a, "pct", 0) / 100; fine = g(a, "fine", 5000); days = g(a, "days", 14); outs = a.get("outlets") or []
    d = Q("SELECT outlet_id, score, violations FROM audits WHERE audit_id IN (SELECT audit_id FROM audits a2 WHERE a2.outlet_id=audits.outlet_id ORDER BY audit_date DESC LIMIT 1)")
    if outs: d = d[d.outlet_id.isin(outs)]
    if not len(d): return {"blocks": [B.callout("No audit data.", "warn")], "m": {}}
    pf = lambda sc, mark: 1 / (1 + np.exp((sc - mark) / 6)); p0 = pf(d.score.values, 65); sc1 = d.score.values - extra * 20; p1 = pf(sc1, 65 + raise_); v1 = d.violations.values * (1 + extra)
    d = d.assign(p_now=p0, p_scn=p1, viol_scn=v1, fines=p1 * v1 * fine, rem_days=np.where(p1 > .5, days, 0))
    sw = [round(float(pf(d.score.values - extra * 20, 65 + x).sum()), 1) for x in (0, 5, 10, 15)]
    wt = d.sort_values("p_scn", ascending=False).head(15)
    bl = [_cb("audit"), B.kpis(("Expected failing outlets", f"{p1.sum():.1f}", f"now {p0.sum():.1f}", "Critical" if p1.sum() > p0.sum() + 2 else None), ("Expected fines", inr(d.fines.sum())), ("Outlets likely to fail (>50%)", int((p1 > .5).sum()), f"now {int((p0 > .5).sum())}"), ("Outlet-days under remediation", f"{d.rem_days.sum():,.0f}")),
          B.card("Expected failures vs stricter pass mark", B.chart(B.bar(["65", "70", "75", "80"], {"expected failures": sw}, colors=[RED]), h=240, key="au_s")),
          B.table(wt[["outlet_id", "score", "violations", "p_now", "p_scn", "fines"]], ["outlet_id", B.num_col("score", "last score", "num"), B.num_col("violations", "violations", "int"), B.num_col("p_now", "fail risk now", "pct"), B.num_col("p_scn", "fail risk scenario", "pct"), B.num_col("fines", "expected fines", "money")], title="Outlets to prepare first", h=400, open={"kind": "outlet", "col": "outlet_id"}, key="au_t")]
    return {"blocks": bl, "m": {"fines": float(d.fines.sum()), "fail": float(p1.sum())}}
RUN = {"inventory": run_inventory, "workforce": run_workforce, "outlets": run_pnl, "marketing": run_marketing, "sentiment": run_sentiment, "audit": run_audit}
