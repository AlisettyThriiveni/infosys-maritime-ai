"""Question understanding for the Copilot, ahead of the generic table query (qa.py). Each handler computes the answer from live data and returns
{"answer": lead text (markdown), "df": optional table, "sql": how it was computed, "extra": more markdown}. Nothing here asks the language model for a number."""
import re, json, datetime
import numpy as np, pandas as pd
from blocks import Q
import qa as QA, alts
CITY_STATE = {"Mumbai": "Maharashtra", "Pune": "Maharashtra", "Nashik": "Maharashtra", "Nagpur": "Maharashtra", "Delhi": "Delhi", "Bengaluru": "Karnataka", "Mysuru": "Karnataka", "Hyderabad": "Telangana", "Chennai": "Tamil Nadu", "Coimbatore": "Tamil Nadu", "Madurai": "Tamil Nadu",
              "Kolkata": "West Bengal", "Ahmedabad": "Gujarat", "Surat": "Gujarat", "Vadodara": "Gujarat", "Jaipur": "Rajasthan", "Lucknow": "Uttar Pradesh", "Kochi": "Kerala", "Thiruvananthapuram": "Kerala", "Chandigarh": "Chandigarh", "Bhopal": "Madhya Pradesh", "Indore": "Madhya Pradesh",
              "Patna": "Bihar", "Ranchi": "Jharkhand", "Raipur": "Chhattisgarh", "Bhubaneswar": "Odisha", "Guwahati": "Assam", "Goa": "Goa", "Visakhapatnam": "Andhra Pradesh", "Vijayawada": "Andhra Pradesh", "Kanpur": "Uttar Pradesh", "Dehradun": "Uttarakhand", "Amritsar": "Punjab", "Ludhiana": "Punjab"}
CHOKE = {"suez": ("Suez Canal", 30.5, 32.3), "panama": ("Panama Canal", 9.1, -79.7), "malacca": ("Strait of Malacca", 2.5, 101.5), "hormuz": ("Strait of Hormuz", 26.5, 56.5), "bosphorus": ("Bosphorus", 41.1, 29.0), "cape": ("Cape of Good Hope", -34.4, 18.5), "red sea": ("Red Sea", 18.0, 40.0)}
def _w(q, t): return re.search(r"(?<![a-z0-9])" + re.escape(t) + r"(?![a-z0-9])", q) is not None
def _md(df, n=10): return QA.md(df.head(n)) if df is not None and len(df) else ""
def _health(dec): return (((dec or {}).get("ev") or {}).get("health")) or {}
def _agent_scores(e):
    import entities as EN; out = {}
    for a in ("outlet", "inventory", "staff", "marketing", "audit", "feedback"):
        v = EN.latest_out(a).get("per_outlet", {}).get(e)
        if v is not None: out[a] = round(float(v), 1)
    return out
NEXT = {"staffing_shortage": "add a cover shift or move staff from a nearby outlet", "health_alert": "review the lowest agent score below and fix that first", "reorder": "place the reorder or transfer stock from a nearby outlet", "stockout": "reorder now or transfer stock",
        "corrective_action": "complete the corrective plan before the re-audit", "anomaly_review": "check the POS feed and the day's sales for this outlet", "campaign_review": "pause or re-target the campaign", "retention": "talk to the staff at risk and review overtime"}
# ------------------------------------------------------------------------------------------------ Franchise
def explain_outlet(e, dec):
    o = Q("SELECT * FROM outlets WHERE outlet_id=?", (e,))
    if not len(o): return None
    r = o.iloc[0]; h = _health(dec).get(e); sc = _agent_scores(e); tk = Q("SELECT action_id id, type, severity, status, detail FROM agent_actions WHERE target=? AND status IN ('open','proposed') ORDER BY CASE severity WHEN 'Critical' THEN 0 WHEN 'Warning' THEN 1 ELSE 2 END, action_id DESC LIMIT 8", (e,))
    avg = Q("SELECT AVG(revenue) rv, AVG(customer_satisfaction) cs FROM outlets").iloc[0]; low = Q("SELECT COUNT(*) n FROM inventory WHERE outlet_id=? AND current_stock<=reorder_threshold*1.5", (e,)).n[0]
    att = Q("SELECT AVG(predicted_attrition_prob) p, COUNT(*) n FROM staff WHERE outlet_id=?", (e,)).iloc[0]
    lines = []
    if h is not None: lines.append(f"Health score **{h:.1f}**/100 ({'Critical' if h < 60 else 'Needs attention' if h < 80 else 'Healthy'}).")
    if sc: worst = sorted(sc.items(), key=lambda kv: kv[1])[:2]; lines.append("Weakest areas: " + ", ".join(f"**{a}** {v}" for a, v in worst) + " (each agent scores 0-100, higher is better).")
    lines.append(f"Revenue {r.revenue:,.0f} ({(r.revenue / avg.rv - 1):+.0%} vs chain average), satisfaction {r.customer_satisfaction:.2f} (chain {avg.cs:.2f}), {int(att.n)} staff with average attrition risk {att.p:.0%}, {int(low)} SKUs at or near reorder level.")
    why = "\n".join(f"- {t.type} ({t.severity}): {t.detail}" + (f" → {NEXT[t.type]}" if t.type in NEXT else "") for t in tk.itertuples()) or "- no open tickets"
    return {"answer": (f"**{e}** ({r.outlet_name}, {r.location}) is flagged because:\n" if (h is None or h < 80 or len(tk)) else f"**{e}** ({r.outlet_name}, {r.location}) is not flagged right now; here is its status:\n") + "\n".join("- " + l for l in lines) + "\n\n**Open tickets:**\n" + why, "df": pd.DataFrame([{"agent": a, "score": v} for a, v in sc.items()]) if sc else None, "sql": f"decision health + agent per_outlet scores + agent_actions for {e}"}
def risk_rank(q, dec, scope, n=5):
    _m = re.search(r"(?<![-\d])\b(\d{1,2})\b(?!\d)", q)
    if _m and 1 <= int(_m.group(1)) <= 50: n = int(_m.group(1))
    hl = _health(dec)
    if not hl: return None
    s = pd.Series(hl).astype(float); worst = bool(re.search(r"\b(highest risk|most at risk|worst|lowest|riskiest|critical|weakest|needs? attention|problem|bottom)\b", q)); best = bool(re.search(r"\b(best|top|highest health|strongest|healthiest)\b", q)) and not re.search(r"highest risk", q)
    both = re.search(r"best.*worst|worst.*best", q) is not None
    if scope: s = s[s.index == scope]
    o = Q("SELECT outlet_id, outlet_name, location, revenue, customer_satisfaction csat FROM outlets").set_index("outlet_id")
    def frame(ix):
        rows = []
        for e in ix:
            sc = _agent_scores(e); wk = min(sc, key=sc.get) if sc else "-"; ct = int(Q("SELECT COUNT(*) n FROM agent_actions WHERE target=? AND status IN ('open','proposed') AND severity='Critical'", (e,)).n[0])
            rows.append({"outlet": e, "name": o.name if False else (o.outlet_name.get(e, "") if e in o.index else ""), "location": o.location.get(e, ""), "health": round(float(s[e]), 1), "weakest_area": f"{wk} {sc.get(wk, '')}", "critical_tickets": ct, "revenue": o.revenue.get(e), "csat": o.csat.get(e)})
        return pd.DataFrame(rows)
    low = s.sort_values().head(n).index; hi = s.sort_values(ascending=False).head(n).index
    if both or (best and worst):
        a, b = frame(hi), frame(low); return {"answer": f"Best outlet: **{a.outlet[0]}** (health {a.health[0]}). Worst outlet: **{b.outlet[0]}** (health {b.health[0]}). Health combines outlet, inventory, staff, marketing, audit and feedback agent scores.", "df": None, "sql": "decision health per outlet", "extra": "**Top " + str(n) + " by health**\n" + QA.md(a) + "\n\n**Bottom " + str(n) + " by health**\n" + QA.md(b)}
    if best and not worst: d = frame(hi); return {"answer": f"Healthiest outlet: **{d.outlet[0]}** (health {d.health[0]}, {d.location[0]}). Top {n} below.", "df": d, "sql": "decision health per outlet, descending"}
    d = frame(low); crit = int((s < 60).sum()); return {"answer": f"Highest risk: **{d.outlet[0]}** (health {d.health[0]}, weakest area {d.weakest_area[0]}). {crit} outlets are below 60 (critical). Lowest {n} below; ask \"why is {d.outlet[0]} flagged\" for the reasons.", "df": d, "sql": "decision health per outlet, ascending"}
def inventory_status(scope):
    w = " WHERE outlet_id=?" if scope else ""; p = (scope,) if scope else ()
    d = Q("SELECT outlet_id, sku_name, category, current_stock st, reorder_threshold thr, weekly_demand wk, lead_time_days lead, stockout_risk_prob p FROM inventory" + w, p)
    if not len(d): return None
    d["cover_d"] = d.st / (d.wk / 7).replace(0, np.nan); below = d[d.st <= d.thr]; wk1 = d[d.cover_d < 7]; lt = d[d.cover_d < d.lead]
    po = Q("SELECT status, COUNT(*) n FROM purchase_orders" + w + " GROUP BY status", p); cat = d.groupby("category").agg(skus=("sku_name", "count"), below_reorder=("st", lambda s: int((d.loc[s.index, "st"] <= d.loc[s.index, "thr"]).sum())), avg_cover_days=("cover_d", "mean"), avg_risk=("p", "mean")).reset_index().sort_values("avg_risk", ascending=False)
    worst = d.sort_values("cover_d").head(8)[["outlet_id", "sku_name", "st", "cover_d", "lead", "p"]].rename(columns={"st": "stock", "cover_d": "days_of_cover", "lead": "lead_days", "p": "stockout_risk"})
    return {"answer": f"Inventory: **{len(d):,}** SKU records; **{len(below):,}** at or below reorder level, **{len(wk1):,}** have under 7 days of cover, **{len(lt):,}** will run out before a new order can arrive (cover shorter than lead time). Average stock-out risk {d.p.mean():.0%}." + (" Open purchase orders: " + ", ".join(f"{r.status} {r.n}" for r in po.itertuples()) + "." if len(po) else ""), "df": worst, "sql": "inventory: stock vs reorder threshold, cover = stock ÷ daily demand", "extra": "**By category**\n" + QA.md(cat.round(2))}
def sales_trend(scope):
    w = " AND outlet_id=?" if scope else ""; p = (scope,) if scope else ()
    d = Q(f"SELECT substr(ts,1,10) day, SUM(amount) amount, SUM(tx_count) tx FROM sales WHERE ts IS NOT NULL{w} GROUP BY day ORDER BY day DESC LIMIT 14", p)
    if len(d) < 2: return None
    d = d.iloc[::-1].reset_index(drop=True); last7, prev7 = d.tail(7).amount.sum(), d.iloc[:-7].tail(7).amount.sum() if len(d) > 7 else np.nan
    ch = f" ({(last7 / prev7 - 1):+.1%} vs the 7 days before)" if prev7 == prev7 and prev7 else ""
    return {"answer": f"Sales over the last 7 recorded days: **{last7:,.0f}**{ch}. Best day {d.loc[d.amount.idxmax(), 'day']} ({d.amount.max():,.0f}), weakest {d.loc[d.amount.idxmin(), 'day']} ({d.amount.min():,.0f}).", "df": d.tail(10), "sql": "sales grouped by day"}

def _place(ql):
    """Find a state or city named in the question. Returns ("state"|"city", name) or None."""
    flat = re.sub(r"[^a-z]", "", ql); cities = Q("SELECT DISTINCT location FROM outlets").location.dropna().tolist()
    for st in sorted(set(CITY_STATE.values()), key=len, reverse=True):
        if re.sub(r"[^a-z]", "", st.lower()) in flat: return "state", st
    for ct in sorted(cities, key=len, reverse=True):
        if re.search(r"\b" + re.escape(ct.lower()) + r"\b", ql): return "city", ct
    return None
def outlets_in_place(ql, scope=None):
    pl = _place(ql)
    if not pl: return None
    kind, name = pl; o = Q("SELECT outlet_id, outlet_name name, location, tier, revenue, customer_satisfaction csat, staff_headcount staff FROM outlets")
    o["state"] = o.location.map(CITY_STATE).fillna("Other"); d = o[o.state == name] if kind == "state" else o[o.location == name]
    if not len(d): return {"answer": f"No outlets found in {name}.", "df": None, "sql": "outlets filtered by place"}
    by = d.groupby("location").size().sort_values(ascending=False); txt = ", ".join(f"{k} {v}" for k, v in by.items())
    return {"answer": f"**{len(d)}** outlets in {name}" + (f": {txt}." if kind == "state" else "."), "df": d.drop(columns=["state"]).sort_values(["location", "outlet_id"]), "sql": f"outlets where {'state (from city)' if kind == 'state' else 'location'} = {name}"}
def staff_by_place(ql, scope=None):
    s = Q("SELECT s.staff_id, s.outlet_id, o.location FROM staff s LEFT JOIN outlets o USING(outlet_id)")
    if not len(s): return None
    s["state"] = s.location.map(CITY_STATE).fillna("Other"); pl = _place(ql)
    if pl:
        kind, name = pl; d = s[s.state == name] if kind == "state" else s[s.location == name]; g = d.groupby("location").size().sort_values(ascending=False).reset_index(name="employees")
        return {"answer": f"**{len(d):,}** employees in {name}" + (f"; most in **{g.location.iloc[0]}** ({int(g.employees.iloc[0]):,})." if len(g) else "."), "df": g, "sql": f"staff joined to outlets, place = {name}"}
    by_state = bool(re.search(r"\bstates?\b", ql)); by_out = bool(re.search(r"\boutlets?\b", ql)); col = "outlet_id" if by_out else ("state" if by_state else "location")
    g = s.groupby(col).size().sort_values(ascending=False).head(15).reset_index(name="employees"); low = bool(re.search(r"\b(fewest|least|lowest|less|low number)\b", ql)); r = (s.groupby(col).size().sort_values().reset_index(name="employees").iloc[0] if low else g.iloc[0])
    return {"answer": f"**{r[col]}** has the {'fewest' if low else 'most'} employees: **{int(r.employees):,}** (of {len(s):,} in total, by {'outlet' if by_out else 'state' if by_state else 'city'}).", "df": g, "sql": f"staff joined to outlets, grouped by {col}"}
def by_state(q):
    o = Q("SELECT outlet_id, location, revenue FROM outlets"); o["state"] = o.location.map(CITY_STATE).fillna("Other"); g = o.groupby("state").agg(outlets=("outlet_id", "count"), revenue=("revenue", "sum")).reset_index().sort_values("outlets", ascending=False)
    low = bool(re.search(r"\b(fewest|least|lowest)\b", q)); r = g.iloc[-1] if low else g.iloc[0]
    return {"answer": f"**{r.state}** has the {'fewest' if low else 'most'} outlets: **{int(r.outlets)}**. Your outlets table stores the city, so states are derived from the city name.", "df": g, "sql": "outlets grouped by state (city → state mapping)"}
def staff_status(scope):
    w = " WHERE outlet_id=?" if scope else ""; p = (scope,) if scope else ()
    s = Q("SELECT outlet_id, role, overtime_hrs ot, predicted_attrition_prob pr FROM staff" + w, p); at = Q("SELECT status, COUNT(*) n FROM attendance" + (" WHERE outlet_id=?" if scope else "") + " GROUP BY status", p)
    if not len(s): return None
    hi = s[s.pr > .6]; g = s.groupby("outlet_id").pr.mean().sort_values(ascending=False).head(8).reset_index().rename(columns={"pr": "avg_attrition_risk"})
    return {"answer": f"Workforce: **{len(s):,}** staff, **{len(hi):,}** at high attrition risk (>60%), average overtime {s.ot.mean():.1f} h" + (". Attendance: " + ", ".join(f"{r.status} {r.n:,}" for r in at.itertuples()) if len(at) else "") + ".", "df": g, "sql": "staff + attendance", }
# ------------------------------------------------------------------------------------------------ Freight
STOP = {"long", "port", "new", "fort", "saint", "south", "north", "east", "west", "city", "bay", "cape", "grand", "great", "royal", "santa", "puerto", "king", "bandar"}
def _ports_in(q):
    p = Q("SELECT port_name FROM ports").port_name.tolist(); spans = []; first = {}
    for name in p:
        core = [w for w in re.sub(r"\(.*?\)", "", name).lower().split() if w not in QA.GENERIC]
        if core and len(core[0]) >= 4 and core[0] not in STOP: first.setdefault(core[0], []).append(name)
    for name in p:
        als = set(QA._alias(name)); core = [w for w in re.sub(r"\(.*?\)", "", name).lower().split() if w not in QA.GENERIC]
        if core and core[0] not in STOP and len(first.get(core[0], [])) == 1 and len(core[0]) >= 4: als.add(core[0])
        for al in sorted(als, key=len, reverse=True):
            m = re.search(r"(?<![a-z0-9])" + re.escape(al) + r"(?![a-z0-9])", q)
            if m: spans.append((m.start(), m.end(), len(al), name)); break
    spans.sort(key=lambda x: (-x[2], x[0])); kept = []
    for s_ in spans:
        if not any(s_[0] < k[1] and k[0] < s_[1] for k in kept): kept.append(s_)
    kept.sort(); return [k[3] for k in kept], kept
def plan_lane(q, dom):
    ps, hits = _ports_in(re.sub(r"how long", "how_long", q.lower()))
    if len(ps) < 2: return None
    pre = q.lower(); o, d = ps[0], ps[1]; m = re.search(r"from\s+(.+?)\s+to\s+", pre)
    cargo = next((k for k in dom.CARGO if k.lower() in pre or k.lower().rstrip("s") in pre), "General"); wm = re.search(r"(\d+(?:\.\d+)?)\s*(t|tons?|tonnes?|mt|kg|kgs)\b", pre); wt = 20.0
    if wm: wt = float(wm.group(1)) / (1000 if wm.group(2).startswith("kg") else 1)
    po, pd_ = dom.port_xy(o), dom.port_xy(d)
    if not po or not pd_: return None
    cust = Q("SELECT customer_id FROM customers LIMIT 1").customer_id[0]; req = {"origin": o, "dest": d, "cargo": cargo, "weight_t": wt, "hs_code": "HS-8501", "customer_id": cust, "docs_provided": None}
    pq = dom.preview_quote(req); opts = alts.route_alternatives(dom, (po[0], po[1]), (pd_[0], pd_[1]), tonnes=wt, interp=dom.interp, dwell=(po[3] + pd_[3]) * .5)
    if not pq and not opts: return None
    rows = [{"option": f"{i + 1}. {x['label']}", "route": x["name"], "nm": x["nm"], "days": round(x["days"], 1), "freight_cost": round(x["freight"]), "time_cost": round(x["delay_cost"]), "total": round(x["total"]), "tag": x["tag"]} for i, x in enumerate(opts)]
    head = f"**{o} → {d}**, {wt:g} t of {cargo}: "
    if pq: head += f"recommended route **{pq['route']}**, about **{pq['days']} days** at sea and in port, quoted price **${pq['price']:,.0f}** (margin {pq['margin_pct']}%), weather risk {pq['weather']}, decision: {pq['decision']}."
    elif opts: head += f"best route **{opts[0]['name']}**, about **{opts[0]['days']} days**."
    ex = (pq["narrative"] if pq and pq.get("narrative") else "") + ("\n\nOnly one sea route exists for this lane in the routing model (it does not pass a closable canal or strait), so the alternatives are commercial: another carrier, or diverting to a nearby less-congested port (open the port in the map to see candidates)." if len(opts) == 1 else "")
    return {"answer": head, "df": pd.DataFrame(rows) if rows else None, "sql": "dom.preview_quote (route, weather, ML price, customs, margin) + sea-route alternatives; nothing was saved", "extra": ex, "map": opts}
def choke_ports(q):
    k = next((k for k in CHOKE if _w(q, k)), None)
    if not k: return None
    name, la, lo = CHOKE[k]; p = Q("SELECT port_name, country, congestion_index ci, avg_dwell_days dw, lat, lon FROM ports"); p["km"] = alts.hav(la, lo, p.lat.values, p.lon.values); near = p[p.km <= 1800].sort_values("ci", ascending=False)
    v = Q("SELECT COUNT(*) n FROM vessels WHERE route_name LIKE ?", (f"%{name.split()[0]}%",)).n[0]; sh = Q("SELECT COUNT(*) n FROM shipments s JOIN vessels v USING(shipment_id) WHERE v.route_name LIKE ? AND s.status LIKE '%Delay%'", (f"%{name.split()[0]}%",)).n[0]
    if not len(near): return None
    return {"answer": f"Ports within 1,800 km of the **{name}**: **{len(near)}**; **{int((near.ci >= 4).sum())}** are congested (index ≥ 4). Most congested: **{near.port_name.iloc[0]}** ({near.ci.iloc[0]:.1f}, dwell {near.dw.iloc[0]:.1f} days). {int(v)} tracked vessels are routed via this passage, {int(sh)} of them delayed.", "df": near[["port_name", "country", "ci", "dw", "km"]].rename(columns={"ci": "congestion", "dw": "dwell_days", "km": "km_from_passage"}), "sql": f"ports within 1,800 km of {name}"}
def freight_summary(q):
    if re.search(r"\bcustoms\b", q) and re.search(r"\b(hold|held|status|summary|how many|why|docs?|documents?)\b", q):
        d = Q("SELECT dest_port, COUNT(*) n FROM shipments WHERE status='Customs Hold' GROUP BY dest_port ORDER BY n DESC LIMIT 8"); t = int(Q("SELECT COUNT(*) n FROM shipments WHERE status='Customs Hold'").n[0]); tk = Q("SELECT detail FROM agent_actions WHERE type='customs_docs' AND status IN ('open','proposed') LIMIT 400")
        miss = pd.Series([x for dd in tk.detail for x in re.findall(r"missing ([^:]+?)(?:\.|$)", dd)[0].split(", ")] if len(tk) and all("missing" in x for x in tk.detail) else []).value_counts().head(6)
        return {"answer": f"**{t}** shipments are on customs hold. Most held at **{d.dest_port.iloc[0] if len(d) else '-'}**." + (" Most often missing: " + ", ".join(f"{k} ({v})" for k, v in miss.items()) + "." if len(miss) else ""), "df": d.rename(columns={"n": "held"}), "sql": "shipments with status Customs Hold; customs_docs tickets"}
    return None
def greeting(q, kind):
    ql = re.sub(r"[^a-z0-9 ?']", " ", q.lower()).strip()
    hi = re.match(r"^(hi+|hello+|hey+|hola|namaste|good (morning|afternoon|evening)|greetings|yo|sup|howdy)\b( there| team| copilot| buddy)?$", ql)
    thanks = re.match(r"^(thanks?|thank you|thx|ok(ay)?|cool|great|nice|got it|awesome)( a lot| so much)?$", ql)
    who = re.search(r"\b(who are you|what are you|what can you do|what do you do|help me|how can you help|your capabilities|what is this)\b", ql) or ql in ("help", "?")
    how = re.match(r"^how are you", ql)
    if not (hi or thanks or who or how): return None
    ex = (["Which stock needs immediate refill?", "Which outlets are at highest risk and why?", "Top 5 outlets by revenue", "Why is OUT-007 flagged?", "Which state has the most outlets?"] if kind == "Franchise" else
          ["Mumbai to Singapore 50 t electronics: days, cost and best route", "Which ports are most congested?", "How many shipments are on customs hold?", "What quotes need approval?"])
    what = ("outlets, stock, staff, marketing, audits, customer feedback and anomalies" if kind == "Franchise" else "routes, ports, weather, customs, quotes and carriers")
    if thanks: return {"answer": "You're welcome. Ask me anything else about " + what + ".", "df": None, "sql": ""}
    head = "Hello! " if hi else ("I'm doing well, thank you. " if how else "")
    return {"answer": head + f"I'm your operations copilot. I answer from your live data on {what}, and I can explain *why* something is flagged, suggest actions and send them to the approval queue. I understand 37 languages.\n\nTry one of these:\n" + "\n".join(f"- {e}" for e in ex), "df": None, "sql": ""}

def refill(scope, n=10):
    w = " WHERE outlet_id=?" if scope else ""; p = (scope,) if scope else ()
    d = Q("SELECT outlet_id, sku_name sku, category, current_stock stock, reorder_threshold thr, weekly_demand wk, lead_time_days lead FROM inventory" + w, p)
    if not len(d): return None
    d["daily"] = d.wk / 7.0; d["cover"] = d.stock / d.daily.replace(0, np.nan); d["cover"] = d.cover.fillna(999)
    d["order_qty"] = np.maximum(d.thr * 3, np.ceil(d.daily * (d.lead + 7)) - d.stock).astype(int)
    d["gap"] = d.cover - d.lead
    d["urgency"] = np.where(d.cover < d.lead, "Critical: runs out before delivery", np.where(d.stock <= d.thr, "High: below reorder level", np.where(d.cover < 7, "Medium: under 7 days", "OK")))
    d["rank"] = d.urgency.str[:4].map({"Crit": 0, "High": 1, "Medi": 2}).fillna(3); need = d[d.urgency != "OK"].sort_values(["rank", "gap", "cover"])
    if not len(need): return {"answer": "No SKU needs an urgent refill right now: all have stock above the reorder level and cover longer than the supplier lead time.", "df": None, "sql": "inventory: cover = stock / daily demand vs lead time"}
    crit = need[need.urgency.str.startswith("Critical")]; po = Q("SELECT outlet_id, sku_name FROM purchase_orders WHERE status IN ('open','ordered','pending','Pending','Ordered','Open')" + (" AND outlet_id=?" if scope else ""), p) if "purchase_orders" in [r[0] for r in Q("SELECT name FROM sqlite_master WHERE type='table'").values] else None
    top = need.head(n)[["outlet_id", "sku", "stock", "thr", "cover", "lead", "order_qty", "urgency"]].rename(columns={"thr": "reorder_level", "cover": "days_of_cover", "lead": "lead_days"}); top["days_of_cover"] = top.days_of_cover.round(1)
    pool = crit if len(crit) else need[need.urgency.str.startswith("High")] if (need.urgency.str.startswith("High")).any() else need; by = pool.groupby("outlet_id").size().sort_values(ascending=False).head(5)
    outs = ", ".join(f"{k} ({v} SKUs)" for k, v in by.items()) if len(by) else "none"
    return {"answer": f"**{len(crit):,}** SKU records will run out *before a new order can arrive* (days of cover < supplier lead time) and **{len(need) - len(crit):,}** more are low. Most urgent outlets: {outs}. The table lists the {len(top)} most urgent SKUs, with the quantity to order.",
            "df": top, "sql": "inventory: days_of_cover = stock / (weekly_demand/7); urgent when cover < lead_time_days; order_qty = max(3 x reorder level, daily demand x (lead + 7 days) - stock)",
            "extra": "**How to read it:** *days_of_cover* is how long current stock lasts at current demand; *lead_days* is how long the supplier takes. When cover is shorter than lead time, stock-out is certain unless you order now (or transfer stock from a nearby outlet). Approve the matching *reorder* tickets in **Approvals** to raise the orders."}

# [M3] Milestone 2 Copilot fine-tuning: typo normaliser + 25 whitelisted freight intents (every number comes from SQL)
def _normalise_question(q):
    """Robust typo and wording normalisation for the Copilot."""
    import difflib
    q = str(q or "").lower().strip()
    direct_replacements = {
        "wich": "which", "qoutes": "quotes", "qoute": "quote", "heaviestt": "heaviest",
        "rotterdm": "rotterdam", "rotterdamm": "rotterdam", "roterdam": "rotterdam",
        "singapor": "singapore", "singapoor": "singapore", "singapre": "singapore",
        "shanghi": "shanghai", "shangai": "shanghai",
        "antwerpp": "antwerp", "hamburgg": "hamburg",
        "mumbay": "mumbai", "chenai": "chennai", "dubaii": "dubai",
        "maerskk": "maersk", "maersck": "maersk",
        "hapagg": "hapag-lloyd", "hapag lloyd": "hapag-lloyd", "hapag": "hapag-lloyd",
        "evergren": "evergreen", "coscoo": "cosco", "cma-cgm": "cma cgm", "cmacgm": "cma cgm",
        "cheepest": "cheapest", "cheep": "cheap", "chepest": "cheapest",
        "conjestion": "congestion", "congeston": "congestion",
        "shipements": "shipments", "shipemnts": "shipments",
        "customs holded": "customs hold", "custons": "customs",
        "stoms": "storms", "stormes": "storms", "stroms": "storms", "wether": "weather",
        "delaied": "delayed", "delaed": "delayed", "delyed": "delayed",
        "carriar": "carrier", "carier": "carrier",
        "margen": "margin", "margine": "margin", "proffit": "profit",
        "relible": "reliable", "reliablity": "reliability",
        "weigt": "weight", "waight": "weight",
        "vesels": "vessels", "vesel": "vessel",
        "tarrif": "tariff", "tarif": "tariff", "dutys": "duty",
        "expensiv": "expensive"
    }
    for typo, fix in direct_replacements.items():
        q = re.sub(r"\b" + re.escape(typo) + r"\b", fix, q)
    q = re.sub(r"\b(show me|can you show|can you tell me|please tell me|please list|could you find|i want to know|what is|which are|give me|list of|tell me about|i need to see|please)\b", " ", q)
    q = re.sub(r"\s+", " ", q).strip()
    vocab = [
        "cheapest", "cheaper", "carrier", "carriers", "shipment", "shipments", "customs", "hold", "held",
        "quote", "quotes", "margin", "congestion", "congested", "port", "ports", "storm", "storms",
        "weather", "delayed", "delay", "reliable", "reliability", "rotterdam", "singapore", "shanghai",
        "status", "average", "highest", "lowest", "below", "near", "route", "routes", "expensive",
        "dwell", "severity", "vessel", "vessels", "weight", "tariff", "tariffs", "duty", "duties",
        "action", "actions", "ticket", "tickets", "pending", "alert", "alerts", "customer", "customers",
        "credit", "risk", "speed", "knots", "progress"
    ]
    words = q.split()
    fixed = []
    for w in words:
        if len(w) >= 5 and w not in vocab and re.fullmatch(r"[a-z]+", w):
            m = difflib.get_close_matches(w, vocab, n=1, cutoff=0.82)
            fixed.append(m[0] if m else w)
        else:
            fixed.append(w)
    return " ".join(fixed)

def freight_intents(q):
    """Comprehensive whitelisted analyst intents. Every answer is backed by live SQL."""
    q = _normalise_question(q)
    # 1. cheapest carrier serving a destination
    m = re.search(r"\b(?:cheapest|lowest[- ]cost|least expensive|cheap)\b.*\b(?:carrier|shipping line|liner)\b.*\b(?:to|for|serving|into)\s+([a-z][a-z .\'-]{1,40})", q)
    if not m:
        m = re.search(r"\b(?:carrier|shipping line)\b.*\b(?:cheapest|lowest[- ]cost|cheap)\b.*\b(?:to|for|serving|into)\s+([a-z][a-z .\'-]{1,40})", q)
    if m:
        dest = re.split(r"\b(?:with|and|under|below|please)\b", m.group(1))[0].strip(" ?.!").lower()
        sql = """SELECT s.carrier, ROUND(AVG(q.final_price),2) AS avg_quote_price, COUNT(*) AS quote_count
FROM freight_quotes q JOIN shipments s ON s.shipment_id=q.shipment_id
WHERE lower(s.dest_port) LIKE ? AND s.carrier IS NOT NULL
GROUP BY s.carrier ORDER BY avg_quote_price ASC LIMIT 10"""
        d = Q(sql, (f"%{dest}%",))
        if len(d):
            return {"answer": f"Lowest average quoted price for destination **{dest.title()}**: **{d.carrier.iloc[0]}** (${d.avg_quote_price.iloc[0]:,.2f} average across {int(d.quote_count.iloc[0])} quotes).", "df": d, "sql": sql, "rows_count": len(d)}

    # 2. quotes below a requested margin threshold
    if re.search(r"\b(quotes?|pricing)\b", q) and re.search(r"\b(margins?|profit)\b", q) and re.search(r"\b(below|under|less than|lower than)\b", q):
        m = re.search(r"\b(?:below|under|less than|lower than)\s+(\d+(?:\.\d+)?)\s*%?", q)
        threshold = float(m.group(1)) if m else 10.0
        sql = "SELECT quote_id, shipment_id, carrier, final_price, margin_pct, status FROM freight_quotes WHERE margin_pct < ? ORDER BY margin_pct ASC LIMIT 50"
        d = Q(sql, (threshold,))
        return {"answer": f"Found **{len(d)}** quotes below {threshold:g}% margin.", "df": d, "sql": sql, "rows_count": len(d)}

    # 3. customs hold count/list
    if re.search(r"\b(customs|clearance)\b", q) and re.search(r"\b(hold|held|stuck|detained|waiting)\b", q):
        sql = "SELECT shipment_id, origin_port, dest_port, carrier, status, eta FROM shipments WHERE lower(status) LIKE '%customs%hold%' ORDER BY eta LIMIT 50"
        d = Q(sql)
        return {"answer": f"Found **{len(d)}** shipments currently on customs hold.", "df": d, "sql": sql, "rows_count": len(d)}

    # 4. most congested ports
    if re.search(r"\b(ports?|harbours?|harbors?|terminals?)\b", q) and re.search(r"\b(congest\w*|crowded|busiest)\b", q):
        sql = "SELECT port_name, country, region, congestion_index, avg_dwell_days FROM ports ORDER BY congestion_index DESC LIMIT 10"
        d = Q(sql)
        return {"answer": f"Top **{len(d)}** most congested ports ranked by congestion index.", "df": d, "sql": sql, "rows_count": len(d)}

    # 5. storms near a named region
    if re.search(r"\b(storms?|weather|wind|waves?|cyclones?)\b", q) and re.search(r"\b(red sea|suez|panama|hormuz|malacca|mediterranean|atlantic|pacific|singapore|mumbai|shanghai|rotterdam)\b", q):
        region = next((x for x in ["red sea","suez","panama","hormuz","malacca","mediterranean","atlantic","pacific","singapore","mumbai","shanghai","rotterdam"] if x in q), "")
        sql = "SELECT port_name, current_severity, forecast, wind_speed, wave_height FROM weather_risks WHERE lower(port_name) LIKE ? OR lower(forecast) LIKE ? ORDER BY current_severity DESC LIMIT 20"
        d = Q(sql, (f"%{region}%", f"%{region}%"))
        return {"answer": f"Weather and storm records matching **{region.title()}**: **{len(d)}** rows found.", "df": d, "sql": sql, "rows_count": len(d)}

    # 6. most reliable / best on-time carriers
    if re.search(r"\b(carriers?|shipping lines?)\b", q) and re.search(r"\b(reliab\w*|on[- ]time|punctual\w*|best performance)\b", q):
        sql = "SELECT name, rating, on_time_pct, avg_cost_index, risk_level FROM carriers ORDER BY on_time_pct DESC LIMIT 10"
        d = Q(sql)
        best = f" Best: **{d.name.iloc[0]}** ({d.on_time_pct.iloc[0]}% on-time)." if len(d) else ""
        return {"answer": f"Top **{len(d)}** carriers ranked by on-time delivery performance.{best}", "df": d, "sql": sql, "rows_count": len(d)}

    # 7. lowest cost index carriers
    if re.search(r"\b(carriers?|shipping lines?)\b", q) and re.search(r"\b(lowest|cheapest|least)\b", q) and re.search(r"\b(cost index|cost)\b", q):
        sql = "SELECT name, rating, on_time_pct, avg_cost_index, risk_level FROM carriers ORDER BY avg_cost_index ASC LIMIT 10"
        d = Q(sql)
        cheapest = f" Lowest: **{d.name.iloc[0]}** (index {d.avg_cost_index.iloc[0]})." if len(d) else ""
        return {"answer": f"Top **{len(d)}** carriers with the lowest cost index.{cheapest}", "df": d, "sql": sql, "rows_count": len(d)}

    # 8. delayed shipments / delay risk
    if re.search(r"\b(shipments?|cargos?|containers?)\b", q) and re.search(r"\b(delayed|delay|late|behind schedule)\b", q):
        sql = "SELECT shipment_id, origin_port, dest_port, carrier, status, predicted_delay_risk, eta FROM shipments WHERE lower(status) LIKE '%delay%' OR predicted_delay_risk > 0.6 ORDER BY predicted_delay_risk DESC LIMIT 50"
        d = Q(sql)
        return {"answer": f"Found **{len(d)}** shipments marked delayed or with high delay risk (>60%).", "df": d, "sql": sql, "rows_count": len(d)}

    # 9. heaviest shipments by cargo weight
    if re.search(r"\b(heaviest|largest|biggest)\b", q) and re.search(r"\b(shipments?|cargos?|containers?|weights?|tonnage)\b", q):
        sql = "SELECT shipment_id, origin_port, dest_port, carrier, weight_kg, status FROM shipments ORDER BY weight_kg DESC LIMIT 10"
        d = Q(sql)
        heaviest = f" Heaviest: **{d.shipment_id.iloc[0]}** ({d.weight_kg.iloc[0]:,.0f} kg)." if len(d) else ""
        return {"answer": f"Top **{len(d)}** heaviest shipments in transit.{heaviest}", "df": d, "sql": sql, "rows_count": len(d)}

    # 10. high credit risk customers
    if re.search(r"\b(customers?|clients?|shippers?)\b", q) and re.search(r"\b(credit risk|financial risk|high risk|bad credit)\b", q):
        sql = "SELECT customer_id, name, industry, priority_tier, credit_risk FROM customers ORDER BY credit_risk DESC LIMIT 10"
        d = Q(sql)
        highest = f" Highest risk: **{d.name.iloc[0]}** (score {d.credit_risk.iloc[0]})." if len(d) else ""
        return {"answer": f"Top **{len(d)}** customers ranked by credit risk score.{highest}", "df": d, "sql": sql, "rows_count": len(d)}

    # 11. pending quote requests
    if re.search(r"\b(pending|open|unquoted|waiting)\b", q) and re.search(r"\b(quotes?|quote requests?|enquir\w*|inquir\w*)\b", q):
        sql = "SELECT req_id, ts, origin, dest, cargo, weight_t, status FROM quote_requests WHERE lower(status)='pending' OR quote_id IS NULL ORDER BY req_id DESC LIMIT 50"
        d = Q(sql)
        return {"answer": f"Found **{len(d)}** pending quote requests awaiting pricing or approval.", "df": d, "sql": sql, "rows_count": len(d)}

    # 12. most expensive / highest quotes
    if re.search(r"\b(highest|most expensive|costliest|priciest)\b", q) and re.search(r"\b(quotes?|prices?|quotations?|pricing)\b", q):
        sql = "SELECT quote_id, shipment_id, customer_id, carrier, final_price, margin_pct, status FROM freight_quotes ORDER BY final_price DESC LIMIT 10"
        d = Q(sql)
        highest = f" Highest: **{d.quote_id.iloc[0]}** (${d.final_price.iloc[0]:,.2f})." if len(d) else ""
        return {"answer": f"Top **{len(d)}** highest priced freight quotes.{highest}", "df": d, "sql": sql, "rows_count": len(d)}

    # 13. fastest vessels underway
    if re.search(r"\b(vessels?|ships?)\b", q) and re.search(r"\b(speed|fastest|moving|knots|underway)\b", q):
        sql = "SELECT shipment_id, route_name, lat, lon, progress, speed_kn FROM vessels WHERE speed_kn > 0 ORDER BY speed_kn DESC LIMIT 10"
        d = Q(sql)
        fastest = f" Fastest: **{d.shipment_id.iloc[0]}** on {d.route_name.iloc[0]} ({d.speed_kn.iloc[0]} knots)." if len(d) else ""
        return {"answer": f"Top **{len(d)}** fastest active vessels underway.{fastest}", "df": d, "sql": sql, "rows_count": len(d)}

    # 14. customs tariffs / duty rates
    if re.search(r"\b(customs|import|tariff|tariffs|duties|duty)\b", q) and re.search(r"\b(rates?|rules?|goods|chapters?|highest|list|fees?)\b", q):
        sql = "SELECT chapter, goods, duty_pct, docs, restricted FROM customs_rules ORDER BY duty_pct DESC LIMIT 20"
        d = Q(sql)
        top_rate = f" Highest rate: **{d.goods.iloc[0]}** ({d.duty_pct.iloc[0]}%)." if len(d) else ""
        return {"answer": f"Customs tariff rates across commodities.{top_rate}", "df": d, "sql": sql, "rows_count": len(d)}

    # 15. open / critical agent action tickets
    if re.search(r"\b(critical|urgent|high severity|open)\b", q) and re.search(r"\b(tickets?|actions?|alerts?|agent actions?)\b", q):
        sql = "SELECT action_id, ts, type, target, severity, status, owner, detail FROM agent_actions WHERE status IN ('open', 'proposed') ORDER BY CASE severity WHEN 'Critical' THEN 0 WHEN 'Warning' THEN 1 ELSE 2 END, action_id DESC LIMIT 20"
        d = Q(sql)
        return {"answer": f"Found **{len(d)}** active agent action tickets.", "df": d, "sql": sql, "rows_count": len(d)}

    # 16. shipments per carrier
    if re.search(r"\b(shipments?|containers?)\b", q) and re.search(r"\b(per carrier|by carrier|carrier volume|carrier share)\b", q):
        sql = "SELECT carrier, COUNT(*) AS shipment_count, ROUND(AVG(weight_kg), 1) AS avg_weight_kg FROM shipments WHERE carrier IS NOT NULL GROUP BY carrier ORDER BY shipment_count DESC"
        d = Q(sql)
        return {"answer": f"Shipment distribution across active carriers ({len(d)} carriers):", "df": d, "sql": sql, "rows_count": len(d)}

    # 17. top origin ports by volume
    if re.search(r"\b(origin ports?|departure ports?|busiest origin)\b", q):
        sql = "SELECT origin_port, COUNT(*) AS departure_count FROM shipments GROUP BY origin_port ORDER BY departure_count DESC LIMIT 10"
        d = Q(sql)
        return {"answer": f"Top **{len(d)}** origin ports by departure shipment volume:", "df": d, "sql": sql, "rows_count": len(d)}

    # 18. average margin by carrier
    if re.search(r"\b(margins?|profit)\b", q) and re.search(r"\b(carrier|carriers)\b", q):
        sql = "SELECT carrier, ROUND(AVG(margin_pct), 2) AS avg_margin_pct, COUNT(*) AS quote_count FROM freight_quotes WHERE carrier IS NOT NULL GROUP BY carrier ORDER BY avg_margin_pct DESC LIMIT 10"
        d = Q(sql)
        return {"answer": f"Average profit margin by carrier across all quotes ({len(d)} carriers):", "df": d, "sql": sql, "rows_count": len(d)}

    # 19. shipments for a specific carrier
    m = re.search(r"\b(?:shipments?|cargo)\b.*\b(?:by|for|from|assigned to|with)\s+(maersk|msc|hapag[- ]lloyd|cma cgm|evergreen|cosco)\b", q)
    if not m:
        m = re.search(r"\b(maersk|msc|hapag[- ]lloyd|cma cgm|evergreen|cosco)\b.*\b(?:shipments?|cargo)\b", q)
    if m:
        cname = m.group(1).strip()
        sql = "SELECT shipment_id, origin_port, dest_port, carrier, status, eta FROM shipments WHERE lower(carrier) LIKE ? ORDER BY eta LIMIT 50"
        d = Q(sql, (f"%{cname}%",))
        return {"answer": f"Found **{len(d)}** shipments assigned to **{cname.title()}**.", "df": d, "sql": sql, "rows_count": len(d)}

    # 20. ports with longest dwell
    if re.search(r"\b(ports?)\b", q) and re.search(r"\b(longest dwell|highest dwell|slowest dwell|dwell times?|dwell days?)\b", q):
        sql = "SELECT port_name, country, region, avg_dwell_days, congestion_index FROM ports ORDER BY avg_dwell_days DESC LIMIT 10"
        d = Q(sql)
        slowest = f" Longest: **{d.port_name.iloc[0]}** ({d.avg_dwell_days.iloc[0]} days)." if len(d) else ""
        return {"answer": f"Top **{len(d)}** ports with the longest average dwell times.{slowest}", "df": d, "sql": sql, "rows_count": len(d)}

    # 21. quotes grouped by status
    if re.search(r"\b(quotes?)\b", q) and re.search(r"\b(by status|status breakdown|group by status)\b", q):
        sql = "SELECT status, COUNT(*) AS quote_count FROM freight_quotes GROUP BY status ORDER BY quote_count DESC"
        d = Q(sql)
        return {"answer": "Quote counts by status:", "df": d, "sql": sql, "rows_count": len(d)}

    # 22. shipments grouped by status
    if re.search(r"\b(shipments?|containers?)\b", q) and re.search(r"\b(status breakdown|by status|group by status)\b", q):
        sql = "SELECT status, COUNT(*) AS shipment_count FROM shipments GROUP BY status ORDER BY shipment_count DESC"
        d = Q(sql)
        return {"answer": "Shipment counts by status:", "df": d, "sql": sql, "rows_count": len(d)}

    # 23. average quote margin overall
    if re.search(r"\b(average|avg|mean)\b", q) and re.search(r"\b(margins?|profit)\b", q) and re.search(r"\b(quotes?|overall|pricing)\b", q):
        sql = "SELECT COUNT(*) AS quote_count, ROUND(AVG(margin_pct),2) AS average_margin_pct, MIN(margin_pct) AS min_margin_pct, MAX(margin_pct) AS max_margin_pct FROM freight_quotes"
        d = Q(sql)
        avg = d.average_margin_pct.iloc[0] if len(d) else None
        return {"answer": f"Average quote margin is **{avg}%** across {int(d.quote_count.iloc[0])} quotes.", "df": d, "sql": sql, "rows_count": len(d)}

    # 24. active vessels by route
    if re.search(r"\b(vessels?|ships?)\b", q) and re.search(r"\b(by route|per route|routes?)\b", q):
        sql = "SELECT route_name, COUNT(*) AS vessel_count, ROUND(AVG(speed_kn), 1) AS avg_speed_kn FROM vessels GROUP BY route_name ORDER BY vessel_count DESC"
        d = Q(sql)
        return {"answer": f"Active vessels grouped by shipping route ({len(d)} routes):", "df": d, "sql": sql, "rows_count": len(d)}

    # 25. high wave / wind severity weather alerts
    if re.search(r"\b(weather|storm|waves?|wind)\b", q) and re.search(r"\b(severe|critical|dangerous|rough|warnings?)\b", q):
        sql = "SELECT port_name, current_severity, forecast, wind_speed, wave_height FROM weather_risks ORDER BY current_severity DESC, wave_height DESC LIMIT 15"
        d = Q(sql)
        return {"answer": "Most severe port weather and marine hazard records:", "df": d, "sql": sql, "rows_count": len(d)}

    return None

# ------------------------------------------------------------------------------------------------ router
def answer(kind, q, scope=None, dec=None, dom=None):
    r = _answer(kind, q, scope, dec, dom)
    if r: r["complete"] = True
    return r
def _answer(kind, q, scope=None, dec=None, dom=None):
    g = greeting(q, kind)
    if g: return g
    q = _normalise_question(q)      # [M3] Milestone 2: typos and filler words
    ql = q.lower().strip(); ids = re.findall(r"\b(OUT-\d+|STF-\d+|SHP-[A-Z0-9-]+|QTE-[A-Z0-9-]+)\b", q, re.I)
    try:
        if kind == "Franchise":
            if ids and ids[0].upper().startswith("OUT") and re.search(r"\b(why|reason|flag\w*|wrong|problem|issue|explain|risk)\b", ql):
                if scope and ids[0].upper() != scope: return {"answer": f"{ids[0].upper()} is outside your outlet scope ({scope}).", "df": None, "sql": ""}
                return explain_outlet(ids[0].upper(), dec)
            _pl = (bool(re.search(r"\b(where|which|list|all|show|located|locations?|states?|cities|city|how many|number)\b", ql)) or bool(_place(ql))) and not re.search(r"\b(risk\w*|health\w*|revenue|sales|csat|satisfaction|inventory|stock|attrition|salary|overtime|best|worst|weakest|critical)\b", ql)
            if _pl and re.search(r"\b(employees?|staff|workers?|people|headcount|manpower|workforce)\b", ql) and (_place(ql) or re.search(r"\b(where|which|most|highest|more|largest|big|fewest|least|lowest|number)\b", ql)): return staff_by_place(ql, scope)
            if _pl and re.search(r"\b(outlets?|stores?|branch\w*|franchises?)\b", ql) and _place(ql): return outlets_in_place(ql, scope)
            if re.search(r"\b(state|states)\b", ql) and re.search(r"\b(outlets?|stores?|branch\w*)\b", ql): return by_state(ql)
            if re.search(r"\b(outlets?|stores?|branch\w*)\b", ql) and re.search(r"\b(risk\w*|health\w*|best|worst|weakest|strongest|critical|attention|problem\w*|performing|performance)\b", ql) and not re.search(r"\b(revenue|sales|csat|satisfaction|headcount)\b", ql): return risk_rank(ql, dec, scope)
            if re.search(r"\b(inventory|stock|stocks|stocked|sku|skus|items?|products?|ingredients?)\b", ql) and re.search(r"\b(refill\w*|restock\w*|re-?order\w*|replenish\w*|immediate\w*|urgent\w*|attention|run(ning)? (out|low)|shortage\w*|low|critical|need\w*|order now)\b", ql) and not re.search(r"\b(how many|count|average|total)\b", ql): return refill(scope)
            if re.search(r"\b(inventory|stock)\b", ql) and re.search(r"\b(how|status|holding|summary|overview|situation|look|doing|week|today|health)\b", ql) and not re.search(r"\b(how many|count|average|total|top|lowest|highest|which)\b", ql): return inventory_status(scope)
            if re.search(r"\b(sales|revenue|takings)\b", ql) and re.search(r"\b(trend|this week|last week|today|yesterday|last 7|past week|recent|how (is|are|did))\b", ql): return sales_trend(scope)
            if re.search(r"\b(staff|workforce|employees?|team)\b", ql) and re.search(r"\b(how|status|summary|overview|situation|doing|look)\b", ql) and not re.search(r"\b(how many|count|average|total|top|lowest|highest|which)\b", ql): return staff_status(scope)
        else:
            if dom is not None and re.search(r"\b(days?|time|transit|cost|price|quote|route|how long|how much|eta|rates?|freight|charges?)\b", ql) and not re.search(r"\b(shipments?|carriers?|ports?|vessels?|customs|congest\w*)\b", ql) or (dom is not None and re.search(r"\b(days?|time|transit|cost|price|quote|route|how long|how much|eta)\b|\b\d+(\.\d+)?\s*(t|tons?|tonnes?|kgs?)\b", ql)):
                r = plan_lane(q, dom)
                if r: return r
                _p1 = _ports_in(re.sub(r"how long", "how_long", ql))[0]  # freight_ask_origin
                if len(_p1) == 1 and re.search(r"\b(best|fastest|cheapest|route|transit|cost|rate|freight)\b", ql) and re.search(r"\b(\d+\s*(t|tons?|tonnes?|kg)|from|to)\b", ql) and not re.search(r"\b(shipments?|carriers?|congest\w*)\b", ql):
                    return {"answer": f"I found one port ({_p1[0]}). Tell me both ports, for example: **Mumbai to {_p1[0].replace(' Port', '')} 20 t textiles**.", "df": None, "sql": ""}
            if re.search(r"\b(congest\w*|delay\w*|busy|ports?)\b", ql) and any(_w(ql, k) for k in CHOKE): return choke_ports(ql)
            r = freight_intents(ql)      # [M3] Milestone 2 intents
            if r: return r
            r = freight_summary(ql)
            if r: return r
    except Exception as e:
        import sys; print("analyst failed:", repr(e), file=sys.stderr)
    return None
